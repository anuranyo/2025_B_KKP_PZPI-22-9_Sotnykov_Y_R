import { config } from 'dotenv';
config();

import { createServer } from 'http';
import { Server } from 'socket.io';
import app from './src/app';
import { connectMongoDB } from './src/config/mongodb';
import { connectPostgreSQL } from './src/config/postgresql';
import { setupSocketHandlers } from './src/services/socket.service';

const PORT = process.env.PORT || 5000;

// Create HTTP server
const server = createServer(app);

// Setup Socket.IO
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

// Setup socket handlers
setupSocketHandlers(io);

// Start server function
async function startServer() {
  try {
    // Connect to databases
    await connectMongoDB();
    console.log('✅ MongoDB connected successfully');
    
    await connectPostgreSQL();
    console.log('✅ PostgreSQL connected successfully');

    // Start the server
    server.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
    });

  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

// Start the server
startServer();