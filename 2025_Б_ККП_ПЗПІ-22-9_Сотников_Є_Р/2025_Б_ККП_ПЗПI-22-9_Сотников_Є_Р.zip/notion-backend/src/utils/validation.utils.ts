import { z } from 'zod';

// User validation schemas
export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  name: z.string().min(2, 'Name must be at least 2 characters').max(50, 'Name cannot exceed 50 characters'),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/\d/, 'Password must contain at least one number')
    .regex(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, 'Password must contain at least one special character'),
  avatar: z.string().url().optional()
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required')
});

export const updateUserSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(50, 'Name cannot exceed 50 characters').optional(),
  avatar: z.string().url().optional()
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/\d/, 'Password must contain at least one number')
    .regex(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, 'Password must contain at least one special character')
});

// Workspace validation schemas
export const createWorkspaceSchema = z.object({
  name: z.string().min(1, 'Workspace name is required').max(100, 'Name cannot exceed 100 characters'),
  description: z.string().max(500, 'Description cannot exceed 500 characters').optional(),
  icon: z.string().optional(),
  isPublic: z.boolean().default(false)
});

export const updateWorkspaceSchema = z.object({
  name: z.string().min(1, 'Workspace name is required').max(100, 'Name cannot exceed 100 characters').optional(),
  description: z.string().max(500, 'Description cannot exceed 500 characters').optional(),
  icon: z.string().optional(),
  isPublic: z.boolean().optional()
});

export const inviteMemberSchema = z.object({
  email: z.string().email('Invalid email address'),
  role: z.enum(['ADMIN', 'MEMBER', 'VIEWER'], {
    errorMap: () => ({ message: 'Role must be ADMIN, MEMBER, or VIEWER' })
  })
});

export const updateMemberRoleSchema = z.object({
  role: z.enum(['ADMIN', 'MEMBER', 'VIEWER'], {
    errorMap: () => ({ message: 'Role must be ADMIN, MEMBER, or VIEWER' })
  })
});

// Document validation schemas
export const createDocumentSchema = z.object({
  title: z.string().min(1, 'Document title is required').max(200, 'Title cannot exceed 200 characters'),
  workspaceId: z.string().min(1, 'Workspace ID is required'), // Убрано .cuid() для совместимости
  parentId: z.string().min(1, 'Parent document ID is required').optional(),
  isPublic: z.boolean().default(false)
});

export const updateDocumentSchema = z.object({
  title: z.string().min(1, 'Document title is required').max(200, 'Title cannot exceed 200 characters').optional(),
  isPublic: z.boolean().optional(),
  isArchived: z.boolean().optional(),
  isFavorite: z.boolean().optional(),
  parentId: z.string().min(1, 'Parent document ID is required').nullable().optional()
});

// Document content validation schemas
export const textAnnotationSchema = z.object({
  bold: z.boolean().optional(),
  italic: z.boolean().optional(),
  strikethrough: z.boolean().optional(),
  underline: z.boolean().optional(),
  code: z.boolean().optional(),
  color: z.string().optional(),
  href: z.string().url().optional()
});

export const richTextSchema = z.object({
  type: z.enum(['text', 'mention', 'equation']),
  text: z.object({
    content: z.string(),
    link: z.object({ url: z.string().url() }).optional()
  }).optional(),
  mention: z.object({
    type: z.enum(['user', 'page', 'database']),
    user: z.object({ id: z.string() }).optional(),
    page: z.object({ id: z.string() }).optional()
  }).optional(),
  equation: z.object({
    expression: z.string()
  }).optional(),
  annotations: textAnnotationSchema,
  plain_text: z.string(),
  href: z.string().url().optional()
});

// Более гибкая схема блоков - ИСПРАВЛЕНО
export const blockSchema = z.object({
  id: z.string(),
  type: z.string(), // Убрано строгое enum - разрешаем любые типы блоков
  // Разрешаем строки и объекты Date для дат - ИСПРАВЛЕНО
  created_time: z.union([
    z.string(),
    z.date(),
    z.string().transform(val => new Date(val))
  ]),
  last_edited_time: z.union([
    z.string(), 
    z.date(),
    z.string().transform(val => new Date(val))
  ]),
  archived: z.boolean().default(false),
  has_children: z.boolean().default(false),
  parent_id: z.string().optional()
}).passthrough(); // Разрешаем дополнительные свойства для контента блоков

// КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: все поля опциональны
export const updateDocumentContentSchema = z.object({
  title: z.string().min(1, 'Document title is required').max(200, 'Title cannot exceed 200 characters').optional(),
  icon: z.object({
    type: z.enum(['emoji', 'file', 'external']),
    emoji: z.string().optional(),
    file: z.object({ url: z.string().url() }).optional(),
    external: z.object({ url: z.string().url() }).optional()
  }).optional(),
  cover: z.object({
    type: z.enum(['external', 'file']),
    external: z.object({ url: z.string().url() }).optional(),
    file: z.object({ url: z.string().url() }).optional()
  }).optional(),
  blocks: z.array(blockSchema).optional(), // ИСПРАВЛЕНО: сделано опциональным
  last_edited_time: z.union([z.string(), z.date()]).optional(), // Добавлено для совместимости
  last_edited_by: z.string().optional() // Добавлено для совместимости
});

// AI validation schemas
export const aiGenerateSchema = z.object({
  prompt: z.string().min(1, 'Prompt is required').max(2000, 'Prompt cannot exceed 2000 characters'),
  context: z.string().max(5000, 'Context cannot exceed 5000 characters').optional(),
  type: z.enum(['complete', 'improve', 'summarize', 'translate', 'custom']),
  max_tokens: z.number().min(1).max(4000).default(1000),
  temperature: z.number().min(0).max(2).default(0.7)
});

// Enhanced pagination validation schema with additional filters
export const paginationSchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
  search: z.string().optional(),
  // Additional filters for documents
  archived: z.enum(['true', 'false']).optional(),
  favorites: z.enum(['true', 'false']).optional()
});

// Search validation schema
export const searchSchema = z.object({
  query: z.string().min(1, 'Search query is required').max(200, 'Query cannot exceed 200 characters'),
  workspaceId: z.string().min(1, 'Workspace ID is required').optional(), // Убрано .cuid()
  type: z.enum(['documents', 'blocks', 'all']).default('all'),
  limit: z.coerce.number().min(1).max(50).default(20),
  offset: z.coerce.number().min(0).default(0)
});

// File upload validation schema
export const uploadSchema = z.object({
  folder: z.string().max(100).optional(),
  public_id: z.string().max(100).optional(),
  resource_type: z.enum(['image', 'video', 'raw', 'auto']).default('auto'),
  allowed_formats: z.array(z.string()).optional(),
  max_file_size: z.number().positive().optional()
});

// Generic ID validation
export const idSchema = z.object({
  id: z.string().min(1, 'ID is required') // Убрано .cuid() для совместимости
});

// УЛУЧШЕННАЯ функция валидации с более подробными ошибками
export const validateData = <T>(schema: z.ZodSchema<T>, data: unknown): T => {
  try {
    return schema.parse(data);
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('=== VALIDATION ERROR ===');
      console.error('Input data:', JSON.stringify(data, null, 2));
      console.error('Validation errors:', error.errors);
      
      const errorMessages = error.errors.map(err => {
        const path = err.path.length > 0 ? err.path.join('.') : 'root';
        return `${path}: ${err.message}`;
      }).join(', ');
      
      throw new Error(`Validation error: ${errorMessages}`);
    }
    console.error('=== NON-ZOD VALIDATION ERROR ===');
    console.error('Error:', error);
    throw error;
  }
};