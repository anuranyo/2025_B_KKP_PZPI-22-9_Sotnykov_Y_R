import { Router } from 'express';
import { asyncHandler } from '../middleware/error.middleware';
import { authenticate } from '../middleware/auth.middleware';
import { aiRateLimit } from '../middleware/rateLimit.middleware';
import { AIController } from '../controllers/ai.controller';

const router = Router();
const aiController = new AIController();

// All AI routes require authentication and have stricter rate limiting
router.use(authenticate);
router.use(aiRateLimit);

// AI generation endpoints
router.post('/generate', asyncHandler(aiController.generateContent.bind(aiController)));
router.post('/complete', asyncHandler(aiController.completeText.bind(aiController)));
router.post('/improve', asyncHandler(aiController.improveText.bind(aiController)));
router.post('/summarize', asyncHandler(aiController.summarizeText.bind(aiController)));
router.post('/translate', asyncHandler(aiController.translateText.bind(aiController)));

// AI-powered features
router.post('/brainstorm', asyncHandler(aiController.brainstorm.bind(aiController)));
router.post('/outline', asyncHandler(aiController.generateOutline.bind(aiController)));

// AI health check
router.get('/health', asyncHandler(aiController.healthCheck.bind(aiController)));

export default router;