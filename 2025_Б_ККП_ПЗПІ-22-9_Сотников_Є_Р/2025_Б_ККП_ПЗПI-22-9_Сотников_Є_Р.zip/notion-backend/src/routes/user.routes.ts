import { Router } from 'express';
import { asyncHandler } from '../middleware/error.middleware';
import { authenticate } from '../middleware/auth.middleware';
import { UserController } from '../controllers/user.controller';

const router = Router();
const userController = new UserController();

// All user routes require authentication
router.use(authenticate);

// User profile management
router.get('/profile', asyncHandler(userController.getProfile.bind(userController)));
router.put('/profile', asyncHandler(userController.updateProfile.bind(userController)));
router.delete('/profile', asyncHandler(userController.deleteProfile.bind(userController)));

// User workspaces
router.get('/workspaces', asyncHandler(userController.getUserWorkspaces.bind(userController)));

// User documents
router.get('/documents', asyncHandler(userController.getUserDocuments.bind(userController)));
router.get('/documents/recent', asyncHandler(userController.getRecentDocuments.bind(userController)));
router.get('/documents/favorites', asyncHandler(userController.getFavoriteDocuments.bind(userController)));

// User activity
router.get('/activity', asyncHandler(userController.getUserActivity.bind(userController)));

// User settings
router.get('/settings', asyncHandler(userController.getUserSettings.bind(userController)));
router.put('/settings', asyncHandler(userController.updateUserSettings.bind(userController)));

// User search
router.post('/search', asyncHandler(userController.searchUserContent.bind(userController)));

// User statistics
router.get('/stats', asyncHandler(userController.getUserStats.bind(userController)));

export default router;