import { Router } from 'express';
import { asyncHandler } from '../middleware/error.middleware';
import { authenticate } from '../middleware/auth.middleware';
import { AuthController } from '../controllers/auth.controller';

const router = Router();
const authController = new AuthController();

// Public routes
router.post('/register', asyncHandler(authController.register.bind(authController)));
router.post('/login', asyncHandler(authController.login.bind(authController)));
router.post('/forgot-password', asyncHandler(authController.forgotPassword.bind(authController)));
router.post('/reset-password', asyncHandler(authController.resetPassword.bind(authController)));

// Protected routes
router.get('/me', authenticate, asyncHandler(authController.getProfile.bind(authController)));
router.post('/logout', authenticate, asyncHandler(authController.logout.bind(authController)));
router.post('/refresh', authenticate, asyncHandler(authController.refreshToken.bind(authController)));
router.post('/change-password', authenticate, asyncHandler(authController.changePassword.bind(authController)));

export default router;