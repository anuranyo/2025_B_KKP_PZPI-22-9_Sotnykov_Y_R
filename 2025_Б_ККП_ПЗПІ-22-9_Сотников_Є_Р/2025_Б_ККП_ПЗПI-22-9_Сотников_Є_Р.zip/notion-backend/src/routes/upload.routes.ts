import { Router } from 'express';
import multer from 'multer';
import { asyncHandler } from '../middleware/error.middleware';
import { authenticate } from '../middleware/auth.middleware';
import { uploadRateLimit } from '../middleware/rateLimit.middleware';
import { UploadController } from '../controllers/upload.controller';

const router = Router();
const uploadController = new UploadController();

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
    files: 5 // Maximum 5 files per request
  },
  fileFilter: (req, file, cb) => {
    // Allow common file types
    const allowedTypes = [
      'image/jpeg',
      'image/jpg', 
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain',
      'text/csv'
    ];

    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('File type not allowed'));
    }
  }
});

// All upload routes require authentication and have upload rate limiting
router.use(authenticate);
router.use(uploadRateLimit);

// File upload endpoints
router.post('/single', 
  upload.single('file'), 
  asyncHandler(uploadController.uploadSingle.bind(uploadController))
);

router.post('/multiple', 
  upload.array('files', 5), 
  asyncHandler(uploadController.uploadMultiple.bind(uploadController))
);

// Image-specific uploads
router.post('/image', 
  upload.single('image'), 
  asyncHandler(uploadController.uploadImage.bind(uploadController))
);

router.post('/avatar', 
  upload.single('avatar'), 
  asyncHandler(uploadController.uploadAvatar.bind(uploadController))
);

// Document-specific uploads
router.post('/document-attachment', 
  upload.single('attachment'), 
  asyncHandler(uploadController.uploadDocumentAttachment.bind(uploadController))
);

// Delete uploaded file
router.delete('/:publicId', 
  asyncHandler(uploadController.deleteFile.bind(uploadController))
);

// Get upload URL for direct client uploads (if needed)
router.post('/signed-url', 
  asyncHandler(uploadController.getSignedUploadUrl.bind(uploadController))
);

export default router;