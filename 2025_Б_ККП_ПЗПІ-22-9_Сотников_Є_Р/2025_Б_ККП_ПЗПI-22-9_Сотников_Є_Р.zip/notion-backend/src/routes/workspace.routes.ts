import { Router } from 'express';
import { asyncHandler } from '../middleware/error.middleware';
import { authenticate, checkWorkspaceAccess } from '../middleware/auth.middleware';
import { WorkspaceController } from '../controllers/workspace.controller';

const router = Router();
const workspaceController = new WorkspaceController();

// All workspace routes require authentication
router.use(authenticate);

// Workspace CRUD operations
router.post('/', asyncHandler(workspaceController.createWorkspace.bind(workspaceController)));
router.get('/', asyncHandler(workspaceController.getUserWorkspaces.bind(workspaceController)));
router.get('/:workspaceId', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.getWorkspace.bind(workspaceController)));
router.put('/:workspaceId', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.updateWorkspace.bind(workspaceController)));
router.delete('/:workspaceId', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.deleteWorkspace.bind(workspaceController)));

// Workspace member management
router.get('/:workspaceId/members', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.getWorkspaceMembers.bind(workspaceController)));
router.post('/:workspaceId/members', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.inviteMember.bind(workspaceController)));
router.put('/:workspaceId/members/:userId', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.updateMemberRole.bind(workspaceController)));
router.delete('/:workspaceId/members/:userId', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.removeMember.bind(workspaceController)));

// Member actions
router.post('/:workspaceId/join', asyncHandler(workspaceController.joinWorkspace.bind(workspaceController)));
router.post('/:workspaceId/leave', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.leaveWorkspace.bind(workspaceController)));

// Workspace documents
router.get('/:workspaceId/documents', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.getWorkspaceDocuments.bind(workspaceController)));
router.get('/:workspaceId/documents/recent', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.getRecentWorkspaceDocuments.bind(workspaceController)));

// Workspace activity
router.get('/:workspaceId/activity', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.getWorkspaceActivity.bind(workspaceController)));

// Workspace settings
router.get('/:workspaceId/settings', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.getWorkspaceSettings.bind(workspaceController)));
router.put('/:workspaceId/settings', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.updateWorkspaceSettings.bind(workspaceController)));

// Workspace transfer and duplication
router.post('/:workspaceId/transfer', checkWorkspaceAccess('ADMIN'), asyncHandler(workspaceController.transferOwnership.bind(workspaceController)));
router.post('/:workspaceId/duplicate', checkWorkspaceAccess('READ'), asyncHandler(workspaceController.duplicateWorkspace.bind(workspaceController)));

// Public workspaces
router.get('/public/list', asyncHandler(workspaceController.getPublicWorkspaces.bind(workspaceController)));

export default router;