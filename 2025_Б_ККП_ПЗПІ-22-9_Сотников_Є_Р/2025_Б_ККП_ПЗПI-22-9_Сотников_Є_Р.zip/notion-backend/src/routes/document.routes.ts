import { Router } from 'express';
import { asyncHandler } from '../middleware/error.middleware';
import { authenticate, checkDocumentAccess, checkWorkspaceAccess } from '../middleware/auth.middleware';
import { DocumentController } from '../controllers/document.controller';

const router = Router();
const documentController = new DocumentController();

// All routes require authentication
router.use(authenticate);

// Document CRUD operations
router.post('/', asyncHandler(documentController.createDocument.bind(documentController)));
router.get('/workspace/:workspaceId', checkWorkspaceAccess('READ'), asyncHandler(documentController.getWorkspaceDocuments.bind(documentController)));
router.get('/:documentId', checkDocumentAccess('READ'), asyncHandler(documentController.getDocument.bind(documentController)));
router.put('/:documentId', checkDocumentAccess('WRITE'), asyncHandler(documentController.updateDocument.bind(documentController)));
router.delete('/:documentId', checkDocumentAccess('ADMIN'), asyncHandler(documentController.deleteDocument.bind(documentController)));

// Document content operations (MongoDB)
router.get('/:documentId/content', checkDocumentAccess('READ'), asyncHandler(documentController.getDocumentContent.bind(documentController)));
router.put('/:documentId/content', checkDocumentAccess('WRITE'), asyncHandler(documentController.updateDocumentContent.bind(documentController)));

// Document hierarchy operations
router.get('/:documentId/children', checkDocumentAccess('READ'), asyncHandler(documentController.getChildDocuments.bind(documentController)));
router.put('/:documentId/move', checkDocumentAccess('WRITE'), asyncHandler(documentController.moveDocument.bind(documentController)));

// Document access management
router.get('/:documentId/access', checkDocumentAccess('ADMIN'), asyncHandler(documentController.getDocumentAccess.bind(documentController)));
router.post('/:documentId/access', checkDocumentAccess('ADMIN'), asyncHandler(documentController.grantDocumentAccess.bind(documentController)));
router.put('/:documentId/access/:userId', checkDocumentAccess('ADMIN'), asyncHandler(documentController.updateDocumentAccess.bind(documentController)));
router.delete('/:documentId/access/:userId', checkDocumentAccess('ADMIN'), asyncHandler(documentController.revokeDocumentAccess.bind(documentController)));

// Document versions
router.get('/:documentId/versions', checkDocumentAccess('READ'), asyncHandler(documentController.getDocumentVersions.bind(documentController)));
router.get('/:documentId/versions/:versionId', checkDocumentAccess('READ'), asyncHandler(documentController.getDocumentVersion.bind(documentController)));
router.post('/:documentId/versions', checkDocumentAccess('WRITE'), asyncHandler(documentController.createDocumentVersion.bind(documentController)));

// Document operations
router.post('/:documentId/duplicate', checkDocumentAccess('READ'), asyncHandler(documentController.duplicateDocument.bind(documentController)));
router.post('/:documentId/favorite', checkDocumentAccess('READ'), asyncHandler(documentController.toggleFavorite.bind(documentController)));
router.post('/:documentId/archive', checkDocumentAccess('WRITE'), asyncHandler(documentController.toggleArchive.bind(documentController)));

// Document search and activity
router.get('/:documentId/activity', checkDocumentAccess('READ'), asyncHandler(documentController.getDocumentActivity.bind(documentController)));
router.post('/search', asyncHandler(documentController.searchDocuments.bind(documentController)));

// Bulk operations
router.post('/bulk/delete', asyncHandler(documentController.bulkDeleteDocuments.bind(documentController)));
router.post('/bulk/archive', asyncHandler(documentController.bulkArchiveDocuments.bind(documentController)));
router.post('/bulk/move', asyncHandler(documentController.bulkMoveDocuments.bind(documentController)));

export default router;