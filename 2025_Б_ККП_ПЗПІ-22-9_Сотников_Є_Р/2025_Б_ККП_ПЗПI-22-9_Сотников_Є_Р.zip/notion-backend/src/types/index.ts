// API Response types
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
  pagination?: PaginationMeta;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface PaginationQuery {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  search?: string;
  archived?: 'true' | 'false';
  favorites?: 'true' | 'false';
}

// User types
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  user: User;
  token: string;
  expiresIn: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  name: string;
  password: string;
  avatar?: string;
}

export interface CreateUserData {
  email: string;
  name: string;
  password: string;
  avatar?: string;
}

export interface UpdateUserData {
  name?: string;
  avatar?: string;
}

// Workspace types
export interface Workspace {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  isPublic: boolean;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
  owner?: {
    id: string;
    name: string;
    avatar?: string;
  };
  members?: WorkspaceMember[];
  _count?: {
    members: number;
    documents: number;
  };
}

export interface WorkspaceMember {
  id: string;
  userId: string;
  workspaceId: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER' | 'VIEWER';
  joinedAt: string;
  user: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
}

export interface CreateWorkspaceData {
  name: string;
  description?: string;
  icon?: string;
  isPublic?: boolean;
}

export interface UpdateWorkspaceData {
  name?: string;
  description?: string;
  icon?: string;
  isPublic?: boolean;
}

export interface WorkspaceMemberData {
  id: string;
  userId: string;
  workspaceId: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER' | 'VIEWER';
  joinedAt: Date;
  user: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
}

export interface InviteMemberData {
  email: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER' | 'VIEWER';
}

// Document types
export interface Document {
  id: string;
  title: string;
  mongoId: string;
  isPublic: boolean;
  isArchived: boolean;
  isFavorite: boolean;
  parentId?: string;
  authorId: string;
  workspaceId: string;
  createdAt: string;
  updatedAt: string;
  author?: {
    id: string;
    name: string;
    avatar?: string;
  };
  workspace?: {
    id: string;
    name: string;
  };
  parent?: {
    id: string;
    title: string;
  };
  children?: Array<{
    id: string;
    title: string;
    updatedAt: string;
  }>;
  _count?: {
    children: number;
  };
}

export interface CreateDocumentData {
  title: string;
  workspaceId: string;
  parentId?: string;
  isPublic?: boolean;
}

export interface UpdateDocumentData {
  title?: string;
  isPublic?: boolean;
  isArchived?: boolean;
  isFavorite?: boolean;
  parentId?: string;
}

export interface DocumentData {
  id: string;
  title: string;
  mongoId: string;
  isPublic: boolean;
  isArchived: boolean;
  isFavorite: boolean;
  parentId?: string;
  authorId: string;
  workspaceId: string;
  createdAt: Date;
  updatedAt: Date;
  author?: {
    id: string;
    name: string;
    avatar?: string;
  };
  workspace?: {
    id: string;
    name: string;
  };
}

// Document Content types
export interface RichText {
  type: 'text' | 'mention' | 'equation';
  text?: {
    content: string;
    link?: { url: string };
  };
  mention?: {
    type: 'user' | 'page' | 'database';
    user?: { id: string };
    page?: { id: string };
  };
  equation?: {
    expression: string;
  };
  annotations: {
    bold?: boolean;
    italic?: boolean;
    strikethrough?: boolean;
    underline?: boolean;
    code?: boolean;
    color?: string;
    href?: string;
  };
  plain_text: string;
  href?: string;
}

export interface Block {
  id: string;
  type: string;
  created_time: string;
  last_edited_time: string;
  archived: boolean;
  has_children: boolean;
  parent_id?: string;
  [key: string]: any;
}

export interface DocumentContent {
  id: string;
  postgresql_id: string;
  title: string;
  icon?: {
    type: 'emoji' | 'file' | 'external';
    emoji?: string;
    file?: { url: string };
    external?: { url: string };
  };
  cover?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string };
  };
  blocks: Block[];
  current_version: number;
  last_edited_time: string;
  last_edited_by: string;
  created_time: string;
  created_by: string;
}

export interface DocumentContentData {
  id: string;
  postgresql_id: string;
  title: string;
  icon?: {
    type: 'emoji' | 'file' | 'external';
    emoji?: string;
    file?: { url: string };
    external?: { url: string };
  };
  cover?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string };
  };
  blocks: any[];
  current_version: number;
  last_edited_time: Date;
  last_edited_by: string;
  created_time: Date;
  created_by: string;
}

// AI types
export interface AIGenerateRequest {
  prompt: string;
  context?: string;
  type: 'complete' | 'improve' | 'summarize' | 'translate' | 'custom';
  max_tokens?: number;
  temperature?: number;
}

export interface AIGenerateResponse {
  content: string;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

// Upload types
export interface UploadedFile {
  public_id: string;
  url: string;
  format: string;
  resource_type: string;
  bytes: number;
  width?: number;
  height?: number;
}

export interface UploadResponse {
  success: boolean;
  file: UploadedFile;
}

// Socket types
export interface SocketUser {
  id: string;
  name: string;
  avatar?: string;
}

export interface DocumentUpdateEvent {
  documentId: string;
  userId: string;
  user: SocketUser;
  operation: 'insert' | 'update' | 'delete';
  blockId?: string;
  data: any;
  timestamp: Date;
}

export interface UserPresenceEvent {
  userId: string;
  user: SocketUser;
  documentId: string;
  cursor?: {
    blockId: string;
    position: number;
  };
  selection?: {
    startBlockId: string;
    startPosition: number;
    endBlockId: string;
    endPosition: number;
  };
}

// Activity Log types
export interface ActivityLogData {
  id: string;
  action: string;
  details?: any;
  timestamp: Date;
  userId: string;
  documentId?: string;
  user: {
    id: string;
    name: string;
    avatar?: string;
  };
}

// Search types
export interface SearchQuery {
  query: string;
  workspaceId?: string;
  type?: 'documents' | 'blocks' | 'all';
  limit?: number;
  offset?: number;
}

export interface SearchResult {
  id: string;
  type: 'document' | 'block';
  title: string;
  content: string;
  url: string;
  highlights: string[];
  document?: {
    id: string;
    title: string;
    workspaceId: string;
  };
}

export interface SearchResponse {
  results: SearchResult[];
  total: number;
  query: string;
  took: number;
}

// Extended types for frontend compatibility
export type UserProfile = User;