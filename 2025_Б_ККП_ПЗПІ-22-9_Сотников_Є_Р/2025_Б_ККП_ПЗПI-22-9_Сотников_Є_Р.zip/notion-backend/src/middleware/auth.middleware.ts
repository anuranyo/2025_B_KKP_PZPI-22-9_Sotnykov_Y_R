import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/postgresql';
import { AppError } from './error.middleware';

// Extend Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        name: string;
      };
    }
  }
}

export interface JWTPayload {
  userId: string;
  email: string;
  iat: number;
  exp: number;
}

// Authentication middleware
export const authenticate = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Access token is required', 401);
    }

    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    
    if (!token) {
      throw new AppError('Access token is required', 401);
    }

    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      throw new AppError('JWT secret not configured', 500);
    }

    // Verify token
    const decoded = jwt.verify(token, jwtSecret) as JWTPayload;
    
    // Get user from database
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        createdAt: true,
      }
    });

    if (!user) {
      throw new AppError('User not found', 401);
    }

    // Attach user to request
    req.user = {
      id: user.id,
      email: user.email,
      name: user.name,
    };

    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AppError('Invalid token', 401));
    }
    if (error instanceof jwt.TokenExpiredError) {
      return next(new AppError('Token expired', 401));
    }
    next(error);
  }
};

// Optional authentication (for public routes that can work with or without auth)
export const optionalAuth = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  
  if (authHeader && authHeader.startsWith('Bearer ')) {
    // Try to authenticate, but don't fail if invalid
    try {
      await authenticate(req, res, () => {});
    } catch (error) {
      // Ignore authentication errors for optional auth
    }
  }
  
  next();
};

// Check if user has workspace access
export const checkWorkspaceAccess = (permission: 'READ' | 'WRITE' | 'ADMIN' = 'READ') => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { workspaceId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        throw new AppError('Authentication required', 401);
      }

      if (!workspaceId) {
        throw new AppError('Workspace ID is required', 400);
      }

      // Check if user is workspace owner or member
      const workspace = await prisma.workspace.findFirst({
        where: {
          id: workspaceId,
          OR: [
            { ownerId: userId },
            {
              members: {
                some: {
                  userId: userId,
                  ...(permission === 'ADMIN' && { role: { in: ['OWNER', 'ADMIN'] } }),
                  ...(permission === 'WRITE' && { role: { in: ['OWNER', 'ADMIN', 'MEMBER'] } }),
                }
              }
            }
          ]
        },
        include: {
          members: {
            where: { userId },
            select: { role: true }
          }
        }
      });

      if (!workspace) {
        throw new AppError('Workspace not found or access denied', 403);
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};

// Check document access permissions
export const checkDocumentAccess = (permission: 'READ' | 'WRITE' | 'ADMIN' = 'READ') => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { documentId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        throw new AppError('Authentication required', 401);
      }

      if (!documentId) {
        throw new AppError('Document ID is required', 400);
      }

      // Check document access
      const document = await prisma.document.findFirst({
        where: {
          id: documentId,
          OR: [
            { authorId: userId }, // Document author
            { isPublic: true }, // Public document
            {
              workspace: {
                OR: [
                  { ownerId: userId }, // Workspace owner
                  {
                    members: {
                      some: { userId }
                    }
                  }
                ]
              }
            },
            {
              access: {
                some: {
                  userId,
                  ...(permission === 'ADMIN' && { permission: 'ADMIN' }),
                  ...(permission === 'WRITE' && { permission: { in: ['WRITE', 'ADMIN'] } }),
                }
              }
            }
          ]
        }
      });

      if (!document) {
        throw new AppError('Document not found or access denied', 403);
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};