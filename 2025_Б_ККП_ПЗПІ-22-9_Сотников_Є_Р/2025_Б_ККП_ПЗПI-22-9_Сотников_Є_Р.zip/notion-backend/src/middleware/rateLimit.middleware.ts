import { Request, Response, NextFunction } from 'express';
import { RateLimiterMemory, RateLimiterRedis } from 'rate-limiter-flexible';

// Basic rate limiter configuration
const rateLimiterConfig = {
  keyPrefix: 'notion_api',
  points: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100000000'), // Number of requests
  duration: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '9'), // Per 15 minutes (900 seconds)
  blockDuration: 90, // Block for 15 minutes
};

// Create rate limiter instance
const rateLimiter = new RateLimiterMemory(rateLimiterConfig);

// AI-specific rate limiter (more restrictive)
const aiRateLimiter = new RateLimiterMemory({
  keyPrefix: 'notion_ai',
  points: 20, // 20 AI requests
  duration: 3600, // Per hour
  blockDuration: 3600, // Block for 1 hour
});

// Upload rate limiter
const uploadRateLimiter = new RateLimiterMemory({
  keyPrefix: 'notion_upload',
  points: 50, // 50 uploads
  duration: 3600, // Per hour
  blockDuration: 1800, // Block for 30 minutes
});

export const rateLimiterMiddleware = (limiter: RateLimiterMemory) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const key = req.ip || req.connection.remoteAddress || 'unknown';
      const resRateLimiter = await limiter.consume(key);

      // Add rate limit headers
      res.set({
        'X-RateLimit-Limit': limiter.points.toString(),
        'X-RateLimit-Remaining': resRateLimiter.remainingPoints?.toString() || '0',
        'X-RateLimit-Reset': new Date(Date.now() + resRateLimiter.msBeforeNext).toISOString(),
      });

      next();
    } catch (rejRes: any) {
      // Rate limit exceeded
      const secs = Math.round(rejRes.msBeforeNext / 1000) || 1;
      
      res.set({
        'X-RateLimit-Limit': limiter.points.toString(),
        'X-RateLimit-Remaining': '0',
        'X-RateLimit-Reset': new Date(Date.now() + rejRes.msBeforeNext).toISOString(),
        'Retry-After': secs.toString(),
      });

      res.status(429).json({
        success: false,
        message: 'Too many requests, please try again later.',
        retryAfter: secs
      });
    }
  };
};

// Export different rate limiters
export const generalRateLimit = rateLimiterMiddleware(rateLimiter);
export const aiRateLimit = rateLimiterMiddleware(aiRateLimiter);
export const uploadRateLimit = rateLimiterMiddleware(uploadRateLimiter);

// Default rate limiter for general API routes
export { generalRateLimit as rateLimiter };