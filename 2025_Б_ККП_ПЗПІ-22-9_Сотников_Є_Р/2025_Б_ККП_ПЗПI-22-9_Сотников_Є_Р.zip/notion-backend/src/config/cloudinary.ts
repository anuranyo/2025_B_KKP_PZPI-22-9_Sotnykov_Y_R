import { v2 as cloudinary } from 'cloudinary';

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export interface UploadOptions {
  folder?: string;
  public_id?: string;
  resource_type?: 'image' | 'video' | 'raw' | 'auto';
  allowed_formats?: string[];
  max_file_size?: number;
}

export const uploadToCloudinary = async (
  file: string | Buffer, 
  options: UploadOptions = {}
): Promise<any> => {
  try {
    const defaultOptions = {
      folder: 'notion-app',
      resource_type: 'auto' as const,
      allowed_formats: ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'docx', 'xlsx'],
      max_file_size: 10 * 1024 * 1024, // 10MB
    };

    const uploadOptions = { ...defaultOptions, ...options };

    let uploadSource: string;
    if (Buffer.isBuffer(file)) {
      // Convert Buffer to base64 data URI (default to image/png, adjust as needed)
      const base64 = file.toString('base64');
      uploadSource = `data:application/octet-stream;base64,${base64}`;
    } else {
      uploadSource = file;
    }
    const result = await cloudinary.uploader.upload(uploadSource, uploadOptions);
    
    return {
      public_id: result.public_id,
      url: result.secure_url,
      format: result.format,
      resource_type: result.resource_type,
      bytes: result.bytes,
      width: result.width,
      height: result.height,
    };
  } catch (error) {
    console.error('Cloudinary upload error:', error);
    throw new Error('Failed to upload file to Cloudinary');
  }
};

export const deleteFromCloudinary = async (publicId: string): Promise<void> => {
  try {
    await cloudinary.uploader.destroy(publicId);
  } catch (error) {
    console.error('Cloudinary delete error:', error);
    throw new Error('Failed to delete file from Cloudinary');
  }
};

export default cloudinary;