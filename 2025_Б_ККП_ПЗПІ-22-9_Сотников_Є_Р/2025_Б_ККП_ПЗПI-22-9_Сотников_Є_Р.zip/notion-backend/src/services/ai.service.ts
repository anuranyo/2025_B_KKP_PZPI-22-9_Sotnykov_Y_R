import Anthropic from '@anthropic-ai/sdk';
import type { AIGenerateRequest, AIGenerateResponse } from '../types';

class AIService {
  private anthropic: Anthropic;
  private readonly MODEL_NAME = 'claude-3-5-sonnet-20241022'; // Latest stable model

  constructor() {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    
    if (!apiKey) {
      throw new Error('ANTHROPIC_API_KEY is not defined in environment variables');
    }

    this.anthropic = new Anthropic({
      apiKey: apiKey,
    });
  }

  // Generate content based on prompt and type
  async generateContent(request: AIGenerateRequest): Promise<AIGenerateResponse> {
    try {
      const { prompt, context, type, max_tokens = 1000, temperature = 0.7 } = request;

      // Build system prompt based on type
      const systemPrompt = this.buildSystemPrompt(type);
      
      // Build user message with context if provided
      const userMessage = context 
        ? `Context: ${context}\n\nRequest: ${prompt}`
        : prompt;

      const response = await this.anthropic.messages.create({
        model: this.MODEL_NAME,
        max_tokens: max_tokens,
        temperature: temperature,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: userMessage
          }
        ]
      });

      // Extract text content from response
      const content = response.content
        .filter((block: any) => block.type === 'text')
        .map((block: any) => block.text)
        .join('\n');

      return {
        content: content.trim(),
        usage: {
          prompt_tokens: response.usage.input_tokens,
          completion_tokens: response.usage.output_tokens,
          total_tokens: response.usage.input_tokens + response.usage.output_tokens
        }
      };

    } catch (error) {
      console.error('AI Service Error:', error);
      
      // Handle specific Anthropic errors
      if (error instanceof Error) {
        if (error.message.includes('model') || error.message.includes('not_found')) {
          throw new Error(`AI model not available: ${this.MODEL_NAME}`);
        }
        if (error.message.includes('rate_limit')) {
          throw new Error('AI service rate limit exceeded. Please try again later.');
        }
        if (error.message.includes('authentication')) {
          throw new Error('AI service authentication failed. Please check API key.');
        }
      }
      
      throw new Error('Failed to generate AI content');
    }
  }

  // Complete text based on partial input
  async completeText(prompt: string, context?: string): Promise<string> {
    const request: AIGenerateRequest = {
      prompt,
      context,
      type: 'complete',
      max_tokens: 500,
      temperature: 0.6
    };

    const response = await this.generateContent(request);
    return response.content;
  }

  // Improve existing text
  async improveText(text: string, instructions?: string): Promise<string> {
    const prompt = instructions 
      ? `Improve this text according to these instructions: ${instructions}\n\nText: ${text}`
      : `Improve this text: ${text}`;

    const request: AIGenerateRequest = {
      prompt,
      type: 'improve',
      max_tokens: 800,
      temperature: 0.5
    };

    const response = await this.generateContent(request);
    return response.content;
  }

  // Summarize text
  async summarizeText(text: string, length: 'short' | 'medium' | 'long' = 'medium'): Promise<string> {
    const lengthInstructions = {
      short: 'in 1-2 sentences',
      medium: 'in 1-2 paragraphs',
      long: 'in 3-4 paragraphs'
    };

    const prompt = `Summarize this text ${lengthInstructions[length]}:\n\n${text}`;

    const request: AIGenerateRequest = {
      prompt,
      type: 'summarize',
      max_tokens: length === 'short' ? 100 : length === 'medium' ? 300 : 600,
      temperature: 0.3
    };

    const response = await this.generateContent(request);
    return response.content;
  }

  // Translate text
  async translateText(text: string, targetLanguage: string, sourceLanguage?: string): Promise<string> {
    const sourceInfo = sourceLanguage ? ` from ${sourceLanguage}` : '';
    const prompt = `Translate this text${sourceInfo} to ${targetLanguage}:\n\n${text}`;

    const request: AIGenerateRequest = {
      prompt,
      type: 'translate',
      max_tokens: Math.min(text.length * 2, 2000),
      temperature: 0.2
    };

    const response = await this.generateContent(request);
    return response.content;
  }

  // Generate ideas or brainstorm
  async brainstorm(topic: string, count: number = 5): Promise<string[]> {
    const prompt = `Generate ${count} creative ideas or suggestions about: ${topic}. Provide each idea on a new line, numbered.`;

    const request: AIGenerateRequest = {
      prompt,
      type: 'custom',
      max_tokens: 800,
      temperature: 0.8
    };

    const response = await this.generateContent(request);
    
    // Split response into individual ideas
    return response.content
      .split('\n')
      .filter(line => line.trim().length > 0)
      .map(line => line.replace(/^\d+\.\s*/, '').trim())
      .filter(line => line.length > 0)
      .slice(0, count);
  }

  // Generate outline for a topic
  async generateOutline(topic: string, depth: 'basic' | 'detailed' = 'basic'): Promise<string> {
    const depthInstruction = depth === 'detailed' 
      ? 'Create a detailed outline with main points and sub-points'
      : 'Create a basic outline with main points';

    const prompt = `${depthInstruction} for: ${topic}`;

    const request: AIGenerateRequest = {
      prompt,
      type: 'custom',
      max_tokens: depth === 'detailed' ? 1000 : 500,
      temperature: 0.4
    };

    const response = await this.generateContent(request);
    return response.content;
  }

  // Build system prompt based on AI request type
  private buildSystemPrompt(type: AIGenerateRequest['type']): string {
    const basePrompt = "You are a helpful AI assistant integrated into a Notion-like productivity application. ";

    switch (type) {
      case 'complete':
        return basePrompt + "Help users complete their thoughts and text in a natural, coherent way. Match the tone and style of the existing content.";
      
      case 'improve':
        return basePrompt + "Help users improve their text by making it clearer, more engaging, and better structured while preserving the original meaning and intent.";
      
      case 'summarize':
        return basePrompt + "Create concise, accurate summaries that capture the key points and main ideas of the provided text.";
      
      case 'translate':
        return basePrompt + "Provide accurate translations while preserving the meaning, tone, and context of the original text.";
      
      case 'custom':
        return basePrompt + "Assist users with various writing and productivity tasks. Be creative, helpful, and provide practical suggestions.";
      
      default:
        return basePrompt + "Assist users with their writing and productivity needs.";
    }
  }

  // Check if AI service is available
  async healthCheck(): Promise<boolean> {
    try {
      const response = await this.anthropic.messages.create({
        model: this.MODEL_NAME,
        max_tokens: 10,
        messages: [
          {
            role: 'user',
            content: 'Test'
          }
        ]
      });

      return response.content.length > 0;
    } catch (error) {
      console.error('AI Health Check Failed:', error);
      return false;
    }
  }

  // Get available models (for debugging)
  getModelName(): string {
    return this.MODEL_NAME;
  }

  // Check API key validity
  async validateApiKey(): Promise<boolean> {
    try {
      await this.healthCheck();
      return true;
    } catch (error) {
      return false;
    }
  }
}

export const aiService = new AIService();