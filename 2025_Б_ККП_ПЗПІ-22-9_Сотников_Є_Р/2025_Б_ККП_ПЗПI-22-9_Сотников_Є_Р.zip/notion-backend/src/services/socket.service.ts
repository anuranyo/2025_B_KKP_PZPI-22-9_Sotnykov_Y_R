import { Server, Socket } from 'socket.io';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/postgresql';
import { DocumentUpdateEvent, UserPresenceEvent, SocketUser } from '../types';

interface AuthenticatedSocket extends Socket {
  user?: SocketUser;
}

interface DocumentRoom {
  documentId: string;
  users: Map<string, {
    user: SocketUser;
    socket: AuthenticatedSocket;
    cursor?: {
      blockId: string;
      position: number;
    };
    lastSeen: Date;
  }>;
}

class SocketService {
  private io: Server;
  private documentRooms: Map<string, DocumentRoom> = new Map();
  private userSockets: Map<string, AuthenticatedSocket[]> = new Map();

  constructor(io: Server) {
    this.io = io;
  }

  // Setup all socket event handlers
  setupHandlers() {
    this.io.use(this.authenticateSocket.bind(this));
    this.io.on('connection', this.handleConnection.bind(this));
  }

  // Authenticate socket connection
  private async authenticateSocket(socket: AuthenticatedSocket, next: Function) {
    try {
      const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];
      
      if (!token) {
        throw new Error('Authentication token required');
      }

      const jwtSecret = process.env.JWT_SECRET;
      if (!jwtSecret) {
        throw new Error('JWT secret not configured');
      }

      const decoded = jwt.verify(token, jwtSecret) as any;
      
      // Get user info from database
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true
        }
      });

      if (!user) {
        throw new Error('User not found');
      }

      socket.user = {
        id: user.id,
        name: user.name,
        avatar: user.avatar || undefined
      };

      next();
    } catch (error) {
      console.error('Socket authentication error:', error);
      next(new Error('Authentication failed'));
    }
  }

  // Handle new socket connection
  private handleConnection(socket: AuthenticatedSocket) {
    console.log(`User ${socket.user?.name} connected with socket ${socket.id}`);

    // Add socket to user's socket list
    this.addUserSocket(socket);

    // Setup event handlers
    socket.on('join_document', (data) => this.handleJoinDocument(socket, data));
    socket.on('leave_document', (data) => this.handleLeaveDocument(socket, data));
    socket.on('document_update', (data) => this.handleDocumentUpdate(socket, data));
    socket.on('cursor_update', (data) => this.handleCursorUpdate(socket, data));
    socket.on('user_typing', (data) => this.handleUserTyping(socket, data));
    socket.on('user_stopped_typing', (data) => this.handleUserStoppedTyping(socket, data));

    // Handle disconnection
    socket.on('disconnect', () => this.handleDisconnection(socket));
  }

  // Add socket to user's socket list
  private addUserSocket(socket: AuthenticatedSocket) {
    if (!socket.user) return;

    const userId = socket.user.id;
    if (!this.userSockets.has(userId)) {
      this.userSockets.set(userId, []);
    }
    this.userSockets.get(userId)!.push(socket);
  }

  // Remove socket from user's socket list
  private removeUserSocket(socket: AuthenticatedSocket) {
    if (!socket.user) return;

    const userId = socket.user.id;
    const sockets = this.userSockets.get(userId);
    if (sockets) {
      const index = sockets.indexOf(socket);
      if (index !== -1) {
        sockets.splice(index, 1);
      }
      if (sockets.length === 0) {
        this.userSockets.delete(userId);
      }
    }
  }

  // Handle user joining a document
  private async handleJoinDocument(socket: AuthenticatedSocket, data: { documentId: string }) {
    try {
      const { documentId } = data;
      
      if (!socket.user) return;

      // Verify user has access to the document
      const hasAccess = await this.verifyDocumentAccess(socket.user.id, documentId);
      if (!hasAccess) {
        socket.emit('error', { message: 'Access denied to document' });
        return;
      }

      // Join the document room
      socket.join(`document:${documentId}`);

      // Add user to document room tracking
      if (!this.documentRooms.has(documentId)) {
        this.documentRooms.set(documentId, {
          documentId,
          users: new Map()
        });
      }

      const room = this.documentRooms.get(documentId)!;
      room.users.set(socket.user.id, {
        user: socket.user,
        socket,
        lastSeen: new Date()
      });

      // Notify other users in the document
      socket.to(`document:${documentId}`).emit('user_joined', {
        user: socket.user,
        timestamp: new Date()
      });

      // Send current users in the document to the joining user
      const currentUsers = Array.from(room.users.values()).map(u => ({
        user: u.user,
        cursor: u.cursor,
        lastSeen: u.lastSeen
      }));

      socket.emit('document_users', currentUsers);

      console.log(`User ${socket.user.name} joined document ${documentId}`);
    } catch (error) {
      console.error('Error joining document:', error);
      socket.emit('error', { message: 'Failed to join document' });
    }
  }

  // Handle user leaving a document
  private handleLeaveDocument(socket: AuthenticatedSocket, data: { documentId: string }) {
    const { documentId } = data;
    
    if (!socket.user) return;

    socket.leave(`document:${documentId}`);

    const room = this.documentRooms.get(documentId);
    if (room) {
      room.users.delete(socket.user.id);
      
      // Clean up empty rooms
      if (room.users.size === 0) {
        this.documentRooms.delete(documentId);
      }
    }

    // Notify other users
    socket.to(`document:${documentId}`).emit('user_left', {
      user: socket.user,
      timestamp: new Date()
    });

    console.log(`User ${socket.user.name} left document ${documentId}`);
  }

  // Handle document content updates
  private handleDocumentUpdate(socket: AuthenticatedSocket, data: DocumentUpdateEvent) {
    if (!socket.user) return;

    const updateEvent: DocumentUpdateEvent = {
      ...data,
      userId: socket.user.id,
      user: socket.user,
      timestamp: new Date()
    };

    // Broadcast to all other users in the document
    socket.to(`document:${data.documentId}`).emit('document_updated', updateEvent);

    console.log(`Document update from ${socket.user.name} in document ${data.documentId}`);
  }

  // Handle cursor position updates
  private handleCursorUpdate(socket: AuthenticatedSocket, data: UserPresenceEvent) {
    if (!socket.user) return;

    const room = this.documentRooms.get(data.documentId);
    if (room && room.users.has(socket.user.id)) {
      const userInRoom = room.users.get(socket.user.id)!;
      userInRoom.cursor = data.cursor;
      userInRoom.lastSeen = new Date();
    }

    const presenceEvent: UserPresenceEvent = {
      ...data,
      userId: socket.user.id,
      user: socket.user
    };

    // Broadcast cursor position to other users
    socket.to(`document:${data.documentId}`).emit('cursor_updated', presenceEvent);
  }

  // Handle user typing events
  private handleUserTyping(socket: AuthenticatedSocket, data: { documentId: string; blockId: string }) {
    if (!socket.user) return;

    socket.to(`document:${data.documentId}`).emit('user_typing', {
      user: socket.user,
      documentId: data.documentId,
      blockId: data.blockId,
      timestamp: new Date()
    });
  }

  // Handle user stopped typing events
  private handleUserStoppedTyping(socket: AuthenticatedSocket, data: { documentId: string; blockId: string }) {
    if (!socket.user) return;

    socket.to(`document:${data.documentId}`).emit('user_stopped_typing', {
      user: socket.user,
      documentId: data.documentId,
      blockId: data.blockId,
      timestamp: new Date()
    });
  }

  // Handle socket disconnection
  private handleDisconnection(socket: AuthenticatedSocket) {
    if (!socket.user) return;

    console.log(`User ${socket.user.name} disconnected`);

    // Remove from all document rooms
    for (const [documentId, room] of this.documentRooms.entries()) {
      if (room.users.has(socket.user.id)) {
        room.users.delete(socket.user.id);
        
        // Notify other users in the document
        socket.to(`document:${documentId}`).emit('user_left', {
          user: socket.user,
          timestamp: new Date()
        });

        // Clean up empty rooms
        if (room.users.size === 0) {
          this.documentRooms.delete(documentId);
        }
      }
    }

    // Remove from user sockets tracking
    this.removeUserSocket(socket);
  }

  // Verify user has access to document
  private async verifyDocumentAccess(userId: string, documentId: string): Promise<boolean> {
    try {
      const document = await prisma.document.findFirst({
        where: {
          id: documentId,
          OR: [
            { authorId: userId },
            { isPublic: true },
            {
              workspace: {
                OR: [
                  { ownerId: userId },
                  {
                    members: {
                      some: { userId }
                    }
                  }
                ]
              }
            },
            {
              access: {
                some: {
                  userId,
                  permission: { in: ['READ', 'WRITE', 'ADMIN'] }
                }
              }
            }
          ]
        }
      });

      return !!document;
    } catch (error) {
      console.error('Error verifying document access:', error);
      return false;
    }
  }

  // Get users currently viewing a document
  getDocumentUsers(documentId: string): SocketUser[] {
    const room = this.documentRooms.get(documentId);
    if (!room) return [];

    return Array.from(room.users.values()).map(u => u.user);
  }

  // Send notification to specific user
  sendToUser(userId: string, event: string, data: any) {
    const sockets = this.userSockets.get(userId);
    if (sockets) {
      sockets.forEach(socket => {
        socket.emit(event, data);
      });
    }
  }

  // Send notification to all users in a document
  sendToDocument(documentId: string, event: string, data: any) {
    this.io.to(`document:${documentId}`).emit(event, data);
  }
}

export const setupSocketHandlers = (io: Server) => {
  const socketService = new SocketService(io);
  socketService.setupHandlers();
  return socketService;
};