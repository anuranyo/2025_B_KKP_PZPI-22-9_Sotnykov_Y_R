import { Request, Response } from 'express';
import { prisma } from '../config/postgresql';
import { AppError } from '../middleware/error.middleware';
import { 
  validateData,
  updateUserSchema,
  paginationSchema,
  searchSchema
} from '../utils/validation.utils';
import { ApiResponse, UpdateUserData, PaginationQuery } from '../types';

export class UserController {
  // Get user profile
  async getProfile(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            documents: true,
            ownedWorkspaces: true,
            workspaces: true,
            activityLogs: true
          }
        }
      }
    });

    if (!user) {
      throw new AppError('User not found', 404);
    }

    const response: ApiResponse = {
      success: true,
      message: 'Profile retrieved successfully',
      data: user
    };

    res.json(response);
  }

  // Update user profile
  async updateProfile(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const updateData = validateData(updateUserSchema, req.body) as UpdateUserData;

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        updatedAt: true
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'profile_updated',
        details: updateData as any
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Profile updated successfully',
      data: updatedUser
    };

    res.json(response);
  }

  // Delete user profile
  async deleteProfile(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Check if user owns any workspaces
    const ownedWorkspaces = await prisma.workspace.count({
      where: { ownerId: userId }
    });

    if (ownedWorkspaces > 0) {
      throw new AppError('Cannot delete account while owning workspaces. Please transfer or delete workspaces first.', 400);
    }

    // Delete user (cascade will handle related records)
    await prisma.user.delete({
      where: { id: userId }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Profile deleted successfully'
    };

    res.json(response);
  }

  // Get user's workspaces
  async getUserWorkspaces(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const workspaces = await prisma.workspace.findMany({
      where: {
        OR: [
          { ownerId: userId },
          {
            members: {
              some: { userId }
            }
          }
        ]
      },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        members: {
          select: {
            id: true,
            role: true,
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          }
        },
        _count: {
          select: {
            documents: true,
            members: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Workspaces retrieved successfully',
      data: workspaces
    };

    res.json(response);
  }

  // Get user's documents
  async getUserDocuments(req: Request, res: Response) {
    const userId = req.user?.id;
    const query = validateData(paginationSchema, req.query) as PaginationQuery;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Extract additional filters from query
    const { archived, favorites } = req.query;

    const skip = (query.page! - 1) * query.limit!;

    const where: any = {
      authorId: userId
    };

    // Handle archived filter
    if (archived === 'true') {
      where.isArchived = true;
    } else if (archived === 'false') {
      where.isArchived = false;
    } else {
      // Default behavior - show non-archived documents
      where.isArchived = false;
    }

    // Handle favorites filter
    if (favorites === 'true') {
      where.isFavorite = true;
    }

    // Handle search
    if (query.search) {
      where.title = {
        contains: query.search,
        mode: 'insensitive'
      };
    }

    const [documents, total] = await Promise.all([
      prisma.document.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              avatar: true
            }
          },
          workspace: {
            select: {
              id: true,
              name: true
            }
          },
          _count: {
            select: {
              children: true
            }
          }
        },
        orderBy: {
          [query.sortBy || 'updatedAt']: query.sortOrder || 'desc'
        },
        skip,
        take: query.limit
      }),
      prisma.document.count({ where })
    ]);

    const response: ApiResponse = {
      success: true,
      message: 'Documents retrieved successfully',
      data: documents,
      pagination: {
        page: query.page!,
        limit: query.limit!,
        total,
        totalPages: Math.ceil(total / query.limit!),
        hasNextPage: skip + query.limit! < total,
        hasPrevPage: query.page! > 1
      }
    };

    res.json(response);
  }

  // Get recent documents
  async getRecentDocuments(req: Request, res: Response) {
    const userId = req.user?.id;
    const limit = parseInt(req.query.limit as string) || 10;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const documents = await prisma.document.findMany({
      where: {
        OR: [
          { authorId: userId },
          {
            workspace: {
              OR: [
                { ownerId: userId },
                {
                  members: {
                    some: { userId }
                  }
                }
              ]
            }
          }
        ],
        isArchived: false
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        workspace: {
          select: {
            id: true,
            name: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      },
      take: limit
    });

    const response: ApiResponse = {
      success: true,
      message: 'Recent documents retrieved successfully',
      data: documents
    };

    res.json(response);
  }

  // Get favorite documents
  async getFavoriteDocuments(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const documents = await prisma.document.findMany({
      where: {
        authorId: userId,
        isFavorite: true,
        isArchived: false
      },
      include: {
        workspace: {
          select: {
            id: true,
            name: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Favorite documents retrieved successfully',
      data: documents
    };

    res.json(response);
  }

  // Get user activity
  async getUserActivity(req: Request, res: Response) {
    const userId = req.user?.id;
    const query = validateData(paginationSchema, req.query) as PaginationQuery;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const skip = (query.page! - 1) * query.limit!;

    const [activities, total] = await Promise.all([
      prisma.activityLog.findMany({
        where: { userId },
        include: {
          document: {
            select: {
              id: true,
              title: true,
              workspace: {
                select: {
                  id: true,
                  name: true
                }
              }
            }
          }
        },
        orderBy: {
          timestamp: 'desc'
        },
        skip,
        take: query.limit
      }),
      prisma.activityLog.count({ where: { userId } })
    ]);

    const response: ApiResponse = {
      success: true,
      message: 'User activity retrieved successfully',
      data: activities,
      pagination: {
        page: query.page!,
        limit: query.limit!,
        total,
        totalPages: Math.ceil(total / query.limit!),
        hasNextPage: skip + query.limit! < total,
        hasPrevPage: query.page! > 1
      }
    };

    res.json(response);
  }

  // Get user settings (placeholder)
  async getUserSettings(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // TODO: Implement user settings table/storage
    const defaultSettings = {
      theme: 'light',
      language: 'en',
      notifications: {
        email: true,
        push: true,
        mentions: true,
        comments: true
      },
      editor: {
        autoSave: true,
        spellCheck: true,
        wordWrap: true
      }
    };

    const response: ApiResponse = {
      success: true,
      message: 'User settings retrieved successfully',
      data: defaultSettings
    };

    res.json(response);
  }

  // Update user settings (placeholder)
  async updateUserSettings(req: Request, res: Response) {
    const userId = req.user?.id;
    const settings = req.body;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // TODO: Implement user settings update logic
    // For now, just return the received settings

    const response: ApiResponse = {
      success: true,
      message: 'User settings updated successfully',
      data: settings
    };

    res.json(response);
  }

  // Search user content
  async searchUserContent(req: Request, res: Response) {
    const userId = req.user?.id;
    const searchData = validateData(searchSchema, req.body);

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Search in user's documents
    const documents = await prisma.document.findMany({
      where: {
        authorId: userId,
        title: {
          contains: searchData.query,
          mode: 'insensitive'
        },
        isArchived: false
      },
      include: {
        workspace: {
          select: {
            id: true,
            name: true
          }
        }
      },
      take: searchData.limit || 20,
      skip: searchData.offset || 0
    });

    // Search in workspaces user has access to
    const workspaces = await prisma.workspace.findMany({
      where: {
        OR: [
          { ownerId: userId },
          {
            members: {
              some: { userId }
            }
          }
        ],
        name: {
          contains: searchData.query,
          mode: 'insensitive'
        }
      },
      take: 10
    });

    const response: ApiResponse = {
      success: true,
      message: 'Search completed successfully',
      data: {
        documents,
        workspaces,
        query: searchData.query,
        total: documents.length + workspaces.length
      }
    };

    res.json(response);
  }

  // Get user statistics
  async getUserStats(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const [
      documentsCount,
      workspacesOwnedCount,
      workspacesMemberCount,
      favoriteDocumentsCount,
      recentActivity
    ] = await Promise.all([
      prisma.document.count({
        where: {
          authorId: userId,
          isArchived: false
        }
      }),
      prisma.workspace.count({
        where: { ownerId: userId }
      }),
      prisma.workspaceMember.count({
        where: { userId }
      }),
      prisma.document.count({
        where: {
          authorId: userId,
          isFavorite: true,
          isArchived: false
        }
      }),
      prisma.activityLog.count({
        where: {
          userId,
          timestamp: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // Last 7 days
          }
        }
      })
    ]);

    const stats = {
      documents: documentsCount,
      workspacesOwned: workspacesOwnedCount,
      workspacesMember: workspacesMemberCount,
      favoriteDocuments: favoriteDocumentsCount,
      recentActivity,
      joinedDate: req.user ? new Date() : null // Would be actual join date from user record
    };

    const response: ApiResponse = {
      success: true,
      message: 'User statistics retrieved successfully',
      data: stats
    };

    res.json(response);
  }
}