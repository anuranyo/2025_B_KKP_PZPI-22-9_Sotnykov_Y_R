import { Request, Response } from 'express';
import { prisma } from '../config/postgresql';
import { AppError } from '../middleware/error.middleware';
import { 
  hashPassword, 
  comparePassword, 
  generateAuthResponse,
  validatePasswordStrength
} from '../utils/auth.utils';
import { 
  validateData,
  registerSchema,
  loginSchema,
  changePasswordSchema
} from '../utils/validation.utils';
import type { ApiResponse, CreateUserData, LoginCredentials } from '../types';

export class AuthController {
  // Register new user
  async register(req: Request, res: Response) {
    const userData = validateData(registerSchema, req.body) as CreateUserData;

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: userData.email }
    });

    if (existingUser) {
      throw new AppError('User with this email already exists', 409);
    }

    // Validate password strength
    const passwordValidation = validatePasswordStrength(userData.password);
    if (!passwordValidation.isValid) {
      throw new AppError(`Password validation failed: ${passwordValidation.errors.join(', ')}`, 400);
    }

    // Hash password
    const hashedPassword = await hashPassword(userData.password);

    // Create user
    const user = await prisma.user.create({
      data: {
        email: userData.email,
        name: userData.name,
        password: hashedPassword,
        avatar: userData.avatar
      },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        createdAt: true,
        updatedAt: true
      }
    });

    // Generate auth response
    const authResponse = generateAuthResponse(user);

    // Log registration activity
    await prisma.activityLog.create({
      data: {
        userId: user.id,
        action: 'user_registered',
        details: {
          email: user.email,
          name: user.name
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'User registered successfully',
      data: authResponse
    };

    res.status(201).json(response);
  }

  // Login user
  async login(req: Request, res: Response) {
    const credentials = validateData(loginSchema, req.body) as LoginCredentials;

    // Find user by email
    const user = await prisma.user.findUnique({
      where: { email: credentials.email },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        password: true,
        createdAt: true,
        updatedAt: true
      }
    });

    if (!user) {
      throw new AppError('Invalid email or password', 401);
    }

    // Verify password
    const isPasswordValid = await comparePassword(credentials.password, user.password);
    if (!isPasswordValid) {
      throw new AppError('Invalid email or password', 401);
    }

    // Remove password from user object
    const { password, ...userWithoutPassword } = user;

    // Generate auth response
    const authResponse = generateAuthResponse(userWithoutPassword);

    // Log login activity
    await prisma.activityLog.create({
      data: {
        userId: user.id,
        action: 'user_login',
        details: {
          ip: req.ip,
          userAgent: req.get('User-Agent')
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Login successful',
      data: authResponse
    };

    res.json(response);
  }

  // Get current user profile
  async getProfile(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not found', 401);
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            documents: true,
            ownedWorkspaces: true,
            workspaces: true
          }
        }
      }
    });

    if (!user) {
      throw new AppError('User not found', 404);
    }

    const response: ApiResponse = {
      success: true,
      message: 'Profile retrieved successfully',
      data: user
    };

    res.json(response);
  }

  // Logout user (in a stateless JWT system, this is mainly for logging)
  async logout(req: Request, res: Response) {
    const userId = req.user?.id;

    if (userId) {
      // Log logout activity
      await prisma.activityLog.create({
        data: {
          userId,
          action: 'user_logout',
          details: {
            ip: req.ip,
            userAgent: req.get('User-Agent')
          }
        }
      });
    }

    const response: ApiResponse = {
      success: true,
      message: 'Logout successful'
    };

    res.json(response);
  }

  // Refresh token (generate new token with same payload)
  async refreshToken(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not found', 401);
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        createdAt: true,
        updatedAt: true
      }
    });

    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Generate new auth response
    const authResponse = generateAuthResponse(user);

    const response: ApiResponse = {
      success: true,
      message: 'Token refreshed successfully',
      data: authResponse
    };

    res.json(response);
  }

  // Change password
  async changePassword(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not found', 401);
    }

    const { currentPassword, newPassword } = validateData(changePasswordSchema, req.body);

    // Get current user with password
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        password: true
      }
    });

    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Verify current password
    const isCurrentPasswordValid = await comparePassword(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      throw new AppError('Current password is incorrect', 400);
    }

    // Validate new password strength
    const passwordValidation = validatePasswordStrength(newPassword);
    if (!passwordValidation.isValid) {
      throw new AppError(`Password validation failed: ${passwordValidation.errors.join(', ')}`, 400);
    }

    // Hash new password
    const hashedNewPassword = await hashPassword(newPassword);

    // Update password
    await prisma.user.update({
      where: { id: userId },
      data: { password: hashedNewPassword }
    });

    // Log password change activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'password_changed',
        details: {
          ip: req.ip,
          userAgent: req.get('User-Agent')
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Password changed successfully'
    };

    res.json(response);
  }

  // Forgot password (placeholder - would need email service)
  async forgotPassword(req: Request, res: Response) {
    const { email } = req.body;

    if (!email) {
      throw new AppError('Email is required', 400);
    }

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, email: true, name: true }
    });

    // Always return success for security (don't reveal if email exists)
    const response: ApiResponse = {
      success: true,
      message: 'If an account with that email exists, we have sent password reset instructions.'
    };

    // If user exists, you would generate a reset token and send email here
    if (user) {
      // TODO: Generate password reset token
      // TODO: Send password reset email
      
      // Log forgot password attempt
      await prisma.activityLog.create({
        data: {
          userId: user.id,
          action: 'password_reset_requested',
          details: {
            email: user.email,
            ip: req.ip
          }
        }
      });
    }

    res.json(response);
  }

  // Reset password (placeholder - would need token validation)
  async resetPassword(req: Request, res: Response) {
    const { token, newPassword } = req.body;

    if (!token || !newPassword) {
      throw new AppError('Token and new password are required', 400);
    }

    // TODO: Validate reset token
    // TODO: Find user by reset token
    // TODO: Update password

    const response: ApiResponse = {
      success: true,
      message: 'Password reset feature not implemented yet'
    };

    res.json(response);
  }
}