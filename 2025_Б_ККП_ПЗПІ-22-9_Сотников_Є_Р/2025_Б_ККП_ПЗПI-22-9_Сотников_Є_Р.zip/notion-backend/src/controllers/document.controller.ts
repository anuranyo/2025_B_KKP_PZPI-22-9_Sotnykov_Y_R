import { Request, Response } from 'express';
import { prisma } from '../config/postgresql';
import { DocumentContent } from '../models/document.model';
import { AppError } from '../middleware/error.middleware';
import { 
  validateData,
  createDocumentSchema,
  updateDocumentSchema,
  paginationSchema,
  searchSchema
} from '../utils/validation.utils';
import { ApiResponse, CreateDocumentData, UpdateDocumentData, PaginationQuery } from '../types';

export class DocumentController {
  // Create new document
  async createDocument(req: Request, res: Response) {
    const userId = req.user?.id;
    if (!userId) throw new AppError('User not authenticated', 401);

    const documentData = validateData(createDocumentSchema, req.body) as CreateDocumentData;

    // Verify user has access to workspace
    const workspace = await prisma.workspace.findFirst({
      where: {
        id: documentData.workspaceId,
        OR: [
          { ownerId: userId },
          {
            members: {
              some: {
                userId,
                role: { in: ['OWNER', 'ADMIN', 'MEMBER'] }
              }
            }
          }
        ]
      }
    });

    if (!workspace) {
      throw new AppError('Workspace not found or access denied', 403);
    }

    // Verify parent document if specified
    if (documentData.parentId) {
      const parentDoc = await prisma.document.findFirst({
        where: {
          id: documentData.parentId,
          workspaceId: documentData.workspaceId
        }
      });

      if (!parentDoc) {
        throw new AppError('Parent document not found', 404);
      }
    }

    // Create document in PostgreSQL
    const document = await prisma.document.create({
      data: {
        title: documentData.title,
        mongoId: '', // Will be updated after MongoDB creation
        isPublic: documentData.isPublic || false,
        parentId: documentData.parentId,
        authorId: userId,
        workspaceId: documentData.workspaceId
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        workspace: {
          select: {
            id: true,
            name: true
          }
        }
      }
    });

    // Create document content in MongoDB
    const documentContent = await DocumentContent.create({
      postgresql_id: document.id,
      title: documentData.title,
      blocks: [],
      versions: [],
      current_version: 1,
      last_edited_by: userId,
      created_by: userId
    });

    // Update PostgreSQL document with MongoDB ID
    const updatedDocument = await prisma.document.update({
      where: { id: document.id },
      data: { mongoId: (documentContent._id as any).toString() },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        workspace: {
          select: {
            id: true,
            name: true
          }
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        documentId: document.id,
        action: 'document_created',
        details: {
          title: documentData.title,
          workspaceId: documentData.workspaceId
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Document created successfully',
      data: updatedDocument
    };

    res.status(201).json(response);
  }

  // Get workspace documents
  async getWorkspaceDocuments(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const query = validateData(paginationSchema, req.query) as PaginationQuery;

    const skip = (query.page! - 1) * query.limit!;

    // Build where clause
    const where: any = {
      workspaceId,
      isArchived: false
    };

    if (query.search) {
      where.title = {
        contains: query.search,
        mode: 'insensitive'
      };
    }

    // Get documents with pagination
    const [documents, total] = await Promise.all([
      prisma.document.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              avatar: true
            }
          },
          _count: {
            select: {
              children: true
            }
          }
        },
        orderBy: {
          [query.sortBy || 'updatedAt']: query.sortOrder || 'desc'
        },
        skip,
        take: query.limit
      }),
      prisma.document.count({ where })
    ]);

    const response: ApiResponse = {
      success: true,
      message: 'Documents retrieved successfully',
      data: documents,
      pagination: {
        page: query.page!,
        limit: query.limit!,
        total,
        totalPages: Math.ceil(total / query.limit!),
        hasNextPage: skip + query.limit! < total,
        hasPrevPage: query.page! > 1
      }
    };

    res.json(response);
  }

  // Get single document
  async getDocument(req: Request, res: Response) {
    const { documentId } = req.params;

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        workspace: {
          select: {
            id: true,
            name: true
          }
        },
        parent: {
          select: {
            id: true,
            title: true
          }
        },
        children: {
          select: {
            id: true,
            title: true,
            updatedAt: true
          },
          where: {
            isArchived: false
          }
        }
      }
    });

    if (!document) {
      throw new AppError('Document not found', 404);
    }

    const response: ApiResponse = {
      success: true,
      message: 'Document retrieved successfully',
      data: document
    };

    res.json(response);
  }

  // Update document metadata
  async updateDocument(req: Request, res: Response) {
    const { documentId } = req.params;
    const userId = req.user?.id;
    const updateData = validateData(updateDocumentSchema, req.body) as UpdateDocumentData;

    if (!userId) throw new AppError('User not authenticated', 401);

    const document = await prisma.document.update({
      where: { id: documentId },
      data: updateData,
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        documentId,
        action: 'document_updated',
        details: updateData as any
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Document updated successfully',
      data: document
    };

    res.json(response);
  }

  // Delete document
  async deleteDocument(req: Request, res: Response) {
    const { documentId } = req.params;
    const userId = req.user?.id;

    if (!userId) throw new AppError('User not authenticated', 401);

    // Get document with MongoDB ID
    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { mongoId: true, title: true }
    });

    if (!document) {
      throw new AppError('Document not found', 404);
    }

    // Delete from MongoDB
    if (document.mongoId) {
      await DocumentContent.findByIdAndDelete(document.mongoId);
    }

    // Delete from PostgreSQL (cascade will handle related records)
    await prisma.document.delete({
      where: { id: documentId }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'document_deleted',
        details: {
          documentId,
          title: document.title
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Document deleted successfully'
    };

    res.json(response);
  }

  // Get document content from MongoDB
  async getDocumentContent(req: Request, res: Response) {
    const { documentId } = req.params;

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { mongoId: true }
    });

    if (!document || !document.mongoId) {
      throw new AppError('Document content not found', 404);
    }

    const content = await DocumentContent.findById(document.mongoId);

    if (!content) {
      throw new AppError('Document content not found', 404);
    }

    const response: ApiResponse = {
      success: true,
      message: 'Document content retrieved successfully',
      data: content
    };

    res.json(response);
  }

  // Update document content in MongoDB - ИСПРАВЛЕНА
  async updateDocumentContent(req: Request, res: Response) {
    const { documentId } = req.params;
    const userId = req.user?.id;
    
    console.log('=== UPDATE DOCUMENT CONTENT ===');
    console.log('Document ID:', documentId);
    console.log('User ID:', userId);
    console.log('Request body:', JSON.stringify(req.body, null, 2));
    
    if (!userId) throw new AppError('User not authenticated', 401);

    // Убираем валидацию схемы пока что, или используем простую проверку
    const contentData = req.body;
    
    // Базовая валидация
    if (!contentData || typeof contentData !== 'object') {
      console.error('Invalid content data:', contentData);
      throw new AppError('Invalid content data', 400);
    }

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { mongoId: true, title: true }
    });

    console.log('Found document:', document);

    if (!document || !document.mongoId) {
      console.error('Document not found or no mongoId');
      throw new AppError('Document not found', 404);
    }

    // Подготавливаем данные для обновления
    const updateData: any = {
      last_edited_time: new Date(),
      last_edited_by: userId,
    };

    // Добавляем переданные поля
    if (contentData.title) updateData.title = contentData.title;
    if (contentData.blocks) updateData.blocks = contentData.blocks;
    if (contentData.icon) updateData.icon = contentData.icon;
    if (contentData.cover) updateData.cover = contentData.cover;

    console.log('Update data for MongoDB:', JSON.stringify(updateData, null, 2));

    try {
      // Update content in MongoDB
      const updatedContent = await DocumentContent.findByIdAndUpdate(
        document.mongoId,
        updateData,
        { new: true, runValidators: true }
      );

      console.log('MongoDB update result:', updatedContent ? 'SUCCESS' : 'FAILED');

      if (!updatedContent) {
        throw new AppError('Failed to update document content', 500);
      }

      // Update PostgreSQL document timestamp and title if changed
      const pgUpdateData: any = { 
        updatedAt: new Date()
      };
      
      if (contentData.title && contentData.title !== document.title) {
        pgUpdateData.title = contentData.title;
      }

      console.log('Updating PostgreSQL with:', pgUpdateData);

      await prisma.document.update({
        where: { id: documentId },
        data: pgUpdateData
      });

      console.log('PostgreSQL update: SUCCESS');

      // Log activity
      await prisma.activityLog.create({
        data: {
          userId,
          documentId,
          action: 'document_content_updated',
          details: {
            blocksCount: contentData.blocks?.length || 0,
            hasTitle: !!contentData.title,
            hasIcon: !!contentData.icon,
            hasCover: !!contentData.cover
          }
        }
      });

      console.log('Activity log created: SUCCESS');
      console.log('=== UPDATE COMPLETE ===');

      const response: ApiResponse = {
        success: true,
        message: 'Document content updated successfully',
        data: updatedContent
      };

      res.json(response);
      
    } catch (error: any) {
      console.error('=== UPDATE ERROR ===');
      console.error('Error details:', error);
      console.error('Error name:', error.name);
      console.error('Error message:', error.message);
      console.error('Stack trace:', error.stack);
      
      if (error.name === 'ValidationError') {
        console.error('Validation errors:', error.errors);
        throw new AppError(`Validation error: ${error.message}`, 400);
      }
      
      if (error.name === 'CastError') {
        console.error('Cast error details:', error);
        throw new AppError('Invalid document ID format', 400);
      }
      
      console.error('=== THROWING GENERIC ERROR ===');
      throw new AppError('Failed to update document content', 500);
    }
  }

  // Get child documents
  async getChildDocuments(req: Request, res: Response) {
    const { documentId } = req.params;

    const children = await prisma.document.findMany({
      where: {
        parentId: documentId,
        isArchived: false
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Child documents retrieved successfully',
      data: children
    };

    res.json(response);
  }

  // Toggle favorite
  async toggleFavorite(req: Request, res: Response) {
    const { documentId } = req.params;
    const userId = req.user?.id;

    if (!userId) throw new AppError('User not authenticated', 401);

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { isFavorite: true }
    });

    if (!document) {
      throw new AppError('Document not found', 404);
    }

    const updatedDocument = await prisma.document.update({
      where: { id: documentId },
      data: { isFavorite: !document.isFavorite }
    });

    const response: ApiResponse = {
      success: true,
      message: `Document ${updatedDocument.isFavorite ? 'added to' : 'removed from'} favorites`,
      data: { isFavorite: updatedDocument.isFavorite }
    };

    res.json(response);
  }

  // Toggle archive
  async toggleArchive(req: Request, res: Response) {
    const { documentId } = req.params;
    const userId = req.user?.id;

    if (!userId) throw new AppError('User not authenticated', 401);

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { isArchived: true }
    });

    if (!document) {
      throw new AppError('Document not found', 404);
    }

    const updatedDocument = await prisma.document.update({
      where: { id: documentId },
      data: { isArchived: !document.isArchived }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        documentId,
        action: updatedDocument.isArchived ? 'document_archived' : 'document_unarchived'
      }
    });

    const response: ApiResponse = {
      success: true,
      message: `Document ${updatedDocument.isArchived ? 'archived' : 'unarchived'} successfully`,
      data: { isArchived: updatedDocument.isArchived }
    };

    res.json(response);
  }

  // Search documents (placeholder - would use full-text search in production)
  async searchDocuments(req: Request, res: Response) {
    const searchData = validateData(searchSchema, req.body);
    const userId = req.user?.id;

    if (!userId) throw new AppError('User not authenticated', 401);

    // Search in PostgreSQL documents
    const documents = await prisma.document.findMany({
      where: {
        AND: [
          {
            OR: [
              { authorId: userId },
              { isPublic: true },
              {
                workspace: {
                  OR: [
                    { ownerId: userId },
                    {
                      members: {
                        some: { userId }
                      }
                    }
                  ]
                }
              }
            ]
          },
          {
            title: {
              contains: searchData.query,
              mode: 'insensitive'
            }
          },
          ...(searchData.workspaceId ? [{ workspaceId: searchData.workspaceId }] : []),
          { isArchived: false }
        ]
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        workspace: {
          select: {
            id: true,
            name: true
          }
        }
      },
      take: searchData.limit,
      skip: searchData.offset
    });

    const response: ApiResponse = {
      success: true,
      message: 'Search completed successfully',
      data: {
        results: documents,
        total: documents.length,
        query: searchData.query
      }
    };

    res.json(response);
  }

  // Placeholder methods remain the same...
  async moveDocument(req: Request, res: Response) {
    throw new AppError('Move document feature not implemented yet', 501);
  }

  async duplicateDocument(req: Request, res: Response) {
    throw new AppError('Duplicate document feature not implemented yet', 501);
  }

  async getDocumentAccess(req: Request, res: Response) {
    throw new AppError('Document access management not implemented yet', 501);
  }

  async grantDocumentAccess(req: Request, res: Response) {
    throw new AppError('Document access management not implemented yet', 501);
  }

  async updateDocumentAccess(req: Request, res: Response) {
    throw new AppError('Document access management not implemented yet', 501);
  }

  async revokeDocumentAccess(req: Request, res: Response) {
    throw new AppError('Document access management not implemented yet', 501);
  }

  async getDocumentVersions(req: Request, res: Response) {
    throw new AppError('Document versions not implemented yet', 501);
  }

  async getDocumentVersion(req: Request, res: Response) {
    throw new AppError('Document versions not implemented yet', 501);
  }

  async createDocumentVersion(req: Request, res: Response) {
    throw new AppError('Document versions not implemented yet', 501);
  }

  async getDocumentActivity(req: Request, res: Response) {
    throw new AppError('Document activity not implemented yet', 501);
  }

  async bulkDeleteDocuments(req: Request, res: Response) {
    throw new AppError('Bulk operations not implemented yet', 501);
  }

  async bulkArchiveDocuments(req: Request, res: Response) {
    throw new AppError('Bulk operations not implemented yet', 501);
  }

  async bulkMoveDocuments(req: Request, res: Response) {
    throw new AppError('Bulk operations not implemented yet', 501);
  }
}