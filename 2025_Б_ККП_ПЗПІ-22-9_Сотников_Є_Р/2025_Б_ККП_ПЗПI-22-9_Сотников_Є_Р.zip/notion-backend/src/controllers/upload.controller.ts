import { Request, Response } from 'express';
import { uploadToCloudinary, deleteFromCloudinary } from '../config/cloudinary';
import { AppError } from '../middleware/error.middleware';
import { validateData, uploadSchema } from '../utils/validation.utils';
import { ApiResponse, UploadResponse } from '../types';

export class UploadController {
  // Upload single file
  async uploadSingle(req: Request, res: Response) {
    const file = req.file;
    
    if (!file) {
      throw new AppError('No file provided', 400);
    }

    const options = validateData(uploadSchema, req.body);

    try {
      const result = await uploadToCloudinary(file.buffer, {
        folder: options.folder || 'notion-app/general',
        public_id: options.public_id,
        resource_type: options.resource_type || 'auto',
        allowed_formats: options.allowed_formats,
        max_file_size: options.max_file_size || 10 * 1024 * 1024
      });

      const uploadResponse: UploadResponse = {
        success: true,
        file: result
      };

      const response: ApiResponse = {
        success: true,
        message: 'File uploaded successfully',
        data: uploadResponse
      };

      res.json(response);
    } catch (error) {
      console.error('Upload Error:', error);
      throw new AppError('Failed to upload file', 500);
    }
  }

  // Upload multiple files
  async uploadMultiple(req: Request, res: Response) {
    const files = req.files as Express.Multer.File[];
    
    if (!files || files.length === 0) {
      throw new AppError('No files provided', 400);
    }

    if (files.length > 5) {
      throw new AppError('Maximum 5 files allowed per request', 400);
    }

    const options = validateData(uploadSchema, req.body);

    try {
      const uploadPromises = files.map((file, index) => 
        uploadToCloudinary(file.buffer, {
          folder: options.folder || 'notion-app/general',
          public_id: options.public_id ? `${options.public_id}_${index}` : undefined,
          resource_type: options.resource_type || 'auto',
          allowed_formats: options.allowed_formats,
          max_file_size: options.max_file_size || 10 * 1024 * 1024
        })
      );

      const results = await Promise.all(uploadPromises);

      const response: ApiResponse = {
        success: true,
        message: `${results.length} files uploaded successfully`,
        data: {
          files: results,
          count: results.length
        }
      };

      res.json(response);
    } catch (error) {
      console.error('Multiple Upload Error:', error);
      throw new AppError('Failed to upload files', 500);
    }
  }

  // Upload image with optimization
  async uploadImage(req: Request, res: Response) {
    const file = req.file;
    
    if (!file) {
      throw new AppError('No image provided', 400);
    }

    // Validate image type
    if (!file.mimetype.startsWith('image/')) {
      throw new AppError('File must be an image', 400);
    }

    try {
      const result = await uploadToCloudinary(file.buffer, {
        folder: 'notion-app/images',
        resource_type: 'image',
        allowed_formats: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        max_file_size: 5 * 1024 * 1024 // 5MB for images
      });

      const response: ApiResponse = {
        success: true,
        message: 'Image uploaded successfully',
        data: { file: result }
      };

      res.json(response);
    } catch (error) {
      console.error('Image Upload Error:', error);
      throw new AppError('Failed to upload image', 500);
    }
  }

  // Upload avatar with specific constraints
  async uploadAvatar(req: Request, res: Response) {
    const file = req.file;
    const userId = req.user?.id;
    
    if (!file) {
      throw new AppError('No avatar image provided', 400);
    }

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Validate image type
    if (!file.mimetype.startsWith('image/')) {
      throw new AppError('Avatar must be an image', 400);
    }

    try {
      const result = await uploadToCloudinary(file.buffer, {
        folder: 'notion-app/avatars',
        public_id: `avatar_${userId}`,
        resource_type: 'image',
        allowed_formats: ['jpg', 'jpeg', 'png'],
        max_file_size: 2 * 1024 * 1024 // 2MB for avatars
      });

      // TODO: Update user avatar in database
      // await prisma.user.update({
      //   where: { id: userId },
      //   data: { avatar: result.url }
      // });

      const response: ApiResponse = {
        success: true,
        message: 'Avatar uploaded successfully',
        data: { file: result }
      };

      res.json(response);
    } catch (error) {
      console.error('Avatar Upload Error:', error);
      throw new AppError('Failed to upload avatar', 500);
    }
  }

  // Upload document attachment
  async uploadDocumentAttachment(req: Request, res: Response) {
    const file = req.file;
    const { documentId } = req.body;
    
    if (!file) {
      throw new AppError('No attachment provided', 400);
    }

    if (!documentId) {
      throw new AppError('Document ID is required', 400);
    }

    try {
      const result = await uploadToCloudinary(file.buffer, {
        folder: `notion-app/documents/${documentId}/attachments`,
        resource_type: 'auto',
        max_file_size: 10 * 1024 * 1024 // 10MB for attachments
      });

      // TODO: Log attachment to document in database
      // await prisma.activityLog.create({
      //   data: {
      //     userId: req.user?.id,
      //     documentId,
      //     action: 'attachment_added',
      //     details: {
      //       fileName: file.originalname,
      //       fileSize: file.size,
      //       fileUrl: result.url
      //     }
      //   }
      // });

      const response: ApiResponse = {
        success: true,
        message: 'Document attachment uploaded successfully',
        data: { 
          file: result,
          documentId,
          fileName: file.originalname
        }
      };

      res.json(response);
    } catch (error) {
      console.error('Document Attachment Upload Error:', error);
      throw new AppError('Failed to upload document attachment', 500);
    }
  }

  // Delete uploaded file
  async deleteFile(req: Request, res: Response) {
    const { publicId } = req.params;
    
    if (!publicId) {
      throw new AppError('Public ID is required', 400);
    }

    try {
      await deleteFromCloudinary(publicId);

      const response: ApiResponse = {
        success: true,
        message: 'File deleted successfully'
      };

      res.json(response);
    } catch (error) {
      console.error('Delete File Error:', error);
      throw new AppError('Failed to delete file', 500);
    }
  }

  // Get signed upload URL for direct client uploads
  async getSignedUploadUrl(req: Request, res: Response) {
    const { folder, resourceType = 'auto' } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    try {
      // Generate timestamp and signature for direct upload
      const timestamp = Math.round(new Date().getTime() / 1000);
      const uploadParams = {
        timestamp,
        folder: folder || 'notion-app/temp',
        resource_type: resourceType,
        ...(userId && { public_id: `user_${userId}_${timestamp}` })
      };

      // TODO: Generate signature using Cloudinary SDK
      // const signature = cloudinary.utils.api_sign_request(uploadParams, cloudinaryConfig.api_secret);

      const response: ApiResponse = {
        success: true,
        message: 'Signed upload URL generated',
        data: {
          uploadUrl: `https://api.cloudinary.com/v1_1/${process.env.CLOUDINARY_CLOUD_NAME}/${resourceType}/upload`,
          uploadParams,
          // signature,
          apiKey: process.env.CLOUDINARY_API_KEY
        }
      };

      res.json(response);
    } catch (error) {
      console.error('Signed URL Error:', error);
      throw new AppError('Failed to generate signed upload URL', 500);
    }
  }
}