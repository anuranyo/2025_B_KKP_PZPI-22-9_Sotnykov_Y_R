import { Request, Response } from 'express';
import { aiService } from '../services/ai.service';
import { AppError } from '../middleware/error.middleware';
import { validateData, aiGenerateSchema } from '../utils/validation.utils';
import { ApiResponse, AIGenerateRequest } from '../types';

export class AIController {
  // Generate content using AI
  async generateContent(req: Request, res: Response) {
    const generateData = validateData(aiGenerateSchema, req.body) as AIGenerateRequest;

    try {
      const result = await aiService.generateContent(generateData);

      const response: ApiResponse = {
        success: true,
        message: 'Content generated successfully',
        data: result
      };

      res.json(response);
    } catch (error) {
      console.error('AI Generate Error:', error);
      throw new AppError('Failed to generate content', 500);
    }
  }

  // Complete text
  async completeText(req: Request, res: Response) {
    const { prompt, context } = req.body;

    if (!prompt) {
      throw new AppError('Prompt is required', 400);
    }

    try {
      const result = await aiService.completeText(prompt, context);

      const response: ApiResponse = {
        success: true,
        message: 'Text completed successfully',
        data: { content: result }
      };

      res.json(response);
    } catch (error) {
      console.error('AI Complete Error:', error);
      throw new AppError('Failed to complete text', 500);
    }
  }

  // Improve text
  async improveText(req: Request, res: Response) {
    const { text, instructions } = req.body;

    if (!text) {
      throw new AppError('Text is required', 400);
    }

    try {
      const result = await aiService.improveText(text, instructions);

      const response: ApiResponse = {
        success: true,
        message: 'Text improved successfully',
        data: { content: result }
      };

      res.json(response);
    } catch (error) {
      console.error('AI Improve Error:', error);
      throw new AppError('Failed to improve text', 500);
    }
  }

  // Summarize text
  async summarizeText(req: Request, res: Response) {
    const { text, length = 'medium' } = req.body;

    if (!text) {
      throw new AppError('Text is required', 400);
    }

    if (!['short', 'medium', 'long'].includes(length)) {
      throw new AppError('Length must be short, medium, or long', 400);
    }

    try {
      const result = await aiService.summarizeText(text, length);

      const response: ApiResponse = {
        success: true,
        message: 'Text summarized successfully',
        data: { content: result, length }
      };

      res.json(response);
    } catch (error) {
      console.error('AI Summarize Error:', error);
      throw new AppError('Failed to summarize text', 500);
    }
  }

  // Translate text
  async translateText(req: Request, res: Response) {
    const { text, targetLanguage, sourceLanguage } = req.body;

    if (!text || !targetLanguage) {
      throw new AppError('Text and target language are required', 400);
    }

    try {
      const result = await aiService.translateText(text, targetLanguage, sourceLanguage);

      const response: ApiResponse = {
        success: true,
        message: 'Text translated successfully',
        data: { 
          content: result,
          sourceLanguage,
          targetLanguage
        }
      };

      res.json(response);
    } catch (error) {
      console.error('AI Translate Error:', error);
      throw new AppError('Failed to translate text', 500);
    }
  }

  // Brainstorm ideas
  async brainstorm(req: Request, res: Response) {
    const { topic, count = 5 } = req.body;

    if (!topic) {
      throw new AppError('Topic is required', 400);
    }

    if (count < 1 || count > 20) {
      throw new AppError('Count must be between 1 and 20', 400);
    }

    try {
      const ideas = await aiService.brainstorm(topic, count);

      const response: ApiResponse = {
        success: true,
        message: 'Ideas generated successfully',
        data: { 
          ideas,
          topic,
          count: ideas.length
        }
      };

      res.json(response);
    } catch (error) {
      console.error('AI Brainstorm Error:', error);
      throw new AppError('Failed to generate ideas', 500);
    }
  }

  // Generate outline
  async generateOutline(req: Request, res: Response) {
    const { topic, depth = 'basic' } = req.body;

    if (!topic) {
      throw new AppError('Topic is required', 400);
    }

    if (!['basic', 'detailed'].includes(depth)) {
      throw new AppError('Depth must be basic or detailed', 400);
    }

    try {
      const outline = await aiService.generateOutline(topic, depth);

      const response: ApiResponse = {
        success: true,
        message: 'Outline generated successfully',
        data: { 
          content: outline,
          topic,
          depth
        }
      };

      res.json(response);
    } catch (error) {
      console.error('AI Outline Error:', error);
      throw new AppError('Failed to generate outline', 500);
    }
  }

  // Health check for AI service
  async healthCheck(req: Request, res: Response) {
    try {
      const isHealthy = await aiService.healthCheck();

      const response: ApiResponse = {
        success: isHealthy,
        message: isHealthy ? 'AI service is healthy' : 'AI service is unavailable',
        data: {
          status: isHealthy ? 'healthy' : 'unhealthy',
          timestamp: new Date().toISOString()
        }
      };

      res.status(isHealthy ? 200 : 503).json(response);
    } catch (error) {
      console.error('AI Health Check Error:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'AI service health check failed',
        data: {
          status: 'error',
          timestamp: new Date().toISOString()
        }
      };

      res.status(503).json(response);
    }
  }
}