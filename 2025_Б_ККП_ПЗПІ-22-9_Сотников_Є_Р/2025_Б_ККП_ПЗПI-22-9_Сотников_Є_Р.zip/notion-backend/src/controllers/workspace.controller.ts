import { Request, Response } from 'express';
import { prisma } from '../config/postgresql';
import { AppError } from '../middleware/error.middleware';
import { 
  validateData,
  createWorkspaceSchema,
  updateWorkspaceSchema,
  inviteMemberSchema,
  updateMemberRoleSchema,
  paginationSchema
} from '../utils/validation.utils';
import { ApiResponse, CreateWorkspaceData, UpdateWorkspaceData, InviteMemberData, PaginationQuery } from '../types';

export class WorkspaceController {
  // Create new workspace
  async createWorkspace(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const workspaceData = validateData(createWorkspaceSchema, req.body) as CreateWorkspaceData;

    const workspace = await prisma.workspace.create({
      data: {
        name: workspaceData.name,
        description: workspaceData.description,
        icon: workspaceData.icon,
        isPublic: workspaceData.isPublic || false,
        ownerId: userId
      },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        _count: {
          select: {
            members: true,
            documents: true
          }
        }
      }
    });

    // Add creator as workspace member with OWNER role
    await prisma.workspaceMember.create({
      data: {
        userId,
        workspaceId: workspace.id,
        role: 'OWNER'
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'workspace_created',
        details: {
          workspaceId: workspace.id,
          workspaceName: workspace.name
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Workspace created successfully',
      data: workspace
    };

    res.status(201).json(response);
  }

  // Get user's workspaces
  async getUserWorkspaces(req: Request, res: Response) {
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const workspaces = await prisma.workspace.findMany({
      where: {
        OR: [
          { ownerId: userId },
          {
            members: {
              some: { userId }
            }
          }
        ]
      },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        members: {
          where: { userId },
          select: {
            role: true
          }
        },
        _count: {
          select: {
            members: true,
            documents: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Workspaces retrieved successfully',
      data: workspaces
    };

    res.json(response);
  }

  // Get single workspace
  async getWorkspace(req: Request, res: Response) {
    const { workspaceId } = req.params;

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true
              }
            }
          }
        },
        _count: {
          select: {
            documents: true
          }
        }
      }
    });

    if (!workspace) {
      throw new AppError('Workspace not found', 404);
    }

    const response: ApiResponse = {
      success: true,
      message: 'Workspace retrieved successfully',
      data: workspace
    };

    res.json(response);
  }

  // Update workspace
  async updateWorkspace(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const userId = req.user?.id;
    const updateData = validateData(updateWorkspaceSchema, req.body) as UpdateWorkspaceData;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const workspace = await prisma.workspace.update({
      where: { id: workspaceId },
      data: updateData,
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        _count: {
          select: {
            members: true,
            documents: true
          }
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'workspace_updated',
        details: {
          workspaceId,
          changes: updateData as any // Cast to any to avoid type issues
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Workspace updated successfully',
      data: workspace
    };

    res.json(response);
  }

  // Delete workspace
  async deleteWorkspace(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Check if workspace has documents
    const documentsCount = await prisma.document.count({
      where: { workspaceId }
    });

    if (documentsCount > 0) {
      throw new AppError('Cannot delete workspace with documents. Please delete all documents first.', 400);
    }

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      select: { name: true }
    });

    // Delete workspace (cascade will handle members)
    await prisma.workspace.delete({
      where: { id: workspaceId }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'workspace_deleted',
        details: {
          workspaceId,
          workspaceName: workspace?.name
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Workspace deleted successfully'
    };

    res.json(response);
  }

  // Get workspace members
  async getWorkspaceMembers(req: Request, res: Response) {
    const { workspaceId } = req.params;

    const members = await prisma.workspaceMember.findMany({
      where: { workspaceId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      },
      orderBy: [
        { role: 'asc' },
        { joinedAt: 'asc' }
      ]
    });

    const response: ApiResponse = {
      success: true,
      message: 'Workspace members retrieved successfully',
      data: members
    };

    res.json(response);
  }

  // Invite member to workspace
  async inviteMember(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const userId = req.user?.id;
    const inviteData = validateData(inviteMemberSchema, req.body) as InviteMemberData;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Find user by email
    const user = await prisma.user.findUnique({
      where: { email: inviteData.email },
      select: {
        id: true,
        name: true,
        email: true
      }
    });

    if (!user) {
      throw new AppError('User with this email not found', 404);
    }

    // Check if user is already a member
    const existingMember = await prisma.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId: user.id,
          workspaceId
        }
      }
    });

    if (existingMember) {
      throw new AppError('User is already a member of this workspace', 409);
    }

    // Add member to workspace
    const member = await prisma.workspaceMember.create({
      data: {
        userId: user.id,
        workspaceId,
        role: inviteData.role
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'member_invited',
        details: {
          workspaceId,
          invitedUserId: user.id,
          invitedUserEmail: user.email,
          role: inviteData.role
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Member invited successfully',
      data: member
    };

    res.json(response);
  }

  // Update member role
  async updateMemberRole(req: Request, res: Response) {
    const { workspaceId, userId: targetUserId } = req.params;
    const currentUserId = req.user?.id;

    // Check for OWNER before validation to avoid type error
    if (req.body.role === 'OWNER') {
      throw new AppError('Cannot assign OWNER role. Use transfer ownership instead.', 400);
    }

    const { role } = validateData(updateMemberRoleSchema, req.body);

    if (!currentUserId) {
      throw new AppError('User not authenticated', 401);
    }

    // Get current member
    const member = await prisma.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId: targetUserId,
          workspaceId
        }
      }
    });

    if (!member) {
      throw new AppError('Member not found', 404);
    }

    // Cannot change owner's role
    if (member.role === 'OWNER') {
      throw new AppError('Cannot change workspace owner role', 400);
    }

    // Update member role
    const updatedMember = await prisma.workspaceMember.update({
      where: {
        userId_workspaceId: {
          userId: targetUserId,
          workspaceId
        }
      },
      data: { role },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId: currentUserId,
        action: 'member_role_updated',
        details: {
          workspaceId,
          targetUserId,
          oldRole: member.role,
          newRole: role
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Member role updated successfully',
      data: updatedMember
    };

    res.json(response);
  }

  // Remove member from workspace
  async removeMember(req: Request, res: Response) {
    const { workspaceId, userId: targetUserId } = req.params;
    const currentUserId = req.user?.id;

    if (!currentUserId) {
      throw new AppError('User not authenticated', 401);
    }

    // Get member to be removed
    const member = await prisma.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId: targetUserId,
          workspaceId
        }
      },
      include: {
        user: {
          select: {
            name: true,
            email: true
          }
        }
      }
    });

    if (!member) {
      throw new AppError('Member not found', 404);
    }

    // Cannot remove workspace owner
    if (member.role === 'OWNER') {
      throw new AppError('Cannot remove workspace owner', 400);
    }

    // Remove member
    await prisma.workspaceMember.delete({
      where: {
        userId_workspaceId: {
          userId: targetUserId,
          workspaceId
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId: currentUserId,
        action: 'member_removed',
        details: {
          workspaceId,
          removedUserId: targetUserId,
          removedUserEmail: member.user.email
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Member removed successfully'
    };

    res.json(response);
  }

  // Join public workspace
  async joinWorkspace(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    // Check if workspace is public
    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      select: {
        isPublic: true,
        name: true
      }
    });

    if (!workspace) {
      throw new AppError('Workspace not found', 404);
    }

    if (!workspace.isPublic) {
      throw new AppError('This workspace is not public', 403);
    }

    // Check if already a member
    const existingMember = await prisma.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId,
          workspaceId
        }
      }
    });

    if (existingMember) {
      throw new AppError('You are already a member of this workspace', 409);
    }

    // Join workspace as MEMBER
    const member = await prisma.workspaceMember.create({
      data: {
        userId,
        workspaceId,
        role: 'MEMBER'
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'workspace_joined',
        details: {
          workspaceId,
          workspaceName: workspace.name
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Joined workspace successfully',
      data: member
    };

    res.json(response);
  }

  // Leave workspace
  async leaveWorkspace(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const userId = req.user?.id;

    if (!userId) {
      throw new AppError('User not authenticated', 401);
    }

    const member = await prisma.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId,
          workspaceId
        }
      }
    });

    if (!member) {
      throw new AppError('You are not a member of this workspace', 404);
    }

    // Workspace owner cannot leave (must transfer ownership first)
    if (member.role === 'OWNER') {
      throw new AppError('Workspace owner cannot leave. Transfer ownership first.', 400);
    }

    // Remove membership
    await prisma.workspaceMember.delete({
      where: {
        userId_workspaceId: {
          userId,
          workspaceId
        }
      }
    });

    // Log activity
    await prisma.activityLog.create({
      data: {
        userId,
        action: 'workspace_left',
        details: {
          workspaceId
        }
      }
    });

    const response: ApiResponse = {
      success: true,
      message: 'Left workspace successfully'
    };

    res.json(response);
  }

  // Get workspace documents
  async getWorkspaceDocuments(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const query = validateData(paginationSchema, req.query) as PaginationQuery;

    const skip = (query.page! - 1) * query.limit!;

    const where: any = {
      workspaceId,
      isArchived: false
    };

    if (query.search) {
      where.title = {
        contains: query.search,
        mode: 'insensitive'
      };
    }

    const [documents, total] = await Promise.all([
      prisma.document.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              avatar: true
            }
          },
          _count: {
            select: {
              children: true
            }
          }
        },
        orderBy: {
          [query.sortBy || 'updatedAt']: query.sortOrder || 'desc'
        },
        skip,
        take: query.limit
      }),
      prisma.document.count({ where })
    ]);

    const response: ApiResponse = {
      success: true,
      message: 'Workspace documents retrieved successfully',
      data: documents,
      pagination: {
        page: query.page!,
        limit: query.limit!,
        total,
        totalPages: Math.ceil(total / query.limit!),
        hasNextPage: skip + query.limit! < total,
        hasPrevPage: query.page! > 1
      }
    };

    res.json(response);
  }

  // Get recent workspace documents
  async getRecentWorkspaceDocuments(req: Request, res: Response) {
    const { workspaceId } = req.params;
    const limit = parseInt(req.query.limit as string) || 10;

    const documents = await prisma.document.findMany({
      where: {
        workspaceId,
        isArchived: false
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      },
      take: limit
    });

    const response: ApiResponse = {
      success: true,
      message: 'Recent workspace documents retrieved successfully',
      data: documents
    };

    res.json(response);
  }

  // Get public workspaces
  async getPublicWorkspaces(req: Request, res: Response) {
    const query = validateData(paginationSchema, req.query) as PaginationQuery;
    const skip = (query.page! - 1) * query.limit!;

    const where: any = {
      isPublic: true
    };

    if (query.search) {
      where.name = {
        contains: query.search,
        mode: 'insensitive'
      };
    }

    const [workspaces, total] = await Promise.all([
      prisma.workspace.findMany({
        where,
        include: {
          owner: {
            select: {
              id: true,
              name: true,
              avatar: true
            }
          },
          _count: {
            select: {
              members: true,
              documents: true
            }
          }
        },
        orderBy: {
          [query.sortBy || 'updatedAt']: query.sortOrder || 'desc'
        },
        skip,
        take: query.limit
      }),
      prisma.workspace.count({ where })
    ]);

    const response: ApiResponse = {
      success: true,
      message: 'Public workspaces retrieved successfully',
      data: workspaces,
      pagination: {
        page: query.page!,
        limit: query.limit!,
        total,
        totalPages: Math.ceil(total / query.limit!),
        hasNextPage: skip + query.limit! < total,
        hasPrevPage: query.page! > 1
      }
    };

    res.json(response);
  }

  // Placeholder methods for additional features
  async getWorkspaceActivity(req: Request, res: Response) {
    throw new AppError('Workspace activity feature not implemented yet', 501);
  }

  async getWorkspaceSettings(req: Request, res: Response) {
    throw new AppError('Workspace settings feature not implemented yet', 501);
  }

  async updateWorkspaceSettings(req: Request, res: Response) {
    throw new AppError('Workspace settings feature not implemented yet', 501);
  }

  async transferOwnership(req: Request, res: Response) {
    throw new AppError('Transfer ownership feature not implemented yet', 501);
  }

  async duplicateWorkspace(req: Request, res: Response) {
    throw new AppError('Duplicate workspace feature not implemented yet', 501);
  }
}