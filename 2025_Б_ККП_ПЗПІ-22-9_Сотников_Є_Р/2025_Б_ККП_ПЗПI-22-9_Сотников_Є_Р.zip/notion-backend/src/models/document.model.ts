import mongoose, { Schema, Document } from 'mongoose';

// Block types for different content
export enum BlockType {
  PARAGRAPH = 'paragraph',
  HEADING_1 = 'heading_1',
  HEADING_2 = 'heading_2',
  HEADING_3 = 'heading_3',
  BULLETED_LIST = 'bulleted_list',
  NUMBERED_LIST = 'numbered_list',
  TODO = 'todo',
  TOGGLE = 'toggle',
  CODE = 'code',
  QUOTE = 'quote',
  DIVIDER = 'divider',
  IMAGE = 'image',
  VIDEO = 'video',
  FILE = 'file',
  EMBED = 'embed',
  TABLE = 'table',
  COLUMN_LIST = 'column_list',
  COLUMN = 'column'
}

// Text annotation interface
export interface TextAnnotation {
  bold?: boolean;
  italic?: boolean;
  strikethrough?: boolean;
  underline?: boolean;
  code?: boolean;
  color?: string;
  href?: string;
}

// Rich text interface
export interface RichText {
  type: 'text' | 'mention' | 'equation';
  text?: {
    content: string;
    link?: { url: string };
  };
  mention?: {
    type: 'user' | 'page' | 'database';
    user?: { id: string };
    page?: { id: string };
  };
  equation?: {
    expression: string;
  };
  annotations: TextAnnotation;
  plain_text: string;
  href?: string;
}

// Block content interface
export interface BlockContent {
  id: string;
  type: BlockType;
  created_time: Date;
  last_edited_time: Date;
  archived: boolean;
  has_children: boolean;
  parent_id?: string;
  
  // Content based on block type
  paragraph?: {
    rich_text: RichText[];
    color: string;
  };
  heading_1?: {
    rich_text: RichText[];
    color: string;
    is_toggleable: boolean;
  };
  heading_2?: {
    rich_text: RichText[];
    color: string;
    is_toggleable: boolean;
  };
  heading_3?: {
    rich_text: RichText[];
    color: string;
    is_toggleable: boolean;
  };
  bulleted_list_item?: {
    rich_text: RichText[];
    color: string;
  };
  numbered_list_item?: {
    rich_text: RichText[];
    color: string;
  };
  to_do?: {
    rich_text: RichText[];
    checked: boolean;
    color: string;
  };
  toggle?: {
    rich_text: RichText[];
    color: string;
  };
  code?: {
    rich_text: RichText[];
    language: string;
    caption: RichText[];
  };
  quote?: {
    rich_text: RichText[];
    color: string;
  };
  image?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string; expiry_time: Date };
    caption: RichText[];
  };
  video?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string; expiry_time: Date };
    caption: RichText[];
  };
  file?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string; expiry_time: Date };
    caption: RichText[];
    name: string;
  };
  embed?: {
    url: string;
    caption: RichText[];
  };
  table?: {
    table_width: number;
    has_column_header: boolean;
    has_row_header: boolean;
  };
}

// Document version interface
export interface DocumentVersion {
  id: string;
  version_number: number;
  title: string;
  blocks: BlockContent[];
  created_at: Date;
  created_by: string;
  change_summary?: string;
}

// Main document interface
export interface IDocumentContent extends Document {
  postgresql_id: string; // Reference to PostgreSQL document
  title: string;
  icon?: {
    type: 'emoji' | 'file' | 'external';
    emoji?: string;
    file?: { url: string };
    external?: { url: string };
  };
  cover?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string };
  };
  blocks: BlockContent[];
  versions: DocumentVersion[];
  current_version: number;
  last_edited_time: Date;
  last_edited_by: string;
  created_time: Date;
  created_by: string;
}

// MongoDB Schema
const documentContentSchema = new Schema<IDocumentContent>({
  postgresql_id: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  icon: {
    type: { type: String, enum: ['emoji', 'file', 'external'] },
    emoji: String,
    file: { url: String },
    external: { url: String }
  },
  cover: {
    type: { type: String, enum: ['external', 'file'] },
    external: { url: String },
    file: { url: String }
  },
  blocks: [{ type: Schema.Types.Mixed }],
  versions: [{ type: Schema.Types.Mixed }],
  current_version: { type: Number, default: 1 },
  last_edited_time: { type: Date, default: Date.now },
  last_edited_by: { type: String, required: true },
  created_time: { type: Date, default: Date.now },
  created_by: { type: String, required: true }
}, {
  timestamps: true,
  collection: 'document_contents'
});

// Indexes for better performance
documentContentSchema.index({ postgresql_id: 1 });
documentContentSchema.index({ created_by: 1 });
documentContentSchema.index({ last_edited_time: -1 });
documentContentSchema.index({ 'blocks.id': 1 });

export const DocumentContent = mongoose.model<IDocumentContent>('DocumentContent', documentContentSchema);