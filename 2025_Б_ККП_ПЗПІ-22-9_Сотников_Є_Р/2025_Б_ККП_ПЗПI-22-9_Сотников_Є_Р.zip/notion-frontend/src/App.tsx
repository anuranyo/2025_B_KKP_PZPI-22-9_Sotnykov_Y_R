﻿import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { useAppStore } from './store/useAppStore'
import { useAuth } from './hooks/useAuth'

// Layout components
import AuthLayout from './components/layout/AuthLayout'
import AppLayout from './components/layout/AppLayout'

// Pages
import LoginPage from './pages/auth/LoginPage'
import RegisterPage from './pages/auth/RegisterPage'
import DashboardPage from './pages/DashboardPage'
import WorkspacePage from './pages/WorkspacePage'
import DocumentPage from './pages/DocumentPage'
import SettingsPage from './pages/SettingsPage'
import PublicWorkspacesPage from './pages/PublicWorkspacesPage'
import ArchivedPage from './pages/ArchivedPage'

// Debug Component
import DebugInfo from './components/DebugInfo'

// Loading Component
const LoadingSpinner = () => (
  <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-900">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 dark:border-blue-400"></div>
  </div>
)

function App() {
  const { isAuthenticated, initializeTheme } = useAppStore()
  const { isLoadingProfile } = useAuth()
  const location = useLocation()

  // Инициализация темы при первом рендере
  useEffect(() => {
    initializeTheme()
  }, [initializeTheme])

  // Debug logging
  useEffect(() => {
    console.log('App render:', {
      isAuthenticated,
      isLoadingProfile,
      path: location.pathname
    })
  }, [isAuthenticated, isLoadingProfile, location.pathname])

  // Show loading while checking auth
  if (isLoadingProfile) {
    return <LoadingSpinner />
  }

  return (
    <div className="App min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors">
      {/* <DebugInfo /> */}
      <Routes>
        {/* Root route - handle redirect here */}
        <Route 
          path="/" 
          element={
            <Navigate 
              to={isAuthenticated ? "/dashboard" : "/login"} 
              replace 
            />
          } 
        />

        {/* Auth routes - only show if NOT authenticated */}
        <Route
          path="/login"
          element={
            isAuthenticated ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <AuthLayout>
                <LoginPage />
              </AuthLayout>
            )
          }
        />
        
        <Route
          path="/register"
          element={
            isAuthenticated ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <AuthLayout>
                <RegisterPage />
              </AuthLayout>
            )
          }
        />
        
        {/* Public workspaces - always accessible */}
        <Route 
          path="/public" 
          element={<PublicWorkspacesPage />} 
        />

        {/* Protected routes - only show if authenticated */}
        <Route
          path="/dashboard"
          element={
            isAuthenticated ? (
              <AppLayout>
                <DashboardPage />
              </AppLayout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        
        <Route
          path="/workspace/:workspaceId"
          element={
            isAuthenticated ? (
              <AppLayout>
                <WorkspacePage />
              </AppLayout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />

        <Route path="/archived" element={<ArchivedPage />} />
        
        <Route
          path="/document/:documentId"
          element={
            isAuthenticated ? (
              <AppLayout>
                <DocumentPage />
              </AppLayout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        
        <Route
          path="/settings"
          element={
            isAuthenticated ? (
              <AppLayout>
                <SettingsPage />
              </AppLayout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />

        {/* 404 Page */}
        <Route
          path="*"
          element={
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
              <div className="text-center">
                <h1 className="text-6xl font-bold text-gray-900 dark:text-gray-100 mb-4">404</h1>
                <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">Page not found</p>
                <a 
                  href={isAuthenticated ? "/dashboard" : "/login"}
                  className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-colors"
                >
                  {isAuthenticated ? 'Go to Dashboard' : 'Go to Login'}
                </a>
              </div>
            </div>
          }
        />
      </Routes>
    </div>
  )
}

export default App