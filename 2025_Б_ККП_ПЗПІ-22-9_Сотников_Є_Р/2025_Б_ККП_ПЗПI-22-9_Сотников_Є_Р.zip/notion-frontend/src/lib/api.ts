import axios from 'axios'
import type { AxiosResponse, AxiosError } from 'axios'
import { toast } from 'sonner'
import type { 
  ApiResponse, 
  AuthResponse, 
  LoginCredentials, 
  RegisterData,
  User,
  Workspace,
  CreateWorkspaceData,
  Document,
  CreateDocumentData,
  DocumentContent,
  AIGenerateRequest,
  AIGenerateResponse
} from '../types'

// Create axios instance
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor for error handling
api.interceptors.response.use(
  (response: AxiosResponse) => {
    return response
  },
  (error: AxiosError<ApiResponse>) => {
    const message = error.response?.data?.message || error.message || 'An error occurred'
    
    // Don't show toast for certain status codes
    if (error.response?.status !== 401) {
      toast.error(message)
    }
    
    // Handle unauthorized
    if (error.response?.status === 401) {
      // Clear storage and redirect to login
      localStorage.removeItem('token')
      localStorage.removeItem('app-storage')
      window.location.href = '/login'
    }
    
    return Promise.reject(error)
  }
)

// Health check
export const healthCheck = async (): Promise<any> => {
  const response = await api.get('/health')
  return response.data
}

// Auth API
export const authApi = {
  register: async (data: RegisterData): Promise<AuthResponse> => {
    const response = await api.post<ApiResponse<AuthResponse>>('/api/auth/register', data)
    return response.data.data!
  },

  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    const response = await api.post<ApiResponse<AuthResponse>>('/api/auth/login', credentials)
    return response.data.data!
  },

  getProfile: async (): Promise<User> => {
    const response = await api.get<ApiResponse<User>>('/api/auth/me')
    return response.data.data!
  },

  logout: async (): Promise<void> => {
    await api.post('/api/auth/logout')
  },

  changePassword: async (data: { currentPassword: string; newPassword: string }): Promise<void> => {
    await api.post('/api/auth/change-password', data)
  },
}

// Users API
export const usersApi = {
  getProfile: async (): Promise<User> => {
    const response = await api.get<ApiResponse<User>>('/api/users/profile')
    return response.data.data!
  },

  updateProfile: async (data: Partial<User>): Promise<User> => {
    const response = await api.put<ApiResponse<User>>('/api/users/profile', data)
    return response.data.data!
  },

  getUserWorkspaces: async (): Promise<Workspace[]> => {
    const response = await api.get<ApiResponse<Workspace[]>>('/api/users/workspaces')
    return response.data.data!
  },

  getUserDocuments: async (params?: { 
    page?: number; 
    limit?: number; 
    search?: string;
    archived?: boolean;
    favorites?: boolean;
  }): Promise<{ documents: Document[]; pagination: any }> => {
    // Convert boolean to string for query params
    const queryParams = {
      ...params,
      archived: params?.archived?.toString(),
      favorites: params?.favorites?.toString()
    }
    
    const response = await api.get<ApiResponse<Document[]>>('/api/users/documents', { 
      params: queryParams 
    })
    return {
      documents: response.data.data!,
      pagination: response.data.pagination
    }
  },

  getArchivedDocuments: async (params?: { 
    page?: number; 
    limit?: number; 
    search?: string 
  }): Promise<{ documents: Document[]; pagination: any }> => {
    const response = await api.get<ApiResponse<Document[]>>('/api/users/documents', { 
      params: { ...params, archived: 'true' }
    })
    return {
      documents: response.data.data!,
      pagination: response.data.pagination
    }
  },

  getRecentDocuments: async (limit = 10): Promise<Document[]> => {
    const response = await api.get<ApiResponse<Document[]>>(`/api/users/documents/recent?limit=${limit}`)
    return response.data.data!
  },

  getFavoriteDocuments: async (): Promise<Document[]> => {
    const response = await api.get<ApiResponse<Document[]>>('/api/users/documents/favorites')
    return response.data.data!
  },

  getUserStats: async (): Promise<any> => {
    const response = await api.get<ApiResponse<any>>('/api/users/stats')
    return response.data.data!
  },
}

// Workspaces API
export const workspacesApi = {
  create: async (data: CreateWorkspaceData): Promise<Workspace> => {
    console.log('workspacesApi.create called with:', data)
    console.log('API base URL:', api.defaults.baseURL)
    
    try {
      const response = await api.post<ApiResponse<Workspace>>('/api/workspaces', data)
      console.log('workspacesApi.create response:', response)
      return response.data.data!
    } catch (error) {
      console.error('workspacesApi.create error:', error)
      throw error
    }
  },

  getAll: async (): Promise<Workspace[]> => {
    const response = await api.get<ApiResponse<Workspace[]>>('/api/workspaces')
    return response.data.data!
  },

  getById: async (id: string): Promise<Workspace> => {
    const response = await api.get<ApiResponse<Workspace>>(`/api/workspaces/${id}`)
    return response.data.data!
  },

  update: async (id: string, data: Partial<CreateWorkspaceData>): Promise<Workspace> => {
    const response = await api.put<ApiResponse<Workspace>>(`/api/workspaces/${id}`, data)
    return response.data.data!
  },

  delete: async (id: string): Promise<void> => {
    await api.delete(`/api/workspaces/${id}`)
  },

  getMembers: async (id: string): Promise<any[]> => {
    const response = await api.get<ApiResponse<any[]>>(`/api/workspaces/${id}/members`)
    return response.data.data!
  },

  inviteMember: async (id: string, data: { email: string; role: string }): Promise<any> => {
    const response = await api.post<ApiResponse<any>>(`/api/workspaces/${id}/members`, data)
    return response.data.data!
  },

  getDocuments: async (id: string, params?: { page?: number; limit?: number; search?: string }): Promise<{ documents: Document[]; pagination: any }> => {
    const response = await api.get<ApiResponse<Document[]>>(`/api/documents/workspace/${id}`, { params })
    return {
      documents: response.data.data!,
      pagination: response.data.pagination
    }
  },

  getPublic: async (params?: { page?: number; limit?: number; search?: string }): Promise<{ workspaces: Workspace[]; pagination: any }> => {
    const response = await api.get<ApiResponse<Workspace[]>>('/api/workspaces/public/list', { params })
    return {
      workspaces: response.data.data!,
      pagination: response.data.pagination
    }
  },
}

// Documents API
export const documentsApi = {
  create: async (data: CreateDocumentData): Promise<Document> => {
    const response = await api.post<ApiResponse<Document>>('/api/documents', data)
    return response.data.data!
  },

  getById: async (id: string): Promise<Document> => {
    const response = await api.get<ApiResponse<Document>>(`/api/documents/${id}`)
    return response.data.data!
  },

  update: async (id: string, data: Partial<Document>): Promise<Document> => {
    const response = await api.put<ApiResponse<Document>>(`/api/documents/${id}`, data)
    return response.data.data!
  },

  delete: async (id: string): Promise<void> => {
    await api.delete(`/api/documents/${id}`)
  },

  getContent: async (id: string): Promise<DocumentContent> => {
    const response = await api.get<ApiResponse<DocumentContent>>(`/api/documents/${id}/content`)
    return response.data.data!
  },

  updateContent: async (id: string, content: Partial<DocumentContent>): Promise<DocumentContent> => {
    console.log('documentsApi.updateContent called with:')
    console.log('Document ID:', id)
    console.log('Content data:', content)
    console.log('API base URL:', api.defaults.baseURL)
    
    try {
      const response = await api.put<ApiResponse<DocumentContent>>(`/api/documents/${id}/content`, content)
      console.log('documentsApi.updateContent response:', response)
      return response.data.data!
    } catch (error) {
      console.error('documentsApi.updateContent error:', error)
      if (axios.isAxiosError(error) && error.response) {
        console.error('Error response:', error.response.data)
        console.error('Error status:', error.response.status)
      }
      throw error
    }
  },

  toggleFavorite: async (id: string): Promise<{ isFavorite: boolean }> => {
    const response = await api.post<ApiResponse<{ isFavorite: boolean }>>(`/api/documents/${id}/favorite`)
    return response.data.data!
  },

  toggleArchive: async (id: string): Promise<{ isArchived: boolean }> => {
    const response = await api.post<ApiResponse<{ isArchived: boolean }>>(`/api/documents/${id}/archive`)
    return response.data.data!
  },

  search: async (query: { query: string; workspaceId?: string; type?: string; limit?: number }): Promise<any> => {
    const response = await api.post<ApiResponse<any>>('/api/documents/search', query)
    return response.data.data!
  },

  getChildren: async (id: string): Promise<Document[]> => {
    const response = await api.get<ApiResponse<Document[]>>(`/api/documents/${id}/children`)
    return response.data.data!
  },
}

// AI API
export const aiApi = {
  healthCheck: async (): Promise<any> => {
    const response = await api.get<ApiResponse<any>>('/api/ai/health')
    return response.data.data!
  },

  generate: async (data: AIGenerateRequest): Promise<AIGenerateResponse> => {
    const response = await api.post<ApiResponse<AIGenerateResponse>>('/api/ai/generate', data)
    return response.data.data!
  },

  complete: async (prompt: string, context?: string): Promise<string> => {
    const response = await api.post<ApiResponse<{ content: string }>>('/api/ai/complete', { prompt, context })
    return response.data.data!.content
  },

  improve: async (text: string, instructions?: string): Promise<string> => {
    const response = await api.post<ApiResponse<{ content: string }>>('/api/ai/improve', { text, instructions })
    return response.data.data!.content
  },

  summarize: async (text: string, length: 'short' | 'medium' | 'long' = 'medium'): Promise<string> => {
    const response = await api.post<ApiResponse<{ content: string }>>('/api/ai/summarize', { text, length })
    return response.data.data!.content
  },

  translate: async (text: string, targetLanguage: string, sourceLanguage?: string): Promise<string> => {
    const response = await api.post<ApiResponse<{ content: string }>>('/api/ai/translate', { text, targetLanguage, sourceLanguage })
    return response.data.data!.content
  },

  brainstorm: async (topic: string, count = 5): Promise<string[]> => {
    const response = await api.post<ApiResponse<{ ideas: string[] }>>('/api/ai/brainstorm', { topic, count })
    return response.data.data!.ideas
  },

  generateOutline: async (topic: string, depth: 'basic' | 'detailed' = 'basic'): Promise<string> => {
    const response = await api.post<ApiResponse<{ content: string }>>('/api/ai/outline', { topic, depth })
    return response.data.data!.content
  },
}

// Upload API
export const uploadApi = {
  single: async (file: File, folder?: string): Promise<any> => {
    const formData = new FormData()
    formData.append('file', file)
    if (folder) formData.append('folder', folder)

    const response = await api.post<ApiResponse<any>>('/api/upload/single', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data.data!
  },

  image: async (file: File): Promise<any> => {
    const formData = new FormData()
    formData.append('image', file)

    const response = await api.post<ApiResponse<any>>('/api/upload/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data.data!
  },

  avatar: async (file: File): Promise<any> => {
    const formData = new FormData()
    formData.append('avatar', file)

    const response = await api.post<ApiResponse<any>>('/api/upload/avatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data.data!
  },

  delete: async (publicId: string): Promise<void> => {
    await api.delete(`/api/upload/${publicId}`)
  },
}

export default api