import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, Workspace } from '../types'

interface AppState {
  // Auth state
  user: User | null
  token: string | null
  isAuthenticated: boolean

  // App state
  currentWorkspace: Workspace | null
  sidebarOpen: boolean
  theme: 'light' | 'dark'

  // Auth actions
  login: (token: string, user: User) => void
  logout: () => void
  setUser: (user: User) => void

  // App actions
  setCurrentWorkspace: (workspace: Workspace | null) => void
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
  setTheme: (theme: 'light' | 'dark') => void
  initializeTheme: () => void
}

// Функция для применения темы к DOM
const applyTheme = (theme: 'light' | 'dark') => {
  if (typeof document !== 'undefined' && document.documentElement) {
    const root = document.documentElement
    const body = document.body
    
    try {
      if (theme === 'dark') {
        root.classList.add('dark')
        if (body) body.classList.add('dark')
      } else {
        root.classList.remove('dark')
        if (body) body.classList.remove('dark')
      }
      
      // Сохраняем в localStorage для скрипта в index.html
      localStorage.setItem('theme', theme)
    } catch (error) {
      console.warn('Could not apply theme to DOM:', error)
    }
  }
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      token: null,
      isAuthenticated: false,
      currentWorkspace: null,
      sidebarOpen: true,
      theme: 'light',

      // Auth actions
      login: (token: string, user: User) => {
        console.log('Store login called:', { token: !!token, user: user.name })
        set({
          token,
          user,
          isAuthenticated: true,
        })
      },

      logout: () => {
        console.log('Store logout called')
        set({
          token: null,
          user: null,
          isAuthenticated: false,
          currentWorkspace: null,
        })
      },

      setUser: (user: User) => {
        set({ user })
      },

      // App actions
      setCurrentWorkspace: (workspace: Workspace | null) => {
        set({ currentWorkspace: workspace })
      },

      toggleSidebar: () => {
        set((state) => ({ sidebarOpen: !state.sidebarOpen }))
      },

      setSidebarOpen: (open: boolean) => {
        set({ sidebarOpen: open })
      },

      setTheme: (theme: 'light' | 'dark') => {
        set({ theme })
        applyTheme(theme)
      },

      // Инициализация темы при загрузке приложения
      initializeTheme: () => {
        if (typeof window === 'undefined') return
        
        const state = get()
        let savedTheme: 'light' | 'dark' | null = null
        let systemTheme: 'light' | 'dark' = 'light'
        
        try {
          savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null
          systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
        } catch (error) {
          console.warn('Could not access localStorage or matchMedia:', error)
        }
        
        // Приоритет: сохраненная тема > тема из store > системная тема
        const themeToUse = savedTheme || state.theme || systemTheme
        
        if (themeToUse !== state.theme) {
          set({ theme: themeToUse })
        }
        
        applyTheme(themeToUse)
      },
    }),
    {
      name: 'app-storage',
      partialize: (state) => ({
        token: state.token,
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        currentWorkspace: state.currentWorkspace,
        theme: state.theme,
        sidebarOpen: state.sidebarOpen,
      }),
      onRehydrateStorage: () => (state) => {
        console.log('Zustand rehydrated:', {
          hasToken: !!state?.token,
          isAuthenticated: state?.isAuthenticated,
          hasUser: !!state?.user,
          theme: state?.theme
        })
        
        // Синхронизируем состояние аутентификации с наличием токена
        if (state && state.token && !state.isAuthenticated) {
          console.log('Fixing authentication state')
          state.isAuthenticated = true
        } else if (state && !state.token && state.isAuthenticated) {
          console.log('Clearing authentication state')
          state.isAuthenticated = false
          state.user = null
        }

        // Применяем тему после восстановления состояния
        if (state?.theme) {
          // Небольшая задержка для уверенности, что DOM готов
          setTimeout(() => {
            applyTheme(state.theme)
          }, 0)
        }
      },
    }
  )
)