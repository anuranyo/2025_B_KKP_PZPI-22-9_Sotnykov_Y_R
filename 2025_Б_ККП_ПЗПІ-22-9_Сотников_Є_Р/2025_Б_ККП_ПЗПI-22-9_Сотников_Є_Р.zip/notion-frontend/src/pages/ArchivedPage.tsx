import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  Archive, 
  FileText, 
  Search, 
  RotateCcw, 
  Trash2, 
  Clock,
  Folder,
  User,
  MoreHorizontal
} from 'lucide-react'
import { useDocuments } from '../hooks/useDocuments'
import { toast } from 'sonner'

const ArchivedPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedDocs, setSelectedDocs] = useState<string[]>([])
  const [showMoreMenu, setShowMoreMenu] = useState<string | null>(null)

  const { 
    useArchivedDocuments,
    toggleArchive, 
    deleteDocumentAsync, 
    isTogglingArchive, 
    isDeletingDocument 
  } = useDocuments()

  // Fetch archived documents using the specialized hook
  const { data: archivedData, isLoading, refetch } = useArchivedDocuments({ 
    page: 1, 
    limit: 100 
  })
  
  const archivedDocuments = archivedData?.documents || []

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return 'Just now'
    if (diffInHours < 24) return `${diffInHours}h ago`
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`
    return date.toLocaleDateString()
  }

  const filteredDocuments = archivedDocuments.filter(doc =>
    searchQuery === '' || 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.workspace?.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleRestore = async (documentId: string) => {
    try {
      await toggleArchive(documentId)
      toast.success('Document restored successfully')
      refetch()
    } catch (error) {
      toast.error('Failed to restore document')
    }
  }

  const handleDelete = async (documentId: string, title: string) => {
    if (confirm(`Are you sure you want to permanently delete "${title}"? This action cannot be undone.`)) {
      try {
        await deleteDocumentAsync(documentId)
        toast.success('Document deleted permanently')
        refetch()
      } catch (error) {
        toast.error('Failed to delete document')
      }
    }
    setShowMoreMenu(null)
  }

  const handleBulkRestore = async () => {
    if (selectedDocs.length === 0) return
    
    try {
      await Promise.all(selectedDocs.map(id => toggleArchive(id)))
      toast.success(`${selectedDocs.length} documents restored`)
      setSelectedDocs([])
      refetch()
    } catch (error) {
      toast.error('Failed to restore some documents')
    }
  }

  const handleBulkDelete = async () => {
    if (selectedDocs.length === 0) return
    
    if (confirm(`Are you sure you want to permanently delete ${selectedDocs.length} documents? This action cannot be undone.`)) {
      try {
        await Promise.all(selectedDocs.map(id => deleteDocumentAsync(id)))
        toast.success(`${selectedDocs.length} documents deleted permanently`)
        setSelectedDocs([])
        refetch()
      } catch (error) {
        toast.error('Failed to delete some documents')
      }
    }
  }

  const toggleSelectDoc = (docId: string) => {
    setSelectedDocs(prev => 
      prev.includes(docId) 
        ? prev.filter(id => id !== docId)
        : [...prev, docId]
    )
  }

  const selectAllDocs = () => {
    if (selectedDocs.length === filteredDocuments.length) {
      setSelectedDocs([])
    } else {
      setSelectedDocs(filteredDocuments.map(doc => doc.id))
    }
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <Archive className="h-8 w-8 text-gray-600 dark:text-gray-400" />
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
            Archived Documents
          </h1>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          Manage your archived documents. Restore them or delete them permanently.
        </p>
      </div>

      {/* Search and Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search archived documents..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Bulk Actions */}
        {selectedDocs.length > 0 && (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {selectedDocs.length} selected
            </span>
            <button
              onClick={handleBulkRestore}
              disabled={isTogglingArchive}
              className="flex items-center px-3 py-2 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Restore
            </button>
            <button
              onClick={handleBulkDelete}
              disabled={isDeletingDocument}
              className="flex items-center px-3 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Forever
            </button>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-sm text-gray-500">Loading archived documents...</p>
          </div>
        ) : filteredDocuments.length === 0 ? (
          <div className="p-8 text-center">
            <Archive className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-gray-100">
              {searchQuery ? 'No documents match your search' : 'No archived documents'}
            </h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {searchQuery 
                ? 'Try adjusting your search terms'
                : 'Documents you archive will appear here. You can restore or delete them permanently.'
              }
            </p>
          </div>
        ) : (
          <>
            {/* Select All Header */}
            <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={selectedDocs.length === filteredDocuments.length && filteredDocuments.length > 0}
                  onChange={selectAllDocs}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label className="ml-3 text-sm font-medium text-gray-700 dark:text-gray-300">
                  Select all ({filteredDocuments.length})
                </label>
              </div>
            </div>

            {/* Documents List */}
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {filteredDocuments.map((doc) => (
                <div key={doc.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {/* Checkbox */}
                      <input
                        type="checkbox"
                        checked={selectedDocs.includes(doc.id)}
                        onChange={() => toggleSelectDoc(doc.id)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />

                      {/* Document Info */}
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <FileText className="h-5 w-5 text-gray-400" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                            {doc.title}
                          </p>
                          <div className="flex items-center mt-1 space-x-2 text-xs text-gray-500 dark:text-gray-400">
                            <Folder className="h-3 w-3" />
                            <span>{doc.workspace?.name}</span>
                            <span>•</span>
                            <Clock className="h-3 w-3" />
                            <span>Archived {formatDate(doc.updatedAt)}</span>
                            {doc.author && (
                              <>
                                <span>•</span>
                                <User className="h-3 w-3" />
                                <span>{doc.author.name}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center space-x-2">
                      {/* Quick Actions */}
                      <button
                        onClick={() => handleRestore(doc.id)}
                        disabled={isTogglingArchive}
                        className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors disabled:opacity-50"
                        title="Restore document"
                      >
                        <RotateCcw className="h-4 w-4" />
                      </button>

                      {/* More Menu */}
                      <div className="relative">
                        <button
                          onClick={() => setShowMoreMenu(showMoreMenu === doc.id ? null : doc.id)}
                          className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </button>

                        {showMoreMenu === doc.id && (
                          <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-1 z-50">
                            <Link
                              to={`/document/${doc.id}`}
                              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                              onClick={() => setShowMoreMenu(null)}
                            >
                              <FileText className="h-4 w-4 mr-3" />
                              View Document
                            </Link>
                            
                            <button
                              onClick={() => handleRestore(doc.id)}
                              disabled={isTogglingArchive}
                              className="flex items-center w-full px-4 py-2 text-sm text-green-700 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors disabled:opacity-50"
                            >
                              <RotateCcw className="h-4 w-4 mr-3" />
                              Restore
                            </button>

                            <hr className="my-1 border-gray-200 dark:border-gray-700" />
                            
                            <button
                              onClick={() => handleDelete(doc.id, doc.title)}
                              disabled={isDeletingDocument}
                              className="flex items-center w-full px-4 py-2 text-sm text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors disabled:opacity-50"
                            >
                              <Trash2 className="h-4 w-4 mr-3" />
                              Delete Forever
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Click outside to close menu */}
      {showMoreMenu && (
        <div
          className="fixed inset-0 z-30"
          onClick={() => setShowMoreMenu(null)}
        />
      )}
    </div>
  )
}

export default ArchivedPage