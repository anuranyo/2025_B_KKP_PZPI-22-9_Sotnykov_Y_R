import React, { useState, useEffect } from 'react'
import { useParams, Navigate, useNavigate } from 'react-router-dom'
import { 
  Star, 
  Share2, 
  MoreHorizontal, 
  Clock, 
  Users,
  Archive,
  Trash2,
  Edit,
  Eye,
  Sparkles,
  Copy,
  GitBranch
} from 'lucide-react'
import { useDocuments } from '../hooks/useDocuments'
import { useAuth } from '../hooks/useAuth'
import DocumentEditor from '../components/editor/DocumentEditor'
import { toast } from 'sonner'

const DocumentPage: React.FC = () => {
  const { documentId } = useParams<{ documentId: string }>()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [isEditing, setIsEditing] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [showMoreMenu, setShowMoreMenu] = useState(false)
  const [showCollaboratorsModal, setShowCollaboratorsModal] = useState(false)
  const [showHistoryModal, setShowHistoryModal] = useState(false)

  // ИСПРАВЛЕНИЕ: Сбрасываем состояние при изменении documentId
  useEffect(() => {
    setIsEditing(false)
    setShowShareModal(false)
    setShowMoreMenu(false)
    setShowCollaboratorsModal(false)
    setShowHistoryModal(false)
  }, [documentId])

  const { 
    useDocument, 
    useDocumentContent,
    toggleFavorite,
    toggleArchive,
    deleteDocumentAsync,
    createDocumentAsync,
    updateContentOptimistic,
    isTogglingFavorite,
    isTogglingArchive,
    isDeletingDocument,
    isCreatingDocument
  } = useDocuments()

  const { 
    data: document, 
    isLoading: isLoadingDocument, 
    error: documentError 
  } = useDocument(documentId!)

  const { 
    data: content, 
    isLoading: isLoadingContent 
  } = useDocumentContent(documentId!)

  useEffect(() => {
    // Auto-enable editing if user is document author
    if (document && user && document.authorId === user.id) {
      setIsEditing(true)
    }
  }, [document, user])

  // Handle loading states
  if (isLoadingDocument || isLoadingContent) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  // Handle error states
  if (documentError || !document) {
    return <Navigate to="/dashboard" replace />
  }

  const canEdit = user && (
    document.authorId === user.id || 
    document.isPublic ||
    // Add workspace permission check here
    true
  )

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const handleToggleFavorite = () => {
    toggleFavorite(document.id)
  }

  const handleToggleArchive = () => {
    console.log('Archive clicked')
    if (confirm('Are you sure you want to archive this document?')) {
      toggleArchive(document.id)
      setShowMoreMenu(false)
    }
  }

  const handleDeleteDocument = async () => {
    console.log('Delete clicked')
    if (confirm('Are you sure you want to delete this document? This action cannot be undone.')) {
      try {
        await deleteDocumentAsync(document.id)
        navigate('/dashboard')
      } catch (error) {
        console.error('Failed to delete document:', error)
      }
    }
    setShowMoreMenu(false)
  }

  const handleShare = () => {
    setShowShareModal(true)
    setShowMoreMenu(false)
  }

  const handleViewHistory = () => {
    setShowHistoryModal(true)
    setShowMoreMenu(false)
  }

  const handleCollaborators = () => {
    setShowCollaboratorsModal(true)
    setShowMoreMenu(false)
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href).then(
      () => toast.success('Link copied to clipboard'),
      () => toast.error('Failed to copy link')
    )
  }

  const handleAIAssist = () => {
    // TODO: Implement AI assistance
    toast.info('AI assistance coming soon!')
    setShowMoreMenu(false)
  }

  const handleDuplicateDocument = async () => {
    console.log('=== DUPLICATE FUNCTION CALLED ===')
    
    if (!document) {
      toast.error('Document not found')
      return
    }

    if (!content) {
      toast.error('Document content is still loading')
      return
    }

    try {
      setShowMoreMenu(false)
      
      // Create new document with " Copy" suffix
      const newDocumentData: any = {
        title: `${document.title} Copy`,
        workspaceId: document.workspaceId,
        isPublic: document.isPublic
      }

      // Добавляем parentId только если он есть
      if (document.parentId) {
        newDocumentData.parentId = document.parentId
      }

      toast.info('Duplicating document...')
      
      // Create the new document
      const newDocument = await createDocumentAsync(newDocumentData)
      
      // Copy all content from original document
      const contentToCopy = {
        title: newDocumentData.title,
        blocks: [...(content.blocks || [])],
        icon: content.icon ? { ...content.icon } : undefined,
        cover: content.cover ? { ...content.cover } : undefined,
        last_edited_time: new Date().toISOString()
      }
      
      // Update content of new document
      updateContentOptimistic(newDocument.id, contentToCopy)
      
      toast.success(`Document duplicated as "${newDocumentData.title}"`)
      
      // Navigate to the new document
      setTimeout(() => {
        navigate(`/document/${newDocument.id}`)
      }, 1500)
      
    } catch (error) {
      console.error('Failed to duplicate document:', error)
      toast.error('Failed to duplicate document')
    }
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Header */}
      <div className="border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between" style={{ zIndex: 1 }}>
            <div className="flex items-center space-x-4">
              {/* Document Info */}
              <div className="flex items-center space-x-3">
                {content?.icon?.emoji && (
                  <span className="text-2xl">{content.icon.emoji}</span>
                )}
                <div>
                  <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
                    {document.title}
                  </h1>
                  <div className="flex items-center space-x-3 text-sm text-gray-500 dark:text-gray-400">
                    <span>in {document.workspace?.name}</span>
                    <span>•</span>
                    <span>Last edited {formatDate(document.updatedAt)}</span>
                    {document.author && (
                      <>
                        <span>•</span>
                        <span>by {document.author.name}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-2">
              {/* Editing Toggle */}
              {canEdit && (
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isEditing
                      ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {isEditing ? (
                    <>
                      <Edit className="h-4 w-4 mr-2" />
                      Editing
                    </>
                  ) : (
                    <>
                      <Eye className="h-4 w-4 mr-2" />
                      Viewing
                    </>
                  )}
                </button>
              )}

              {/* Favorite */}
              <button
                onClick={handleToggleFavorite}
                disabled={isTogglingFavorite}
                className={`p-2 rounded-lg transition-colors ${
                  document.isFavorite
                    ? 'text-yellow-500 bg-yellow-50 dark:bg-yellow-900/20'
                    : 'text-gray-400 hover:text-yellow-500 hover:bg-yellow-50 dark:hover:bg-yellow-900/20'
                }`}
              >
                <Star className={`h-5 w-5 ${document.isFavorite ? 'fill-current' : ''}`} />
              </button>

              {/* Share */}
              <button
                onClick={handleShare}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <Share2 className="h-5 w-5" />
              </button>

              {/* More Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowMoreMenu(!showMoreMenu)}
                  className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  style={{ zIndex: 1000 }}
                >
                  <MoreHorizontal className="h-5 w-5" />
                </button>

                {showMoreMenu && (
                  <div 
                    className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-1"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      onClick={() => handleViewHistory()}
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <Clock className="h-4 w-4 mr-3" />
                      View History
                    </button>
                    
                    <button
                      onClick={() => handleCollaborators()}
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <Users className="h-4 w-4 mr-3" />
                      Collaborators
                    </button>

                    <button
                      onClick={() => handleDuplicateDocument()}
                      disabled={isCreatingDocument || !content || isLoadingContent}
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
                    >
                      <Copy className="h-4 w-4 mr-3" />
                      {isCreatingDocument ? 'Duplicating...' : !content ? 'Loading...' : 'Duplicate'}
                    </button>

                    <hr className="my-1 border-gray-200 dark:border-gray-700" />
                    
                    <button
                      onClick={() => handleToggleArchive()}
                      disabled={isTogglingArchive}
                      className="flex items-center w-full px-4 py-2 text-sm text-orange-700 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors disabled:opacity-50"
                    >
                      <Archive className="h-4 w-4 mr-3" />
                      {document.isArchived ? 'Unarchive' : 'Archive'}
                    </button>
                    
                    <button
                      onClick={() => handleDeleteDocument()}
                      disabled={isDeletingDocument}
                      className="flex items-center w-full px-4 py-2 text-sm text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors disabled:opacity-50"
                    >
                      <Trash2 className="h-4 w-4 mr-3" />
                      Delete
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto">
        {content ? (
          <DocumentEditor
            key={document.id} 
            documentId={document.id}
            content={content}
            isEditable={Boolean(isEditing && canEdit)}
          />
        ) : (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-sm text-gray-500">Loading document content...</p>
          </div>
        )}
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-[9999] overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setShowShareModal(false)} />
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full relative z-10">
              <div className="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
                  Share Document
                </h3>
                
                <div className="space-y-4" style={{ zIndex: 1000 }}>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Share link
                    </label>
                    <div className="flex">
                      <input
                        type="text"
                        value={window.location.href}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-l-lg bg-gray-50 dark:bg-gray-700 text-sm"
                      />
                      <button
                        onClick={handleCopyLink}
                        className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 transition-colors text-sm"
                      >
                        Copy
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700 dark:text-gray-300">
                      Anyone with the link can {document.isPublic ? 'view' : 'view (workspace members only)'}
                    </span>
                    <button className="text-sm text-blue-600 hover:text-blue-800">
                      Change
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  onClick={() => setShowShareModal(false)}
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-[9999] overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setShowHistoryModal(false)} />
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full relative z-10">
              <div className="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                    Document History
                  </h3>
                  <button
                    onClick={() => setShowHistoryModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    ×
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <GitBranch className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Document history feature is coming soon!</p>
                    <p className="text-sm mt-2">You'll be able to view and restore previous versions of your document.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Collaborators Modal */}
      {showCollaboratorsModal && (
        <div className="fixed inset-0 z-[9999] overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setShowCollaboratorsModal(false)} />
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full relative z-10">
              <div className="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                    Collaborators
                  </h3>
                  <button
                    onClick={() => setShowCollaboratorsModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    ×
                  </button>
                </div>
                
                <div className="space-y-4">
                  {/* Document Author */}
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                        {document.author?.name?.[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-gray-100">
                          {document.author?.name}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Owner</p>
                      </div>
                    </div>
                    <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs rounded">
                      Owner
                    </span>
                  </div>

                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Real-time collaboration is coming soon!</p>
                    <p className="text-sm mt-2">You'll be able to invite team members to edit documents together.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Click outside to close dropdown menu */}
      {showMoreMenu && (
        <div
          className="fixed inset-0 z-30"
          onClick={() => setShowMoreMenu(false)}
        />
      )}
    </div>
  )
}

export default DocumentPage