import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  Plus, 
  FileText, 
  Folder, 
  Star, 
  Clock, 
  Users,
  TrendingUp,
  Search,
  Filter
} from 'lucide-react'
import { useWorkspaces } from '../hooks/useWorkspaces'
import { useDocuments, useAllDocuments } from '../hooks/useDocuments'
import { usersApi } from '../lib/api'
import { useQuery } from '@tanstack/react-query'
import { useAppStore } from '../store/useAppStore'
import CreateWorkspaceModal from '../components/modals/CreateWorkspaceModal'
import CreateDocumentModal from '../components/modals/CreateDocumentModal'

const DashboardPage: React.FC = () => {
  const { user, currentWorkspace, theme } = useAppStore()
  const { workspaces, isLoadingWorkspaces } = useWorkspaces()
  const { useRecentDocuments, useFavoriteDocuments } = useDocuments()
  
  const [showCreateWorkspace, setShowCreateWorkspace] = useState(false)
  const [showCreateDocument, setShowCreateDocument] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [filterBy, setFilterBy] = useState<'all' | 'recent' | 'favorites'>('recent')

  // Fetch user stats
  const { data: userStats } = useQuery({
    queryKey: ['users', 'stats'],
    queryFn: usersApi.getUserStats,
  })

  // Fetch documents based on filter
  const { data: recentDocuments = [], isLoading: isLoadingRecent } = useRecentDocuments(50)
  const { data: favoriteDocuments = [], isLoading: isLoadingFavorites } = useFavoriteDocuments()
  
  // Fetch all documents when search is active or filter is 'all'
  const { data: allDocumentsData, isLoading: isLoadingAll } = useAllDocuments({
    page: 1,
    limit: 50,
    search: searchQuery.trim() || undefined
  }, {
    enabled: filterBy === 'all' || searchQuery.trim().length > 0
  })

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return 'Just now'
    if (diffInHours < 24) return `${diffInHours}h ago`
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`
    return date.toLocaleDateString()
  }

  // Определяем стили на основе темы
  const isDark = theme === 'dark'
  const bgStyle = {
    backgroundColor: isDark ? '#111827' : '#f9fafb'
  }
  const cardStyle = {
    backgroundColor: isDark ? '#1f2937' : '#ffffff',
    borderColor: isDark ? '#374151' : '#e5e7eb'
  }

  // Определяем какие документы показывать
  // Replace 'Document' with the actual type/interface of your document objects if available
    let documentsToShow: any[] = []
  let isLoadingDocuments = false

  if (searchQuery.trim().length > 0) {
    // При поиске всегда используем API поиска
    documentsToShow = allDocumentsData?.documents || []
    isLoadingDocuments = isLoadingAll
  } else if (filterBy === 'all') {
    documentsToShow = allDocumentsData?.documents || []
    isLoadingDocuments = isLoadingAll
  } else if (filterBy === 'recent') {
    documentsToShow = recentDocuments
    isLoadingDocuments = isLoadingRecent
  } else if (filterBy === 'favorites') {
    documentsToShow = favoriteDocuments
    isLoadingDocuments = isLoadingFavorites
  }

  // Дополнительная локальная фильтрация не нужна, так как API уже обрабатывает поиск
  const filteredDocuments = documentsToShow

  return (
    <div 
      className={`min-h-full transition-colors ${isDark ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'}`}
      style={bgStyle}
    >
      <div className="p-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className={`text-3xl font-bold mb-2 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Welcome back, {user?.name}!
          </h1>
          <p className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Here's what's happening in your workspace today.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div 
            className={`p-6 rounded-lg shadow-sm border transition-colors ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}
            style={cardStyle}
          >
            <div className="flex items-center">
              <div className={`p-2 rounded-lg ${isDark ? 'bg-blue-900' : 'bg-blue-100'}`}>
                <FileText className={`h-6 w-6 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
              </div>
              <div className="ml-4">
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Documents</p>
                <p className={`text-2xl font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  {userStats?.documents || 0}
                </p>
              </div>
            </div>
          </div>

          <div 
            className={`p-6 rounded-lg shadow-sm border transition-colors ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}
            style={cardStyle}
          >
            <div className="flex items-center">
              <div className={`p-2 rounded-lg ${isDark ? 'bg-green-900' : 'bg-green-100'}`}>
                <Folder className={`h-6 w-6 ${isDark ? 'text-green-400' : 'text-green-600'}`} />
              </div>
              <div className="ml-4">
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Workspaces</p>
                <p className={`text-2xl font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  {userStats?.workspacesOwned || 0}
                </p>
              </div>
            </div>
          </div>

          <div 
            className={`p-6 rounded-lg shadow-sm border transition-colors ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}
            style={cardStyle}
          >
            <div className="flex items-center">
              <div className={`p-2 rounded-lg ${isDark ? 'bg-yellow-900' : 'bg-yellow-100'}`}>
                <Star className={`h-6 w-6 ${isDark ? 'text-yellow-400' : 'text-yellow-600'}`} />
              </div>
              <div className="ml-4">
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Favorites</p>
                <p className={`text-2xl font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  {userStats?.favoriteDocuments || 0}
                </p>
              </div>
            </div>
          </div>

          <div 
            className={`p-6 rounded-lg shadow-sm border transition-colors ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}
            style={cardStyle}
          >
            <div className="flex items-center">
              <div className={`p-2 rounded-lg ${isDark ? 'bg-purple-900' : 'bg-purple-100'}`}>
                <TrendingUp className={`h-6 w-6 ${isDark ? 'text-purple-400' : 'text-purple-600'}`} />
              </div>
              <div className="ml-4">
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Activity</p>
                <p className={`text-2xl font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  {userStats?.recentActivity || 0}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Quick Actions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => setShowCreateWorkspace(true)}
              className={`p-4 border-2 border-dashed rounded-lg transition-colors group ${
                isDark 
                  ? 'bg-gray-800 border-gray-600 hover:border-blue-500 hover:bg-blue-900/20' 
                  : 'bg-white border-gray-300 hover:border-blue-500 hover:bg-blue-50'
              }`}
              style={cardStyle}
            >
              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
                  isDark 
                    ? 'bg-blue-900 group-hover:bg-blue-800' 
                    : 'bg-blue-100 group-hover:bg-blue-200'
                }`}>
                  <Folder className={`h-6 w-6 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
                </div>
                <h3 className={`mt-3 text-sm font-medium ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  Create Workspace
                </h3>
                <p className={`mt-1 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                  Start a new workspace for your team
                </p>
              </div>
            </button>

            <button
              onClick={() => setShowCreateDocument(true)}
              disabled={!currentWorkspace}
              className={`p-4 border-2 border-dashed rounded-lg transition-colors group disabled:opacity-50 disabled:cursor-not-allowed ${
                isDark 
                  ? 'bg-gray-800 border-gray-600 hover:border-green-500 hover:bg-green-900/20' 
                  : 'bg-white border-gray-300 hover:border-green-500 hover:bg-green-50'
              }`}
              style={cardStyle}
            >
              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
                  isDark 
                    ? 'bg-green-900 group-hover:bg-green-800' 
                    : 'bg-green-100 group-hover:bg-green-200'
                }`}>
                  <FileText className={`h-6 w-6 ${isDark ? 'text-green-400' : 'text-green-600'}`} />
                </div>
                <h3 className={`mt-3 text-sm font-medium ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  New Document
                </h3>
                <p className={`mt-1 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                  {currentWorkspace ? 'Create a new document' : 'Select a workspace first'}
                </p>
              </div>
            </button>

            <Link
              to="/public"
              className={`p-4 border-2 border-dashed rounded-lg transition-colors group ${
                isDark 
                  ? 'bg-gray-800 border-gray-600 hover:border-purple-500 hover:bg-purple-900/20' 
                  : 'bg-white border-gray-300 hover:border-purple-500 hover:bg-purple-50'
              }`}
              style={cardStyle}
            >
              <div className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
                  isDark 
                    ? 'bg-purple-900 group-hover:bg-purple-800' 
                    : 'bg-purple-100 group-hover:bg-purple-200'
                }`}>
                  <Users className={`h-6 w-6 ${isDark ? 'text-purple-400' : 'text-purple-600'}`} />
                </div>
                <h3 className={`mt-3 text-sm font-medium ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  Explore Public
                </h3>
                <p className={`mt-1 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                  Browse public workspaces
                </p>
              </div>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Documents Section */}
          <div className="lg:col-span-2">
            {/* Controls - как в WorkspacePage */}
            <div className="flex items-center justify-between mb-4">
              <h2 className={`text-xl font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                {filterBy === 'all' && 'All Documents'}
                {filterBy === 'recent' && 'Recent Documents'}
                {filterBy === 'favorites' && 'Favorite Documents'}
              </h2>
              <div className="flex items-center space-x-4">
                {/* Search */}
                <div className="relative">
                  <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
                  <input
                    type="text"
                    placeholder="Search documents..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`pl-9 pr-4 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-64 transition-colors ${
                      isDark 
                        ? 'bg-gray-800 border-gray-600 text-gray-100 placeholder-gray-500' 
                        : 'bg-white border-gray-300 text-gray-900 placeholder-gray-400'
                    }`}
                    style={{
                      backgroundColor: isDark ? '#374151' : '#ffffff',
                      borderColor: isDark ? '#4b5563' : '#d1d5db',
                      color: isDark ? '#f9fafb' : '#111827'
                    }}
                  />
                </div>

                {/* Filter */}
                <select
                  value={filterBy}
                  onChange={(e) => setFilterBy(e.target.value as any)}
                  className={`px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                    isDark 
                      ? 'bg-gray-800 border-gray-600 text-gray-100' 
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                  style={{
                    backgroundColor: isDark ? '#374151' : '#ffffff',
                    borderColor: isDark ? '#4b5563' : '#d1d5db',
                    color: isDark ? '#f9fafb' : '#111827'
                  }}
                >
                  <option value="recent">Recent documents</option>
                  <option value="all">All documents</option>
                  <option value="favorites">Favorites</option>
                </select>
              </div>
            </div>

            <div 
              className={`rounded-lg shadow-sm border transition-colors ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}
              style={cardStyle}
            >
              {isLoadingDocuments ? (
                <div className="p-8 text-center">
                  <div className={`animate-spin rounded-full h-8 w-8 border-b-2 mx-auto ${isDark ? 'border-blue-400' : 'border-blue-600'}`}></div>
                  <p className={`mt-2 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Loading documents...</p>
                </div>
              ) : filteredDocuments.length === 0 ? (
                <div className="p-8 text-center">
                  <FileText className={`mx-auto h-12 w-12 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
                  <h3 className={`mt-2 text-sm font-medium ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                    {searchQuery.trim() ? 'No documents found' : 'No documents yet'}
                  </h3>
                  <p className={`mt-1 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                    {searchQuery.trim() 
                      ? `No documents match "${searchQuery.trim()}"`
                      : 'Create your first document to get started.'
                    }
                  </p>
                  {!searchQuery.trim() && (
                    <button
                      onClick={() => setShowCreateDocument(true)}
                      disabled={!currentWorkspace}
                      className="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Document
                    </button>
                  )}
                </div>
              ) : (
                <div className={`divide-y ${isDark ? 'divide-gray-700' : 'divide-gray-200'}`}>
                  {filteredDocuments.map((doc) => (
                    <Link
                      key={doc.id}
                      to={`/document/${doc.id}`}
                      className={`block p-4 transition-colors document-card ${isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="flex-shrink-0">
                            <FileText className={`h-5 w-5 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className={`text-sm font-medium truncate ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                              {doc.title}
                            </p>
                            <div className={`flex items-center mt-1 space-x-2 text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                              <span>{doc.workspace?.name}</span>
                              <span>•</span>
                              <span>{formatDate(doc.updatedAt)}</span>
                              {doc.isFavorite && (
                                <>
                                  <span>•</span>
                                  <Star className="h-3 w-3 text-yellow-500" />
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {doc.author && (
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${isDark ? 'bg-blue-500' : 'bg-blue-600'}`}>
                              <span className="text-white text-xs font-medium">
                                {doc.author.name.charAt(0).toUpperCase()}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Workspaces */}
            <div>
              <h3 className={`text-lg font-semibold mb-3 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                Your Workspaces
              </h3>
              <div className="space-y-2">
                {isLoadingWorkspaces ? (
                  <div className="animate-pulse space-y-2">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className={`h-12 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-200'}`}></div>
                    ))}
                  </div>
                ) : workspaces.length === 0 ? (
                  <div 
                    className={`text-center p-4 rounded-lg border transition-colors ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}`}
                    style={cardStyle}
                  >
                    <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      No workspaces yet
                    </p>
                  </div>
                ) : (
                  workspaces.slice(0, 5).map((workspace) => (
                    <Link
                      key={workspace.id}
                      to={`/workspace/${workspace.id}`}
                      className={`flex items-center p-3 rounded-lg border transition-colors workspace-card ${
                        isDark 
                          ? 'bg-gray-800 border-gray-700 hover:border-blue-400' 
                          : 'bg-white border-gray-200 hover:border-blue-500'
                      }`}
                      style={cardStyle}
                    >
                      <span className="text-lg mr-3">{workspace.icon || '📁'}</span>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium truncate ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                          {workspace.name}
                        </p>
                        <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                          {workspace._count?.documents || 0} documents
                        </p>
                      </div>
                    </Link>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Modals */}
        <CreateWorkspaceModal 
          isOpen={showCreateWorkspace} 
          onClose={() => setShowCreateWorkspace(false)} 
        />
        <CreateDocumentModal 
          isOpen={showCreateDocument} 
          onClose={() => setShowCreateDocument(false)} 
        />
      </div>
    </div>
  )
}

export default DashboardPage