﻿// API Response types
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
  pagination?: PaginationMeta;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

// User types
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  user: User;
  token: string;
  expiresIn: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  name: string;
  password: string;
  avatar?: string;
}

// Workspace types
export interface Workspace {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  isPublic: boolean;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
  owner?: {
    id: string;
    name: string;
    avatar?: string;
  };
  members?: WorkspaceMember[];
  _count?: {
    members: number;
    documents: number;
  };
}

export interface WorkspaceMember {
  id: string;
  userId: string;
  workspaceId: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER' | 'VIEWER';
  joinedAt: string;
  user: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
}

export interface CreateWorkspaceData {
  name: string;
  description?: string;
  icon?: string;
  isPublic?: boolean;
}

// Document types
export interface Document {
  id: string;
  title: string;
  mongoId: string;
  isPublic: boolean;
  isArchived: boolean;
  isFavorite: boolean;
  parentId?: string;
  authorId: string;
  workspaceId: string;
  createdAt: string;
  updatedAt: string;
  author?: {
    id: string;
    name: string;
    avatar?: string;
  };
  workspace?: {
    id: string;
    name: string;
  };
  parent?: {
    id: string;
    title: string;
  };
  children?: Array<{
    id: string;
    title: string;
    updatedAt: string;
  }>;
  _count?: {
    children: number;
  };
}

export interface CreateDocumentData {
  title: string;
  workspaceId: string;
  parentId?: string;
  isPublic?: boolean;
}

// Document Content types
export interface RichText {
  type: 'text' | 'mention' | 'equation';
  text?: {
    content: string;
    link?: { url: string };
  };
  annotations: {
    bold?: boolean;
    italic?: boolean;
    strikethrough?: boolean;
    underline?: boolean;
    code?: boolean;
    color?: string;
    href?: string;
  };
  plain_text: string;
  href?: string;
}

export interface Block {
  id: string;
  type: string;
  created_time: string;
  last_edited_time: string;
  archived: boolean;
  has_children: boolean;
  parent_id?: string;
  [key: string]: any;
}

export interface DocumentContent {
  id: string;
  postgresql_id: string;
  title: string;
  icon?: {
    type: 'emoji' | 'file' | 'external';
    emoji?: string;
    file?: { url: string };
    external?: { url: string };
  };
  cover?: {
    type: 'external' | 'file';
    external?: { url: string };
    file?: { url: string };
  };
  blocks: Block[];
  current_version: number;
  last_edited_time: string;
  last_edited_by: string;
  created_time: string;
  created_by: string;
}

// AI types
export interface AIGenerateRequest {
  prompt: string;
  context?: string;
  type: 'complete' | 'improve' | 'summarize' | 'translate' | 'custom';
  max_tokens?: number;
  temperature?: number;
}

export interface AIGenerateResponse {
  content: string;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

// Upload types
export interface UploadedFile {
  public_id: string;
  url: string;
  format: string;
  resource_type: string;
  bytes: number;
  width?: number;
  height?: number;
}
