import React, { useState } from 'react'
import {
  Sparkles,
  FileText,
  Lightbulb,
  Languages,
  Wand2,
  ArrowRight,
  Zap,
  List
} from 'lucide-react'
import { useAI } from '../../hooks/useAI'
import AIStatus from './AIStatus'
import { useNavigate } from 'react-router-dom'
import { useDocuments } from '../../hooks/useDocuments'
import { toast } from 'sonner'

interface AIDashboardWidgetProps {
  className?: string
}

const AIDashboardWidget: React.FC<AIDashboardWidgetProps> = ({ className = '' }) => {
  const [selectedPrompt, setSelectedPrompt] = useState('')
  const [isCreating, setIsCreating] = useState(false)
  
  const navigate = useNavigate()
  const { isAIAvailable, generateContent } = useAI()
  const { createDocumentAsync } = useDocuments()

  const aiPrompts = [
    {
      id: 'blog-post',
      title: 'Blog Post',
      description: 'Write a comprehensive blog post',
      icon: FileText,
      prompt: 'Write a detailed blog post about',
      color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
    },
    {
      id: 'project-plan',
      title: 'Project Plan',
      description: 'Create a detailed project plan',
      icon: List,
      prompt: 'Create a detailed project plan for',
      color: 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300'
    },
    {
      id: 'creative-story',
      title: 'Creative Story',
      description: 'Write a creative story',
      icon: Sparkles,
      prompt: 'Write a creative story about',
      color: 'bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
    },
    {
      id: 'meeting-agenda',
      title: 'Meeting Agenda',
      description: 'Draft a meeting agenda',
      icon: FileText,
      prompt: 'Create a meeting agenda for',
      color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300'
    },
    {
      id: 'research-outline',
      title: 'Research Outline',
      description: 'Generate research outline',
      icon: Lightbulb,
      prompt: 'Create a research outline for',
      color: 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-300'
    },
    {
      id: 'email-template',
      title: 'Email Template',
      description: 'Write professional email',
      icon: Wand2,
      prompt: 'Write a professional email about',
      color: 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300'
    }
  ]

  const handleCreateWithAI = async (prompt: any) => {
    if (!selectedPrompt.trim()) {
      toast.error('Please enter a topic or description')
      return
    }

    setIsCreating(true)
    try {
      // Generate content with AI
      const aiResponse = await generateContent({
        prompt: `${prompt.prompt} ${selectedPrompt}`,
        type: 'custom',
        temperature: 0.7,
        max_tokens: 1500
      })

      // Find a workspace (you might want to make this configurable)
      const userWorkspaces = JSON.parse(localStorage.getItem('app-storage') || '{}')?.state?.user?.workspaces
      const defaultWorkspace = userWorkspaces?.[0]?.id

      if (!defaultWorkspace) {
        toast.error('Please create a workspace first')
        return
      }

      // Create new document
      const newDocument = await createDocumentAsync({
        title: `${prompt.title}: ${selectedPrompt}`,
        workspaceId: defaultWorkspace,
        isPublic: false
      })

      // Navigate to the document with AI-generated content
      toast.success('AI document created successfully!')
      navigate(`/document/${newDocument.id}`)

    } catch (error) {
      console.error('Failed to create AI document:', error)
      toast.error('Failed to create document with AI')
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              AI Assistant
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Create documents with AI help
            </p>
          </div>
        </div>
        
        <AIStatus showText={false} />
      </div>

      {!isAIAvailable ? (
        <div className="text-center py-8">
          <Zap className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 dark:text-gray-400">
            AI service is currently unavailable
          </p>
          <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
            Please check your connection and try again
          </p>
        </div>
      ) : (
        <>
          {/* Quick Prompt Input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              What would you like to create?
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={selectedPrompt}
                onChange={(e) => setSelectedPrompt(e.target.value)}
                placeholder="e.g., sustainable energy solutions, team meeting planning..."
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                disabled={isCreating}
              />
            </div>
          </div>

          {/* AI Prompt Templates */}
          <div className="grid grid-cols-2 gap-3">
            {aiPrompts.map((prompt) => {
              const Icon = prompt.icon
              
              return (
                <button
                  key={prompt.id}
                  onClick={() => handleCreateWithAI(prompt)}
                  disabled={!selectedPrompt.trim() || isCreating}
                  className={`relative p-4 rounded-lg border border-gray-200 dark:border-gray-600 text-left hover:shadow-md transition-all disabled:opacity-50 disabled:cursor-not-allowed ${prompt.color}`}
                >
                  <div className="flex items-start space-x-3">
                    <Icon className="h-5 w-5 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm">{prompt.title}</h4>
                      <p className="text-xs opacity-75 mt-1">{prompt.description}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 opacity-50" />
                  </div>
                  
                  {isCreating && (
                    <div className="absolute inset-0 bg-white dark:bg-gray-800 bg-opacity-75 rounded-lg flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-purple-500"></div>
                    </div>
                  )}
                </button>
              )
            })}
          </div>

          {/* Usage Tip */}
          <div className="mt-6 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              💡 <strong>Tip:</strong> Be specific in your description for better AI-generated content. 
              You can always edit and improve the generated text later.
            </p>
          </div>
        </>
      )}
    </div>
  )
}

export default AIDashboardWidget