import React, { useState, useEffect } from 'react'
import {
  Sparkles,
  Wand2,
  FileText,
  Languages,
  Lightbulb,
  Zap,
  MoreHorizontal
} from 'lucide-react'
import { useAI } from '../../hooks/useAI'
import { toast } from 'sonner'

interface AIContextMenuProps {
  isVisible: boolean
  position: { x: number; y: number }
  selectedText: string
  onClose: () => void
  onReplaceText: (newText: string) => void
  onInsertText: (text: string) => void
  onOpenFullAssistant: () => void
}

interface QuickAction {
  id: string
  name: string
  icon: React.ComponentType<{ className?: string }>
  action: () => Promise<void>
  color: string
}

const AIContextMenu: React.FC<AIContextMenuProps> = ({
  isVisible,
  position,
  selectedText,
  onClose,
  onReplaceText,
  onInsertText,
  onOpenFullAssistant
}) => {
  const [isLoading, setIsLoading] = useState<string | null>(null)
  const [showMore, setShowMore] = useState(false)

  const {
    isAIAvailable,
    completeText,
    improveText,
    summarizeText,
    translateText,
    brainstormIdeas
  } = useAI()

  useEffect(() => {
    if (!isVisible) {
      setShowMore(false)
      setIsLoading(null)
    }
  }, [isVisible])

  const executeAction = async (actionId: string, action: () => Promise<string | string[]>) => {
    if (!selectedText.trim() || isLoading) return

    setIsLoading(actionId)
    try {
      const result = await action()
      const textResult = Array.isArray(result) ? result.join('\n• ') : result
      
      // Auto-replace for improvements, translations, etc.
      if (['improve', 'translate', 'fix'].includes(actionId)) {
        onReplaceText(Array.isArray(result) ? '• ' + textResult : textResult)
        toast.success(`Text ${actionId}d successfully`)
      } else {
        // Insert for summaries, completions, etc.
        onInsertText(Array.isArray(result) ? '• ' + textResult : textResult)
        toast.success(`${actionId.charAt(0).toUpperCase() + actionId.slice(1)} inserted`)
      }
      
      onClose()
    } catch (error) {
      console.error(`AI ${actionId} failed:`, error)
      toast.error(`Failed to ${actionId} text`)
    } finally {
      setIsLoading(null)
    }
  }

  const quickActions: QuickAction[] = [
    {
      id: 'improve',
      name: 'Improve',
      icon: Zap,
      color: 'text-blue-600',
      action: () => executeAction('improve', () => improveText(selectedText))
    },
    {
      id: 'complete',
      name: 'Complete',
      icon: Wand2,
      color: 'text-green-600',
      action: () => executeAction('complete', () => completeText(selectedText))
    },
    {
      id: 'summarize',
      name: 'Summarize',
      icon: FileText,
      color: 'text-purple-600',
      action: () => executeAction('summarize', () => summarizeText(selectedText, 'medium'))
    },
    {
      id: 'translate',
      name: 'Translate',
      icon: Languages,
      color: 'text-orange-600',
      action: () => executeAction('translate', () => translateText(selectedText, 'Spanish'))
    }
  ]

  const moreActions: QuickAction[] = [
    {
      id: 'ideas',
      name: 'Ideas',
      icon: Lightbulb,
      color: 'text-yellow-600',
      action: () => executeAction('ideas', () => brainstormIdeas(selectedText, 5))
    },
    {
      id: 'formal',
      name: 'Make Formal',
      icon: Zap,
      color: 'text-indigo-600',
      action: () => executeAction('formal', () => improveText(selectedText, 'make this more formal and professional'))
    },
    {
      id: 'casual',
      name: 'Make Casual',
      icon: Zap,
      color: 'text-pink-600',
      action: () => executeAction('casual', () => improveText(selectedText, 'make this more casual and friendly'))
    },
    {
      id: 'expand',
      name: 'Expand',
      icon: Wand2,
      color: 'text-emerald-600',
      action: () => executeAction('expand', () => improveText(selectedText, 'expand this with more details and examples'))
    }
  ]

  if (!isVisible || !selectedText.trim()) return null

  // Calculate menu position to keep it on screen
  const menuWidth = showMore ? 240 : 200
  const menuHeight = showMore ? 280 : 200
  
  let adjustedX = position.x
  let adjustedY = position.y + 10 // Small offset below cursor

  // Adjust horizontal position
  if (adjustedX + menuWidth > window.innerWidth) {
    adjustedX = window.innerWidth - menuWidth - 10
  }

  // Adjust vertical position
  if (adjustedY + menuHeight > window.innerHeight) {
    adjustedY = position.y - menuHeight - 10 // Show above cursor
  }

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 z-[9998]" 
        onClick={onClose}
      />
      
      {/* Menu */}
      <div
        className="fixed z-[9999] bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 py-2 min-w-[200px]"
        style={{
          left: `${adjustedX}px`,
          top: `${adjustedY}px`,
        }}
      >
        {/* Header */}
        <div className="px-3 py-2 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-4 w-4 text-purple-500" />
            <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
              AI Actions
            </span>
            {!isAIAvailable && (
              <span className="text-xs text-red-500">(Offline)</span>
            )}
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            {selectedText.length > 50 
              ? `"${selectedText.slice(0, 50)}..."`
              : `"${selectedText}"`
            }
          </p>
        </div>

        {/* Quick Actions */}
        <div className="py-1">
          {quickActions.map((action) => {
            const Icon = action.icon
            const isCurrentlyLoading = isLoading === action.id
            
            return (
              <button
                key={action.id}
                onClick={action.action}
                disabled={!isAIAvailable || isLoading !== null}
                className="w-full flex items-center px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isCurrentlyLoading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-500 mr-3" />
                ) : (
                  <Icon className={`h-4 w-4 mr-3 ${action.color}`} />
                )}
                <span>{action.name}</span>
                {isCurrentlyLoading && (
                  <span className="ml-auto text-xs text-gray-500">Working...</span>
                )}
              </button>
            )
          })}
        </div>

        {/* More Actions */}
        {showMore && (
          <div className="border-t border-gray-200 dark:border-gray-700 py-1">
            {moreActions.map((action) => {
              const Icon = action.icon
              const isCurrentlyLoading = isLoading === action.id
              
              return (
                <button
                  key={action.id}
                  onClick={action.action}
                  disabled={!isAIAvailable || isLoading !== null}
                  className="w-full flex items-center px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {isCurrentlyLoading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-500 mr-3" />
                  ) : (
                    <Icon className={`h-4 w-4 mr-3 ${action.color}`} />
                  )}
                  <span>{action.name}</span>
                  {isCurrentlyLoading && (
                    <span className="ml-auto text-xs text-gray-500">Working...</span>
                  )}
                </button>
              )
            })}
          </div>
        )}

        {/* Footer Actions */}
        <div className="border-t border-gray-200 dark:border-gray-700 py-1">
          <button
            onClick={() => setShowMore(!showMore)}
            className="w-full flex items-center px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <MoreHorizontal className="h-4 w-4 mr-3 text-gray-500" />
            {showMore ? 'Show Less' : 'More Actions'}
          </button>
          
          <button
            onClick={onOpenFullAssistant}
            className="w-full flex items-center px-3 py-2 text-sm text-purple-700 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors"
          >
            <Sparkles className="h-4 w-4 mr-3" />
            Open AI Assistant
          </button>
        </div>

        {/* Character limit warning */}
        {selectedText.length > 2000 && (
          <div className="px-3 py-2 bg-yellow-50 dark:bg-yellow-900/20 border-t border-gray-200 dark:border-gray-700">
            <p className="text-xs text-yellow-700 dark:text-yellow-400">
              ⚠️ Selected text is very long ({selectedText.length} chars). Some actions may be slower.
            </p>
          </div>
        )}
      </div>
    </>
  )
}

export default AIContextMenu