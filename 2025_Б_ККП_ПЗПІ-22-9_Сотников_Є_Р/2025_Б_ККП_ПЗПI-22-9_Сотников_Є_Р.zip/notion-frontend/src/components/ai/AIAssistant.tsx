import React, { useState, useRef, useEffect } from 'react'
import {
  Sparkles,
  Wand2,
  FileText,
  Languages,
  Lightbulb,
  List,
  X,
  Send,
  Copy,
  Check,
  AlertCircle,
  Zap
} from 'lucide-react'
import { useAI } from '../../hooks/useAI'
import { toast } from 'sonner'

interface AIAssistantProps {
  isOpen: boolean
  onClose: () => void
  selectedText?: string
  onInsertText?: (text: string) => void
  onReplaceText?: (text: string) => void
  documentContext?: string
}

type AIMode = 'chat' | 'complete' | 'improve' | 'summarize' | 'translate' | 'brainstorm' | 'outline'

const AIAssistant: React.FC<AIAssistantProps> = ({
  isOpen,
  onClose,
  selectedText = '',
  onInsertText,
  onReplaceText,
  documentContext = ''
}) => {
  const [mode, setMode] = useState<AIMode>('chat')
  const [prompt, setPrompt] = useState('')
  const [result, setResult] = useState('')
  const [copied, setCopied] = useState(false)
  const [targetLanguage, setTargetLanguage] = useState('Spanish')
  const [summaryLength, setSummaryLength] = useState<'short' | 'medium' | 'long'>('medium')
  const [brainstormCount, setBrainstormCount] = useState(5)
  const [outlineDepth, setOutlineDepth] = useState<'basic' | 'detailed'>('basic')
  const [improvement, setImprovement] = useState('')

  const inputRef = useRef<HTMLTextAreaElement>(null)

  const {
    isAIAvailable,
    isAIWorking,
    completeText,
    improveText,
    summarizeText,
    translateText,
    brainstormIdeas,
    generateOutline,
    generateContent
  } = useAI()

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen, mode])

  useEffect(() => {
    // Auto-set prompt based on selected text and mode
    if (selectedText) {
      switch (mode) {
        case 'complete':
          setPrompt(selectedText)
          break
        case 'improve':
          setPrompt(selectedText)
          break
        case 'summarize':
          setPrompt(selectedText)
          break
        case 'translate':
          setPrompt(selectedText)
          break
        case 'brainstorm':
          setPrompt(selectedText || 'Generate ideas about...')
          break
        case 'outline':
          setPrompt(selectedText || 'Create outline for...')
          break
        default:
          setPrompt('')
      }
    }
  }, [selectedText, mode])

  const handleSubmit = async () => {
    if (!prompt.trim() || isAIWorking) return

    try {
      let response: string | string[] = ''

      switch (mode) {
        case 'complete':
          response = await completeText(prompt, documentContext)
          break

        case 'improve':
          response = await improveText(prompt, improvement || undefined)
          break

        case 'summarize':
          response = await summarizeText(prompt, summaryLength)
          break

        case 'translate':
          response = await translateText(prompt, targetLanguage)
          break

        case 'brainstorm':
          const ideas = await brainstormIdeas(prompt, brainstormCount)
          response = ideas.join('\n• ')
          response = '• ' + response
          break

        case 'outline':
          response = await generateOutline(prompt, outlineDepth)
          break

        case 'chat':
          const chatResponse = await generateContent({
            prompt,
            context: documentContext,
            type: 'custom',
            temperature: 0.7
          })
          response = chatResponse.content
          break
      }

      setResult(Array.isArray(response) ? response.join('\n') : response)
    } catch (error) {
      console.error('AI request failed:', error)
    }
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast.success('Copied to clipboard')
    } catch (error) {
      toast.error('Failed to copy')
    }
  }

  const handleInsert = () => {
    if (result && onInsertText) {
      onInsertText(result)
      toast.success('Text inserted')
      onClose()
    }
  }

  const handleReplace = () => {
    if (result && onReplaceText) {
      onReplaceText(result)
      toast.success('Text replaced')
      onClose()
    }
  }

  const modes = [
    { id: 'chat' as AIMode, name: 'Chat', icon: Sparkles, description: 'General AI assistant' },
    { id: 'complete' as AIMode, name: 'Complete', icon: Wand2, description: 'Complete your text' },
    { id: 'improve' as AIMode, name: 'Improve', icon: Zap, description: 'Improve writing' },
    { id: 'summarize' as AIMode, name: 'Summarize', icon: FileText, description: 'Create summary' },
    { id: 'translate' as AIMode, name: 'Translate', icon: Languages, description: 'Translate text' },
    { id: 'brainstorm' as AIMode, name: 'Brainstorm', icon: Lightbulb, description: 'Generate ideas' },
    { id: 'outline' as AIMode, name: 'Outline', icon: List, description: 'Create outline' }
  ]

  const languages = [
    'Spanish', 'French', 'German', 'Italian', 'Portuguese', 'Russian', 
    'Chinese', 'Japanese', 'Korean', 'Arabic', 'Hindi', 'Dutch'
  ]

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ zIndex: 1000 }}>
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="absolute right-4 top-4 bottom-4 w-96 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-purple-500" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              AI Assistant
            </h3>
            {!isAIAvailable && (
              <AlertCircle className="h-4 w-4 text-red-500" />
            )}
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mode Selection */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-2 gap-2">
            {modes.map((modeOption) => {
              const Icon = modeOption.icon
              return (
                <button
                  key={modeOption.id}
                  onClick={() => setMode(modeOption.id)}
                  className={`p-2 rounded-lg text-left transition-colors ${
                    mode === modeOption.id
                      ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300'
                      : 'bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Icon className="h-4 w-4" />
                    <span className="text-sm font-medium">{modeOption.name}</span>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {modeOption.description}
                  </p>
                </button>
              )
            })}
          </div>
        </div>

        {/* Mode-specific Options */}
        {mode === 'translate' && (
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Target Language
            </label>
            <select
              value={targetLanguage}
              onChange={(e) => setTargetLanguage(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm"
            >
              {languages.map((lang) => (
                <option key={lang} value={lang}>{lang}</option>
              ))}
            </select>
          </div>
        )}

        {mode === 'summarize' && (
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Summary Length
            </label>
            <div className="flex space-x-2">
              {(['short', 'medium', 'long'] as const).map((length) => (
                <button
                  key={length}
                  onClick={() => setSummaryLength(length)}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    summaryLength === length
                      ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  {length.charAt(0).toUpperCase() + length.slice(1)}
                </button>
              ))}
            </div>
          </div>
        )}

        {mode === 'brainstorm' && (
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Number of Ideas
            </label>
            <input
              type="number"
              min="3"
              max="20"
              value={brainstormCount}
              onChange={(e) => setBrainstormCount(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm"
            />
          </div>
        )}

        {mode === 'outline' && (
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Detail Level
            </label>
            <div className="flex space-x-2">
              {(['basic', 'detailed'] as const).map((depth) => (
                <button
                  key={depth}
                  onClick={() => setOutlineDepth(depth)}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    outlineDepth === depth
                      ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  {depth.charAt(0).toUpperCase() + depth.slice(1)}
                </button>
              ))}
            </div>
          </div>
        )}

        {mode === 'improve' && (
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Improvement Instructions (Optional)
            </label>
            <input
              type="text"
              value={improvement}
              onChange={(e) => setImprovement(e.target.value)}
              placeholder="e.g., make it more formal, add more details..."
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm"
            />
          </div>
        )}

        {/* Input Area */}
        <div className="flex-1 flex flex-col p-4">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {mode === 'complete' ? 'Text to Complete' :
             mode === 'improve' ? 'Text to Improve' :
             mode === 'summarize' ? 'Text to Summarize' :
             mode === 'translate' ? 'Text to Translate' :
             mode === 'brainstorm' ? 'Topic for Ideas' :
             mode === 'outline' ? 'Topic for Outline' :
             'Your Message'}
          </label>
          
          <div className="flex-1 flex flex-col">
            <textarea
              ref={inputRef}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={`${mode === 'chat' ? 'Ask me anything...' : `Enter text to ${mode}...`}`}
              className="flex-1 min-h-[100px] px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm resize-none"
              disabled={isAIWorking}
            />
            
            <button
              onClick={handleSubmit}
              disabled={!prompt.trim() || isAIWorking || !isAIAvailable}
              className="mt-3 flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isAIWorking ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  {mode === 'chat' ? 'Send' : mode.charAt(0).toUpperCase() + mode.slice(1)}
                </>
              )}
            </button>

            {!isAIAvailable && (
              <p className="mt-2 text-xs text-red-600 dark:text-red-400">
                AI service is currently unavailable
              </p>
            )}
          </div>
        </div>

        {/* Result Area */}
        {result && (
          <div className="border-t border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Result
              </span>
              <div className="flex space-x-2">
                <button
                  onClick={handleCopy}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  title="Copy"
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </button>
                {onInsertText && (
                  <button
                    onClick={handleInsert}
                    className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm"
                  >
                    Insert
                  </button>
                )}
                {onReplaceText && selectedText && (
                  <button
                    onClick={handleReplace}
                    className="text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 text-sm"
                  >
                    Replace
                  </button>
                )}
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 max-h-40 overflow-y-auto">
              <pre className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                {result}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default AIAssistant