import React from 'react'
import { Sparkles, AlertCircle, CheckCircle, Loader } from 'lucide-react'
import { useAI } from '../../hooks/useAI'

interface AIStatusProps {
  showText?: boolean
  className?: string
}

const AIStatus: React.FC<AIStatusProps> = ({ 
  showText = true, 
  className = '' 
}) => {
  const { isAIAvailable, isCheckingHealth, isAIWorking } = useAI()

  if (isCheckingHealth) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <Loader className="h-4 w-4 animate-spin text-gray-500" />
        {showText && (
          <span className="text-sm text-gray-500">Checking AI...</span>
        )}
      </div>
    )
  }

  if (!isAIAvailable) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <AlertCircle className="h-4 w-4 text-red-500" />
        {showText && (
          <span className="text-sm text-red-600 dark:text-red-400">
            AI Offline
          </span>
        )}
      </div>
    )
  }

  if (isAIWorking) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <Sparkles className="h-4 w-4 animate-pulse text-purple-500" />
        {showText && (
          <span className="text-sm text-purple-600 dark:text-purple-400">
            AI Working...
          </span>
        )}
      </div>
    )
  }

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <CheckCircle className="h-4 w-4 text-green-500" />
      {showText && (
        <span className="text-sm text-green-600 dark:text-green-400">
          AI Ready
        </span>
      )}
    </div>
  )
}

export default AIStatus