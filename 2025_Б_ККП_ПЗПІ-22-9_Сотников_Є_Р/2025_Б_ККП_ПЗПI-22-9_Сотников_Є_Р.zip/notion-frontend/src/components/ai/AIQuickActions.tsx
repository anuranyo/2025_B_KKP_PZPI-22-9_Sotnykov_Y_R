import React, { useState } from 'react'
import {
  Sparkles,
  Wand2,
  FileText,
  Languages,
  Lightbulb,
  List,
  Zap,
  ChevronDown,
  Loader
} from 'lucide-react'
import { useAI } from '../../hooks/useAI'
import { toast } from 'sonner'

interface AIQuickActionsProps {
  onAIResult: (result: string, action: string) => void
  selectedText?: string
  documentContext?: string
  className?: string
}

const AIQuickActions: React.FC<AIQuickActionsProps> = ({
  onAIResult,
  selectedText = '',
  documentContext = '',
  className = ''
}) => {
  const [isExpanded, setIsExpanded] = useState(false)
  const [activeAction, setActiveAction] = useState<string | null>(null)

  const {
    isAIAvailable,
    completeText,
    improveText,
    summarizeText,
    translateText,
    brainstormIdeas,
    generateOutline
  } = useAI()

  const quickActions = [
    {
      id: 'complete',
      name: 'Complete',
      icon: Wand2,
      color: 'text-green-600',
      description: 'Continue writing',
      action: async () => {
        const prompt = selectedText || 'Continue this document'
        return await completeText(prompt, documentContext)
      }
    },
    {
      id: 'improve',
      name: 'Improve',
      icon: Zap,
      color: 'text-blue-600',
      description: 'Enhance writing',
      action: async () => {
        if (!selectedText) {
          toast.error('Please select text to improve')
          return null
        }
        return await improveText(selectedText)
      }
    },
    {
      id: 'summarize',
      name: 'Summarize',
      icon: FileText,
      color: 'text-purple-600',
      description: 'Create summary',
      action: async () => {
        if (!selectedText && !documentContext) {
          toast.error('Please select text or provide document context')
          return null
        }
        return await summarizeText(selectedText || documentContext, 'medium')
      }
    },
    {
      id: 'translate',
      name: 'Translate',
      icon: Languages,
      color: 'text-orange-600',
      description: 'Translate to Spanish',
      action: async () => {
        if (!selectedText) {
          toast.error('Please select text to translate')
          return null
        }
        return await translateText(selectedText, 'Spanish')
      }
    }
  ]

  const expandedActions = [
    {
      id: 'brainstorm',
      name: 'Ideas',
      icon: Lightbulb,
      color: 'text-yellow-600',
      description: 'Generate ideas',
      action: async () => {
        const topic = selectedText || 'Generate creative ideas'
        const ideas = await brainstormIdeas(topic, 5)
        return ideas.join('\n• ')
      }
    },
    {
      id: 'outline',
      name: 'Outline',
      icon: List,
      color: 'text-indigo-600',
      description: 'Create outline',
      action: async () => {
        const topic = selectedText || 'Create an outline'
        return await generateOutline(topic, 'basic')
      }
    }
  ]

  const handleAction = async (action: any) => {
    if (!isAIAvailable || activeAction) return

    setActiveAction(action.id)
    try {
      const result = await action.action()
      if (result) {
        onAIResult(result, action.name)
        toast.success(`${action.name} completed successfully`)
      }
    } catch (error) {
      console.error(`AI ${action.id} failed:`, error)
      toast.error(`Failed to ${action.name.toLowerCase()}`)
    } finally {
      setActiveAction(null)
    }
  }

  const allActions = isExpanded ? [...quickActions, ...expandedActions] : quickActions

  if (!isAIAvailable) {
    return (
      <div className={`flex items-center px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg ${className}`}>
        <Sparkles className="h-4 w-4 text-gray-400 mr-2" />
        <span className="text-sm text-gray-500">AI Offline</span>
      </div>
    )
  }

  return (
    <div className={`flex items-center space-x-1 ${className}`}>
      {/* Quick Actions */}
      {allActions.map((action) => {
        const Icon = action.icon
        const isLoading = activeAction === action.id
        
        return (
          <button
            key={action.id}
            onClick={() => handleAction(action)}
            disabled={Boolean(activeAction)}
            className={`relative flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              isLoading
                ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300'
                : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-600'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
            title={action.description}
          >
            {isLoading ? (
              <Loader className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Icon className={`h-4 w-4 mr-2 ${action.color}`} />
            )}
            <span className="hidden sm:inline">{action.name}</span>
            
            {isLoading && (
              <div className="absolute inset-0 bg-white dark:bg-gray-800 bg-opacity-75 rounded-lg flex items-center justify-center">
                <Loader className="h-4 w-4 animate-spin text-purple-600" />
              </div>
            )}
          </button>
        )
      })}

      {/* Expand/Collapse Button */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center px-2 py-2 rounded-lg bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-600 transition-colors"
        title={isExpanded ? 'Show less' : 'Show more AI actions'}
      >
        <ChevronDown className={`h-4 w-4 text-gray-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
      </button>

      {/* AI Status Indicator */}
      <div className="flex items-center px-2">
        <Sparkles className="h-3 w-3 text-green-500" />
      </div>
    </div>
  )
}

export default AIQuickActions