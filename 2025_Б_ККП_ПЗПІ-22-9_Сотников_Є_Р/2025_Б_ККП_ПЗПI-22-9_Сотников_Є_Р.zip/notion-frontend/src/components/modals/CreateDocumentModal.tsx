import React, { useEffect, useRef } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X, FileText, Globe, Lock, Folder } from 'lucide-react'
import { useDocuments } from '../../hooks/useDocuments'
import { useWorkspaces } from '../../hooks/useWorkspaces'
import { useAppStore } from '../../store/useAppStore'
import type { CreateDocumentData } from '../../types'

const documentSchema = z.object({
  title: z.string().min(1, 'Document title is required').max(200, 'Title cannot exceed 200 characters'),
  workspaceId: z.string().min(1, 'Please select a workspace'),
  parentId: z.string().optional(),
  isPublic: z.boolean(),
})

interface CreateDocumentModalProps {
  isOpen: boolean
  onClose: () => void
  parentDocumentId?: string
}

const CreateDocumentModal: React.FC<CreateDocumentModalProps> = ({ 
  isOpen, 
  onClose, 
  parentDocumentId 
}) => {
  const { createDocument, isCreatingDocument } = useDocuments()
  const { workspaces } = useWorkspaces()
  const { currentWorkspace } = useAppStore()
  const modalRef = useRef<HTMLDivElement>(null)
  const titleInputRef = useRef<HTMLInputElement>(null)

  const {
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
    control,
    getValues,
  } = useForm<CreateDocumentData>({
    resolver: zodResolver(documentSchema),
    defaultValues: {
      title: '',
      isPublic: false,
      workspaceId: currentWorkspace?.id || '',
      parentId: parentDocumentId || undefined,
    }
  })

  const selectedWorkspaceId = watch('workspaceId')
  const currentValues = watch()

  console.log('Document form values:', currentValues)
  console.log('Document form errors:', errors)

  useEffect(() => {
    if (isOpen && titleInputRef.current) {
      setTimeout(() => {
        titleInputRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  useEffect(() => {
    if (currentWorkspace) {
      setValue('workspaceId', currentWorkspace.id)
    }
  }, [currentWorkspace, setValue])

  useEffect(() => {
    if (parentDocumentId) {
      setValue('parentId', parentDocumentId)
    }
  }, [parentDocumentId, setValue])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener('keydown', handleEscape)
      document.body.style.overflow = 'hidden'
    }

    return () => {
      document.removeEventListener('keydown', handleEscape)
      document.body.style.overflow = 'auto'
    }
  }, [isOpen, onClose])

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  const onSubmit = (data: CreateDocumentData) => {
    console.log('Document form submitted with data:', data)
    
    try {
      createDocument(data)
      console.log('createDocument called successfully')
      reset()
      onClose()
    } catch (error) {
      console.error('Error calling createDocument:', error)
    }
  }

  const handleClose = () => {
    reset({
      title: '',
      isPublic: false,
      workspaceId: currentWorkspace?.id || '',
      parentId: parentDocumentId || undefined,
    })
    onClose()
  }

  if (!isOpen) return null

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto"
      onClick={handleBackdropClick}
    >
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        {/* Background overlay */}
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />

        {/* Modal */}
        <div
          ref={modalRef}
          className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
              {parentDocumentId ? 'Create Sub-document' : 'Create New Document'}
            </h3>
            <button
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Debug info
          <div className="px-6 py-2 bg-gray-100 text-xs">
            <div>Values: {JSON.stringify(currentValues)}</div>
            <div>Errors: {JSON.stringify(errors)}</div>
            <div>Workspaces count: {workspaces.length}</div>
          </div> */}

          {/* Form */}
          <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
            {/* Title - ИСПРАВЛЕНО */}
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Document title <span className="text-red-500">*</span>
              </label>
              <Controller
                name="title"
                control={control}
                render={({ field }) => (
                  <input
                    {...field}
                    ref={titleInputRef}
                    type="text"
                    id="title"
                    autoComplete="off"
                    placeholder="Enter document title"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onChange={(e) => {
                      console.log('Document title changed:', e.target.value)
                      field.onChange(e.target.value)
                    }}
                  />
                )}
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
              )}
            </div>

            {/* Workspace Selection - ИСПРАВЛЕНО */}
            <div>
              <label htmlFor="workspaceId" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Workspace <span className="text-red-500">*</span>
              </label>
              <Controller
                name="workspaceId"
                control={control}
                render={({ field }) => (
                  <select
                    {...field}
                    id="workspaceId"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onChange={(e) => {
                      console.log('Workspace selected:', e.target.value)
                      field.onChange(e.target.value)
                    }}
                  >
                    <option value="">Select a workspace</option>
                    {workspaces.map((workspace) => (
                      <option key={workspace.id} value={workspace.id}>
                        {workspace.icon} {workspace.name}
                      </option>
                    ))}
                  </select>
                )}
              />
              {errors.workspaceId && (
                <p className="mt-1 text-sm text-red-600">{errors.workspaceId.message}</p>
              )}
            </div>

            {/* Parent Document Info */}
            {parentDocumentId && (
              <div className="bg-blue-50 dark:bg-blue-900/50 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                <div className="flex items-center">
                  <Folder className="h-4 w-4 text-blue-600 dark:text-blue-400 mr-2" />
                  <span className="text-sm text-blue-800 dark:text-blue-200">
                    This document will be created as a sub-document
                  </span>
                </div>
              </div>
            )}

            {/* Visibility - ИСПРАВЛЕНО */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Visibility
              </label>
              <Controller
                name="isPublic"
                control={control}
                render={({ field }) => (
                  <div className="space-y-2">
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        checked={!field.value}
                        onChange={() => {
                          console.log('Setting document isPublic to false')
                          field.onChange(false)
                        }}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      <div className="ml-3">
                        <div className="flex items-center">
                          <Lock className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Private</span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Only workspace members can access
                        </p>
                      </div>
                    </label>
                    
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        checked={field.value === true}
                        onChange={() => {
                          console.log('Setting document isPublic to true')
                          field.onChange(true)
                        }}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      <div className="ml-3">
                        <div className="flex items-center">
                          <Globe className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Public</span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Anyone with the link can view
                        </p>
                      </div>
                    </label>
                  </div>
                )}
              />
              {errors.isPublic && (
                <p className="mt-1 text-sm text-red-600">{errors.isPublic.message}</p>
              )}
            </div>

            {/* Template Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Start with a template
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  className="p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-colors text-left"
                >
                  <div className="text-sm font-medium text-gray-900 dark:text-gray-100">📄 Blank</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Start with empty page</div>
                </button>
                
                <button
                  type="button"
                  className="p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-colors text-left"
                >
                  <div className="text-sm font-medium text-gray-900 dark:text-gray-100">📝 Meeting Notes</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Template for meetings</div>
                </button>
                
                <button
                  type="button"
                  className="p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-colors text-left"
                >
                  <div className="text-sm font-medium text-gray-900 dark:text-gray-100">📋 Project Plan</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Planning template</div>
                </button>
                
                <button
                  type="button"
                  className="p-3 border border-gray-300 dark:border-gray-600 rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-colors text-left"
                >
                  <div className="text-sm font-medium text-gray-900 dark:text-gray-100">📊 Report</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Report template</div>
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={handleClose}
                disabled={isCreatingDocument}
                className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isCreatingDocument || !selectedWorkspaceId}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                onClick={(e) => {
                  console.log('Document submit button clicked, current values:', getValues())
                }}
              >
                {isCreatingDocument ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <FileText className="h-4 w-4 mr-2" />
                    Create Document
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default CreateDocumentModal