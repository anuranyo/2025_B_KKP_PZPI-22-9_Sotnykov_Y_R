import React, { useEffect, useRef } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X, Folder, Globe, Lock } from 'lucide-react'
import { useWorkspaces } from '../../hooks/useWorkspaces'
import type { CreateWorkspaceData } from '../../types'

const workspaceSchema = z.object({
  name: z.string().min(1, 'Workspace name is required').max(100, 'Name cannot exceed 100 characters'),
  description: z.string().optional(),
  icon: z.string().optional(),
  isPublic: z.boolean(),
})

interface CreateWorkspaceModalProps {
  isOpen: boolean
  onClose: () => void
}

const emojiOptions = ['📁', '🚀', '💼', '🎯', '🏢', '📊', '💡', '🎨', '🔬', '📚', '🌟', '⚡']

const CreateWorkspaceModal: React.FC<CreateWorkspaceModalProps> = ({ isOpen, onClose }) => {
  const { createWorkspace, isCreatingWorkspace } = useWorkspaces()
  const modalRef = useRef<HTMLDivElement>(null)
  const nameInputRef = useRef<HTMLInputElement>(null)

  const {
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
    control,
    getValues,
  } = useForm<CreateWorkspaceData>({
    resolver: zodResolver(workspaceSchema),
    defaultValues: {
      name: '',
      description: '',
      icon: '📁',
      isPublic: false
    }
  })

  const selectedIcon = watch('icon')
  const isPublic = watch('isPublic')
  const currentValues = watch()

  console.log('Form current values:', currentValues)
  console.log('Form errors:', errors)

  useEffect(() => {
    if (isOpen && nameInputRef.current) {
      setTimeout(() => {
        nameInputRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener('keydown', handleEscape)
      document.body.style.overflow = 'hidden'
    }

    return () => {
      document.removeEventListener('keydown', handleEscape)
      document.body.style.overflow = 'auto'
    }
  }, [isOpen, onClose])

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  const onSubmit = (data: CreateWorkspaceData) => {
    console.log('Form submitted with data:', data)
    
    try {
      createWorkspace(data)
      console.log('createWorkspace called successfully')
      reset()
      onClose()
    } catch (error) {
      console.error('Error calling createWorkspace:', error)
    }
  }

  const handleClose = () => {
    reset({
      name: '',
      description: '',
      icon: '📁',
      isPublic: false
    })
    onClose()
  }

  if (!isOpen) return null

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto"
      onClick={handleBackdropClick}
    >
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        {/* Background overlay */}
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />

        {/* Modal */}
        <div
          ref={modalRef}
          className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
              Create New Workspace
            </h3>
            <button
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Debug info
          <div className="px-6 py-2 bg-gray-100 text-xs">
            <div>Values: {JSON.stringify(currentValues)}</div>
            <div>Errors: {JSON.stringify(errors)}</div>
            <div>isPublic: {String(isPublic)}</div>
          </div> */}

          {/* Form */}
          <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
            {/* Icon Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Choose an icon
              </label>
              <div className="grid grid-cols-6 gap-2">
                {emojiOptions.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => {
                      console.log('Icon selected:', emoji)
                      setValue('icon', emoji)
                    }}
                    className={`
                      w-10 h-10 text-lg rounded-lg border-2 transition-colors
                      ${selectedIcon === emoji
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/50'
                        : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
                      }
                    `}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Name - ИСПРАВЛЕНО */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Workspace name <span className="text-red-500">*</span>
              </label>
              <Controller
                name="name"
                control={control}
                render={({ field }) => (
                  <input
                    {...field}
                    ref={nameInputRef}
                    type="text"
                    id="name"
                    autoComplete="off"
                    placeholder="Enter workspace name"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onChange={(e) => {
                      console.log('Name changed:', e.target.value)
                      field.onChange(e.target.value)
                    }}
                  />
                )}
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Description
              </label>
              <Controller
                name="description"
                control={control}
                render={({ field }) => (
                  <textarea
                    {...field}
                    id="description"
                    rows={3}
                    placeholder="Describe what this workspace is for..."
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                )}
              />
              {errors.description && (
                <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
              )}
            </div>

            {/* Visibility - ПОЛНОСТЬЮ ПЕРЕПИСАНО */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Visibility
              </label>
              <Controller
                name="isPublic"
                control={control}
                render={({ field }) => (
                  <div className="space-y-2">
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        checked={!field.value}
                        onChange={() => {
                          console.log('Setting isPublic to false')
                          field.onChange(false)
                        }}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      <div className="ml-3">
                        <div className="flex items-center">
                          <Lock className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Private</span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Only you and invited members can access
                        </p>
                      </div>
                    </label>
                    
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        checked={field.value === true}
                        onChange={() => {
                          console.log('Setting isPublic to true')
                          field.onChange(true)
                        }}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      <div className="ml-3">
                        <div className="flex items-center">
                          <Globe className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Public</span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Anyone can view and join this workspace
                        </p>
                      </div>
                    </label>
                  </div>
                )}
              />
              {errors.isPublic && (
                <p className="mt-1 text-sm text-red-600">{errors.isPublic.message}</p>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={handleClose}
                disabled={isCreatingWorkspace}
                className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isCreatingWorkspace}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                onClick={(e) => {
                  console.log('Submit button clicked, current form values:', getValues())
                }}
              >
                {isCreatingWorkspace ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <Folder className="h-4 w-4 mr-2" />
                    Create Workspace
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default CreateWorkspaceModal