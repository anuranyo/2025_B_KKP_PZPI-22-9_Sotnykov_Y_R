import { useAppStore } from '../store/useAppStore'
import { useAuth } from '../hooks/useAuth'

const DebugInfo = () => {
  const { user, token, isAuthenticated } = useAppStore()
  const { isLoadingProfile } = useAuth()
  
  const tokenFromStorage = localStorage.getItem('token')
  const appStorageFromLocal = localStorage.getItem('app-storage')
  
  return (
    <div className="fixed top-0 right-0 bg-black bg-opacity-80 text-white p-4 text-xs z-50 max-w-md">
      <h3 className="font-bold mb-2">Debug Info:</h3>
      <div className="space-y-1">
        <div>isAuthenticated: {isAuthenticated ? 'true' : 'false'}</div>
        <div>isLoadingProfile: {isLoadingProfile ? 'true' : 'false'}</div>
        <div>user: {user ? user.name : 'null'}</div>
        <div>token (store): {token ? 'exists' : 'null'}</div>
        <div>token (localStorage): {tokenFromStorage ? 'exists' : 'null'}</div>
        <div>app-storage: {appStorageFromLocal ? 'exists' : 'null'}</div>
        <div>Current URL: {window.location.pathname}</div>
      </div>
    </div>
  )
}

export default DebugInfo