import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { 
  FileText, 
  Home, 
  Search, 
  Settings, 
  Plus, 
  ChevronDown, 
  ChevronRight,
  Star,
  Archive,
  Folder,
  Users
} from 'lucide-react'
import { useAppStore } from '../../store/useAppStore'
import { useWorkspaces } from '../../hooks/useWorkspaces'
import { useDocuments } from '../../hooks/useDocuments'
import CreateWorkspaceModal from '../modals/CreateWorkspaceModal'
import CreateDocumentModal from '../modals/CreateDocumentModal'

const Sidebar: React.FC = () => {
  const location = useLocation()
  const { user, currentWorkspace } = useAppStore()
  const { workspaces, isLoadingWorkspaces } = useWorkspaces()
  const { useRecentDocuments, useFavoriteDocuments } = useDocuments()
  
  const [showCreateWorkspace, setShowCreateWorkspace] = useState(false)
  const [showCreateDocument, setShowCreateDocument] = useState(false)
  const [expandedSections, setExpandedSections] = useState({
    workspaces: true,
    recent: true,
    favorites: true,
  })

  const { data: recentDocuments = [] } = useRecentDocuments(5)
  const { data: favoriteDocuments = [] } = useFavoriteDocuments()

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const isActive = (path: string) => location.pathname === path

  return (
    <div className="w-64 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      {/* User Section */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-medium">
              {user?.name?.charAt(0)?.toUpperCase()}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
              {user?.name}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
              {user?.email}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-2">
        <nav className="space-y-1">
          {/* Dashboard */}
          <Link
            to="/dashboard"
            className={`
              group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors
              ${isActive('/dashboard')
                ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
              }
            `}
          >
            <Home className="mr-3 h-4 w-4" />
            Dashboard
          </Link>

          {/* Settings */}
          <Link
            to="/settings"
            className={`
              group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors
              ${isActive('/settings')
                ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
              }
            `}
          >
            <Settings className="mr-3 h-4 w-4" />
            Settings
          </Link>

          {/* Archived Documents */}
          <Link
            to="/archived"
            className={`
              group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors
              ${isActive('/archived')
                ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
              }
            `}
          >
            <Archive className="mr-3 h-4 w-4" />
            Archived
          </Link>

          <div className="border-t border-gray-200 dark:border-gray-700 my-2"></div>

          {/* Workspaces Section */}
          <div>
            <button
              onClick={() => toggleSection('workspaces')}
              className="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700 rounded-md transition-colors"
            >
              <div className="flex items-center">
                <Folder className="mr-3 h-4 w-4" />
                Workspaces
              </div>
              <div className="flex items-center space-x-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setShowCreateWorkspace(true)
                  }}
                  className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
                >
                  <Plus className="h-3 w-3" />
                </button>
                {expandedSections.workspaces ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
              </div>
            </button>

            {expandedSections.workspaces && (
              <div className="ml-6 mt-1 space-y-1">
                {isLoadingWorkspaces ? (
                  <div className="px-3 py-2 text-xs text-gray-500">Loading...</div>
                ) : workspaces.length === 0 ? (
                  <div className="px-3 py-2 text-xs text-gray-500">No workspaces yet</div>
                ) : (
                  workspaces.map((workspace) => (
                    <Link
                      key={workspace.id}
                      to={`/workspace/${workspace.id}`}
                      className={`
                        group flex items-center px-3 py-2 text-sm rounded-md transition-colors
                        ${isActive(`/workspace/${workspace.id}`) || currentWorkspace?.id === workspace.id
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                          : 'text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
                        }
                      `}
                    >
                      <span className="mr-2">{workspace.icon || '📁'}</span>
                      <span className="truncate">{workspace.name}</span>
                      {workspace._count && (
                        <span className="ml-auto text-xs text-gray-400">
                          {workspace._count.documents}
                        </span>
                      )}
                    </Link>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Recent Documents */}
          {recentDocuments.length > 0 && (
            <div>
              <button
                onClick={() => toggleSection('recent')}
                className="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700 rounded-md transition-colors"
              >
                <div className="flex items-center">
                  <FileText className="mr-3 h-4 w-4" />
                  Recent
                </div>
                {expandedSections.recent ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
              </button>

              {expandedSections.recent && (
                <div className="ml-6 mt-1 space-y-1">
                  {recentDocuments.map((doc) => (
                    <Link
                      key={doc.id}
                      to={`/document/${doc.id}`}
                      className={`
                        group flex items-center px-3 py-2 text-sm rounded-md transition-colors
                        ${isActive(`/document/${doc.id}`)
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                          : 'text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
                        }
                      `}
                    >
                      <FileText className="mr-2 h-3 w-3" />
                      <span className="truncate">{doc.title}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Favorite Documents */}
          {favoriteDocuments.length > 0 && (
            <div>
              <button
                onClick={() => toggleSection('favorites')}
                className="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700 rounded-md transition-colors"
              >
                <div className="flex items-center">
                  <Star className="mr-3 h-4 w-4" />
                  Favorites
                </div>
                {expandedSections.favorites ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
              </button>

              {expandedSections.favorites && (
                <div className="ml-6 mt-1 space-y-1">
                  {favoriteDocuments.map((doc) => (
                    <Link
                      key={doc.id}
                      to={`/document/${doc.id}`}
                      className={`
                        group flex items-center px-3 py-2 text-sm rounded-md transition-colors
                        ${isActive(`/document/${doc.id}`)
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                          : 'text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
                        }
                      `}
                    >
                      <Star className="mr-2 h-3 w-3 text-yellow-500" />
                      <span className="truncate">{doc.title}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          )}
        </nav>
      </div>

      {/* Create Document Button */}
      {currentWorkspace && (
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setShowCreateDocument(true)}
            className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition-colors"
          >
            <Plus className="mr-2 h-4 w-4" />
            New Document
          </button>
        </div>
      )}

      {/* Modals */}
      <CreateWorkspaceModal 
        isOpen={showCreateWorkspace} 
        onClose={() => setShowCreateWorkspace(false)} 
      />
      <CreateDocumentModal 
        isOpen={showCreateDocument} 
        onClose={() => setShowCreateDocument(false)} 
      />
    </div>
  )
}

export default Sidebar