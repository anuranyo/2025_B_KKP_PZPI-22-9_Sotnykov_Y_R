import React, { useState, useRef, useEffect } from 'react'
import { 
  Menu, 
  Search, 
  Bell, 
  Moon, 
  Sun, 
  LogOut,
  Settings,
  User,
  ChevronDown
} from 'lucide-react'
import { useAppStore } from '../../store/useAppStore'
import { useAuth } from '../../hooks/useAuth'
import { useTheme, useThemeClasses } from '../../hooks/useTheme'
import { Link } from 'react-router-dom'

const Header: React.FC = () => {
  const { user, toggleSidebar } = useAppStore()
  const { logout } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const themeClasses = useThemeClasses()
  
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const userMenuRef = useRef<HTMLDivElement>(null)
  const searchRef = useRef<HTMLInputElement>(null)

  // Close user menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // Focus search input when opened
  useEffect(() => {
    if (showSearch && searchRef.current) {
      searchRef.current.focus()
    }
  }, [showSearch])

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Cmd/Ctrl + K for search
      if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
        event.preventDefault()
        setShowSearch(true)
      }
      // Escape to close search
      if (event.key === 'Escape' && showSearch) {
        setShowSearch(false)
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [showSearch])

  const handleLogout = () => {
    logout()
    setShowUserMenu(false)
  }

  return (
    <header className={`${themeClasses.bg.primary} border-b ${themeClasses.border.primary} px-4 py-3 transition-colors`}>
      <div className="flex items-center justify-between">
        {/* Left side */}
        <div className="flex items-center space-x-4">
          {/* Mobile menu button */}
          <button
            onClick={toggleSidebar}
            className={`lg:hidden p-2 rounded-md ${themeClasses.text.secondary} ${themeClasses.hover.bg} ${themeClasses.hover.text} transition-colors`}
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Search
          <div className="relative">
            {showSearch ? (
              <div className="flex items-center">
                <input
                  ref={searchRef}
                  type="text"
                  placeholder="Search documents, workspaces..."
                  className={`w-64 px-4 py-2 text-sm border rounded-lg ${themeClasses.input} focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors`}
                  onBlur={() => setShowSearch(false)}
                />
              </div>
            ) : (
              <button
                onClick={() => setShowSearch(true)}
                className={`flex items-center space-x-2 px-3 py-2 text-sm ${themeClasses.text.secondary} ${themeClasses.bg.secondary} rounded-lg ${themeClasses.hover.bg} transition-colors`}
              >
                <Search className="h-4 w-4" />
                <span>Search...</span>
                <kbd className={`hidden sm:inline-block text-xs ${themeClasses.bg.tertiary} px-2 py-1 rounded`}>
                  ⌘K
                </kbd>
              </button>
            )}
          </div> */}
        </div>

        {/* Right side */}
        <div className="flex items-center space-x-3">
          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-md ${themeClasses.text.secondary} ${themeClasses.hover.bg} ${themeClasses.hover.text} transition-colors`}
            title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          >
            {theme === 'light' ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
          </button>

          {/* Notifications
          <button className={`p-2 rounded-md ${themeClasses.text.secondary} ${themeClasses.hover.bg} ${themeClasses.hover.text} transition-colors relative`}>
            <Bell className="h-5 w-5" />
            Notification badge
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </button> */}

          {/* User menu */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className={`flex items-center space-x-2 p-2 rounded-md ${themeClasses.text.secondary} ${themeClasses.hover.bg} ${themeClasses.hover.text} transition-colors`}
            >
              <div className="w-7 h-7 bg-blue-600 dark:bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">
                  {user?.name?.charAt(0)?.toUpperCase()}
                </span>
              </div>
              <span className={`hidden sm:block text-sm font-medium ${themeClasses.text.primary}`}>
                {user?.name}
              </span>
              <ChevronDown className="h-4 w-4" />
            </button>

            {/* Dropdown menu */}
            {showUserMenu && (
              <div className={`absolute right-0 mt-2 w-56 ${themeClasses.bg.primary} rounded-lg shadow-lg border ${themeClasses.border.primary} py-1 z-50 transition-colors`}>
                <div className={`px-4 py-3 border-b ${themeClasses.border.primary}`}>
                  <p className={`text-sm font-medium ${themeClasses.text.primary}`}>
                    {user?.name}
                  </p>
                  <p className={`text-sm ${themeClasses.text.secondary} truncate`}>
                    {user?.email}
                  </p>
                </div>

                <div className="py-1">
                  <Link
                    to="/settings"
                    className={`flex items-center px-4 py-2 text-sm ${themeClasses.text.secondary} ${themeClasses.hover.bg} transition-colors`}
                    onClick={() => setShowUserMenu(false)}
                  >
                    <User className="mr-3 h-4 w-4" />
                    Profile
                  </Link>
                  
                  <Link
                    to="/settings"
                    className={`flex items-center px-4 py-2 text-sm ${themeClasses.text.secondary} ${themeClasses.hover.bg} transition-colors`}
                    onClick={() => setShowUserMenu(false)}
                  >
                    <Settings className="mr-3 h-4 w-4" />
                    Settings
                  </Link>
                </div>

                <div className={`border-t ${themeClasses.border.primary} py-1`}>
                  <button
                    onClick={handleLogout}
                    className="flex items-center w-full px-4 py-2 text-sm text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  >
                    <LogOut className="mr-3 h-4 w-4" />
                    Sign out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header