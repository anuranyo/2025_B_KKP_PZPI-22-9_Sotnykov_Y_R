import React from 'react'
import { Link } from 'react-router-dom'
import { FileText } from 'lucide-react'

interface AuthLayoutProps {
  children: React.ReactNode
}

const AuthLayout: React.FC<AuthLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-md w-full space-y-8">
        {/* Logo and Brand */}
        <div className="text-center">
          <Link to="/" className="inline-flex items-center space-x-2">
            <div className="bg-blue-600 dark:bg-blue-500 p-3 rounded-xl transition-colors">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">NotionClone</h1>
          </Link>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Your productivity workspace
          </p>
        </div>

        {/* Auth Form */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-8 transition-colors">
          {children}
        </div>

        {/* Footer */}
        <div className="text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Built with React, TypeScript, and Tailwind CSS
          </p>
          <div className="mt-2 flex justify-center space-x-4 text-sm">
            <Link to="/public" className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors">
              Explore Public Workspaces
            </Link>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <a href="#" className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors">
              Privacy Policy
            </a>
            <span className="text-gray-300 dark:text-gray-600">•</span>
            <a href="#" className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors">
              Terms of Service
            </a>
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-3">
          <div className="text-center">
            <div className="bg-green-100 dark:bg-green-900/50 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3 transition-colors">
              <FileText className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Rich Editor</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Powerful block-based editor
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-purple-100 dark:bg-purple-900/50 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3 transition-colors">
              <FileText className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">AI Assistant</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              AI-powered writing help
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-blue-100 dark:bg-blue-900/50 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3 transition-colors">
              <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Collaboration</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Real-time team editing
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AuthLayout