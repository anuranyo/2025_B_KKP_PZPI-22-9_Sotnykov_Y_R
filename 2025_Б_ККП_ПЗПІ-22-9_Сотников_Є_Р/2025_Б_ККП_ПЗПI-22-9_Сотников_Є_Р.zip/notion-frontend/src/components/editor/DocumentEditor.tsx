import React, { useEffect, useState, useCallback } from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import { 
  Bold, 
  Italic, 
  Underline,
  Strikethrough,
  Code,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Quote,
  Undo,
  Redo,
  Link,
  Image,
  Sparkles,
  Save,
  Clock
} from 'lucide-react'
import { useDocuments } from '../../hooks/useDocuments'
import { useAI } from '../../hooks/useAI'
import type { DocumentContent, Block } from '../../types'
import { toast } from 'sonner'
import AIAssistant from '../ai/AIAssistant'
import AIContextMenu from '../ai/AIContextMenu'
import AIQuickActions from '../ai/AIQuickActions'

interface DocumentEditorProps {
  documentId: string
  content: DocumentContent
  isEditable: boolean
}

const DocumentEditor: React.FC<DocumentEditorProps> = ({
  documentId,
  content,
  isEditable
}) => {
  const { updateContentOptimistic, isUpdatingContent } = useDocuments()
  const { isAIAvailable } = useAI()
  
  const [lastSaved, setLastSaved] = useState<Date | null>(null)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [title, setTitle] = useState(content.title)
  
  // AI states
  const [showAIAssistant, setShowAIAssistant] = useState(false)
  const [selectedText, setSelectedText] = useState('')
  const [aiContextMenu, setAIContextMenu] = useState<{
    visible: boolean
    position: { x: number; y: number }
    text: string
  }>({
    visible: false,
    position: { x: 0, y: 0 },
    text: ''
  })

  // ИСПРАВЛЕННАЯ функция Convert blocks to HTML
  const convertBlocksToHTML = (blocks: Block[]) => {
    console.log('=== CONVERTING BLOCKS TO HTML ===')
    console.log('Input blocks:', blocks)
    
    if (!blocks || blocks.length === 0) {
      return '<p>Start writing...</p>'
    }
    
    const htmlParts: string[] = []
    let i = 0
    
    while (i < blocks.length) {
      const block = blocks[i]
      let text = ''
      
      // Извлекаем текст в зависимости от типа блока
      switch (block.type) {
        case 'paragraph':
          text = (block as any).paragraph?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          htmlParts.push(`<p>${text}</p>`)
          i++
          break
          
        case 'heading_1':
          text = (block as any).heading_1?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          htmlParts.push(`<h1>${text}</h1>`)
          i++
          break
          
        case 'heading_2':
          text = (block as any).heading_2?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          htmlParts.push(`<h2>${text}</h2>`)
          i++
          break
          
        case 'heading_3':
          text = (block as any).heading_3?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          htmlParts.push(`<h3>${text}</h3>`)
          i++
          break
          
        case 'quote':
          text = (block as any).quote?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          htmlParts.push(`<blockquote>${text}</blockquote>`)
          i++
          break
          
        case 'code':
          text = (block as any).code?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          htmlParts.push(`<pre><code>${text}</code></pre>`)
          i++
          break
          
        case 'bulleted_list_item':
          // Группируем соседние элементы списка
          const bulletItems: string[] = []
          while (i < blocks.length && blocks[i].type === 'bulleted_list_item') {
            const itemText = (blocks[i] as any).bulleted_list_item?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
            bulletItems.push(`<li>${itemText}</li>`)
            i++
          }
          htmlParts.push(`<ul>${bulletItems.join('')}</ul>`)
          break
          
        case 'numbered_list_item':
          // Группируем соседние элементы списка
          const numberItems: string[] = []
          while (i < blocks.length && blocks[i].type === 'numbered_list_item') {
            const itemText = (blocks[i] as any).numbered_list_item?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
            numberItems.push(`<li>${itemText}</li>`)
            i++
          }
          htmlParts.push(`<ol>${numberItems.join('')}</ol>`)
          break
          
        case 'to_do':
          text = (block as any).to_do?.rich_text?.map((rt: any) => rt.plain_text || rt.text?.content || '').join('') || ''
          const checked = (block as any).to_do?.checked ? 'checked' : ''
          htmlParts.push(`<p><input type="checkbox" ${checked} disabled> ${text}</p>`)
          i++
          break
          
        default:
          // Fallback для неизвестных типов блоков
          const blockContent = (block as any)[block.type]
          if (blockContent?.rich_text) {
            text = blockContent.rich_text.map((rt: any) => rt.plain_text || rt.text?.content || '').join('')
          } else {
            text = JSON.stringify(block)
          }
          htmlParts.push(`<p>${text}</p>`)
          i++
          break
      }
    }
    
    const finalHTML = htmlParts.join('')
    console.log('Generated HTML:', finalHTML)
    return finalHTML
  }

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3],
        },
      }),
      Placeholder.configure({
        placeholder: isEditable ? 'Start writing or use AI to help...' : 'This document is read-only',
      }),
    ],
    // ИСПРАВЛЕНИЕ: Логируем начальный контент
    content: (() => {
      const initialHTML = convertBlocksToHTML(content.blocks)
      console.log('=== EDITOR INITIALIZATION ===')
      console.log('Initial content blocks:', content.blocks)
      console.log('Initial HTML:', initialHTML)
      return initialHTML
    })(),
    editable: isEditable,
    onUpdate: ({ editor }) => {
      if (isEditable) {
        console.log('Editor updated, HTML:', editor.getHTML())
        setHasUnsavedChanges(true)
        saveTimer()
      }
    },
    onSelectionUpdate: ({ editor }) => {
      if (isEditable && isAIAvailable) {
        const { from, to } = editor.state.selection
        const text = editor.state.doc.textBetween(from, to)
        setSelectedText(text.trim())
        
        if (text.trim().length > 0) {
          // Show AI context menu after a delay
          setTimeout(() => {
            const coords = editor.view.coordsAtPos(from)
            setAIContextMenu({
              visible: true,
              position: {
                x: coords.left,
                y: coords.bottom
              },
              text: text.trim()
            })
          }, 300)
        } else {
          setAIContextMenu(prev => ({ ...prev, visible: false }))
        }
      }
    },
  })

  // Auto-save timer
  const [saveTimeoutId, setSaveTimeoutId] = useState<ReturnType<typeof setTimeout> | null>(null)

  const saveTimer = useCallback(() => {
    if (saveTimeoutId) {
      clearTimeout(saveTimeoutId)
    }
    
    const newTimeoutId = setTimeout(() => {
      handleSave()
    }, 2000)
    
    setSaveTimeoutId(newTimeoutId)
  }, [saveTimeoutId])

  const handleSave = useCallback(() => {
    if (!editor || !hasUnsavedChanges) return

    console.log('=== SAVING DOCUMENT ===')
    
    try {
      const html = editor.getHTML()
      console.log('Editor HTML:', html)
      
      const blocks = convertHTMLToBlocks(html)
      console.log('Converted blocks:', blocks)

      const updatedContent = {
        title,
        blocks,
        last_edited_time: new Date().toISOString(),
      }
      
      console.log('Content to save:', updatedContent)

      updateContentOptimistic(documentId, updatedContent)
      setLastSaved(new Date())
      setHasUnsavedChanges(false)
      
      toast.success('Document saved')
    } catch (error) {
      console.error('Error in handleSave:', error)
      
      if (error instanceof Error) {
        if (error.message.includes('Validation error')) {
          toast.error('Invalid document format. Please check your content.')
        } else if (error.message.includes('Network Error')) {
          toast.error('Network error. Please check your connection.')
        } else {
          toast.error(`Failed to save: ${error.message}`)
        }
      } else {
        toast.error('Failed to save document')
      }
    }
  }, [editor, hasUnsavedChanges, title, documentId, updateContentOptimistic])

  // ИСПРАВЛЕННАЯ функция HTML to blocks conversion
  const convertHTMLToBlocks = (html: string): Block[] => {
    console.log('=== CONVERTING HTML TO BLOCKS ===')
    console.log('Input HTML:', html)
    
    const parser = new DOMParser()
    const doc = parser.parseFromString(html, 'text/html')
    
    // ИСПРАВЛЕНИЕ: Получаем ВСЕ узлы, включая текстовые
    const nodes = Array.from(doc.body.childNodes)
    console.log('Parsed nodes:', nodes.length, nodes)
    
    if (nodes.length === 0) {
      return [{
        id: `block-0`,
        type: 'paragraph',
        created_time: new Date().toISOString(),
        last_edited_time: new Date().toISOString(),
        archived: false,
        has_children: false,
        paragraph: {
          rich_text: [{
            type: 'text',
            text: { content: '' },
            annotations: {
              bold: false,
              italic: false,
              strikethrough: false,
              underline: false,
              code: false,
            },
            plain_text: '',
          }],
          color: 'default',
        }
      } as any]
    }
    
    const blocks: Block[] = []
    let blockIndex = 0
    
    nodes.forEach(node => {
      console.log('Processing node:', node.nodeType, node.nodeName, node.textContent)
      
      // Обрабатываем элементы
      if (node.nodeType === Node.ELEMENT_NODE) {
        const element = node as Element
        const text = element.textContent || ''
        const richText = [{
          type: 'text' as const,
          text: { content: text },
          annotations: {
            bold: false,
            italic: false,
            strikethrough: false,
            underline: false,
            code: false,
          },
          plain_text: text,
        }]

        const baseBlock = {
          id: `block-${blockIndex++}`,
          created_time: new Date().toISOString(),
          last_edited_time: new Date().toISOString(),
          archived: false,
          has_children: false,
        }

        switch (element.tagName.toLowerCase()) {
          case 'h1':
            blocks.push({
              ...baseBlock,
              type: 'heading_1',
              heading_1: {
                rich_text: richText,
                color: 'default',
                is_toggleable: false,
              }
            } as any)
            break
          case 'h2':
            blocks.push({
              ...baseBlock,
              type: 'heading_2',
              heading_2: {
                rich_text: richText,
                color: 'default',
                is_toggleable: false,
              }
            } as any)
            break
          case 'h3':
            blocks.push({
              ...baseBlock,
              type: 'heading_3',
              heading_3: {
                rich_text: richText,
                color: 'default',
                is_toggleable: false,
              }
            } as any)
            break
          case 'blockquote':
            blocks.push({
              ...baseBlock,
              type: 'quote',
              quote: {
                rich_text: richText,
                color: 'default',
              }
            } as any)
            break
          case 'pre':
            blocks.push({
              ...baseBlock,
              type: 'code',
              code: {
                rich_text: richText,
                language: 'plain text',
                caption: []
              }
            } as any)
            break
          case 'ul':
            // Обрабатываем каждый li отдельно
            Array.from(element.children).forEach(li => {
              if (li.tagName.toLowerCase() === 'li') {
                blocks.push({
                  id: `block-${blockIndex++}`,
                  created_time: new Date().toISOString(),
                  last_edited_time: new Date().toISOString(),
                  archived: false,
                  has_children: false,
                  type: 'bulleted_list_item',
                  bulleted_list_item: {
                    rich_text: [{
                      type: 'text' as const,
                      text: { content: li.textContent || '' },
                      annotations: {
                        bold: false,
                        italic: false,
                        strikethrough: false,
                        underline: false,
                        code: false,
                      },
                      plain_text: li.textContent || '',
                    }],
                    color: 'default',
                  }
                } as any)
              }
            })
            break
          case 'ol':
            // Обрабатываем каждый li отдельно
            Array.from(element.children).forEach(li => {
              if (li.tagName.toLowerCase() === 'li') {
                blocks.push({
                  id: `block-${blockIndex++}`,
                  created_time: new Date().toISOString(),
                  last_edited_time: new Date().toISOString(),
                  archived: false,
                  has_children: false,
                  type: 'numbered_list_item',
                  numbered_list_item: {
                    rich_text: [{
                      type: 'text' as const,
                      text: { content: li.textContent || '' },
                      annotations: {
                        bold: false,
                        italic: false,
                        strikethrough: false,
                        underline: false,
                        code: false,
                      },
                      plain_text: li.textContent || '',
                    }],
                    color: 'default',
                  }
                } as any)
              }
            })
            break
          case 'p':
          default:
            // Обычный параграф
            blocks.push({
              ...baseBlock,
              type: 'paragraph',
              paragraph: {
                rich_text: richText,
                color: 'default',
              }
            } as any)
            break
        }
      }
      // Обрабатываем текстовые узлы (переносы строк)
      else if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent || ''
        // Пропускаем пустые текстовые узлы и пробелы
        if (text.trim()) {
          blocks.push({
            id: `block-${blockIndex++}`,
            created_time: new Date().toISOString(),
            last_edited_time: new Date().toISOString(),
            archived: false,
            has_children: false,
            type: 'paragraph',
            paragraph: {
              rich_text: [{
                type: 'text' as const,
                text: { content: text.trim() },
                annotations: {
                  bold: false,
                  italic: false,
                  strikethrough: false,
                  underline: false,
                  code: false,
                },
                plain_text: text.trim(),
              }],
              color: 'default',
            }
          } as any)
        }
      }
    })
    
    console.log('Generated blocks:', blocks.length, blocks)
    return blocks
  }

  // Handle title change
  const handleTitleChange = (newTitle: string) => {
    setTitle(newTitle)
    setHasUnsavedChanges(true)
    saveTimer()
  }

  // AI handlers
  const handleAIResult = (result: string, action: string) => {
    if (!editor || !isEditable) return
    
    // Insert AI result at current cursor position
    editor.chain().focus().insertContent(`<p>${result}</p>`).run()
    setHasUnsavedChanges(true)
    saveTimer()
    toast.success(`${action} result inserted`)
  }

  const handleAIInsertText = (text: string) => {
    if (!editor || !isEditable) return
    
    editor.chain().focus().insertContent(`<p>${text}</p>`).run()
    setHasUnsavedChanges(true)
    saveTimer()
    setAIContextMenu(prev => ({ ...prev, visible: false }))
  }

  const handleAIReplaceText = (newText: string) => {
    if (!editor || !isEditable) return
    
    const { from, to } = editor.state.selection
    if (from !== to) {
      editor.chain().focus().insertContentAt({ from, to }, newText).run()
      setHasUnsavedChanges(true)
      saveTimer()
    }
    setAIContextMenu(prev => ({ ...prev, visible: false }))
  }

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault()
        handleSave()
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [handleSave])

  // ИСПРАВЛЕНИЕ: Также обновляем title состояние при изменении content
  useEffect(() => {
    if (content) {
      setTitle(content.title)
    }
  }, [content.title])

  // ИСПРАВЛЕНИЕ: Обновляем content редактора при изменении props
  useEffect(() => {
    if (editor && content) {
      console.log('=== UPDATING EDITOR CONTENT ===')
      console.log('New content received:', content)
      
      const currentContent = editor.getHTML()
      const newContent = convertBlocksToHTML(content.blocks)
      
      console.log('Current editor HTML:', currentContent)
      console.log('New HTML to set:', newContent)
      
      // Обновляем только если контент действительно изменился
      if (currentContent !== newContent) {
        console.log('Content changed, updating editor...')
        editor.commands.setContent(newContent, false) // false = не вызывать onUpdate
        setHasUnsavedChanges(false) // Сбрасываем флаг изменений
      } else {
        console.log('Content unchanged, skipping update')
      }
    }
  }, [content, editor])

  // Cleanup
  useEffect(() => {
    return () => {
      if (saveTimeoutId) {
        clearTimeout(saveTimeoutId)
      }
    }
  }, [saveTimeoutId])

  if (!editor) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Toolbar */}
      {isEditable && (
        <div className="sticky top-16 z-10 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              {/* Text Formatting */}
              <button
                onClick={() => editor.chain().focus().toggleBold().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('bold') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Bold className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleItalic().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('italic') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Italic className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleStrike().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('strike') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Strikethrough className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleCode().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('code') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Code className="h-4 w-4" />
              </button>

              <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-2" />

              {/* Headings */}
              <button
                onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('heading', { level: 1 }) ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Heading1 className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('heading', { level: 2 }) ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Heading2 className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('heading', { level: 3 }) ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Heading3 className="h-4 w-4" />
              </button>

              <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-2" />

              {/* Lists */}
              <button
                onClick={() => editor.chain().focus().toggleBulletList().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('bulletList') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <List className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleOrderedList().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('orderedList') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <ListOrdered className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().toggleBlockquote().run()}
                className={`p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                  editor.isActive('blockquote') ? 'bg-gray-100 dark:bg-gray-700 text-blue-600' : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Quote className="h-4 w-4" />
              </button>

              <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-2" />

              {/* Undo/Redo */}
              <button
                onClick={() => editor.chain().focus().undo().run()}
                disabled={!editor.can().undo()}
                className="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-gray-600 dark:text-gray-400 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Undo className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => editor.chain().focus().redo().run()}
                disabled={!editor.can().redo()}
                className="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-gray-600 dark:text-gray-400 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Redo className="h-4 w-4" />
              </button>

              <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-2" />

              {/* AI Assistant */}
              <button
                onClick={() => setShowAIAssistant(true)}
                disabled={!isAIAvailable}
                className={`flex items-center px-3 py-2 rounded text-sm transition-all ${
                  isAIAvailable
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600'
                    : 'bg-gray-300 dark:bg-gray-600 text-gray-500 cursor-not-allowed'
                }`}
              >
                <Sparkles className="h-4 w-4 mr-1" />
                AI
                {!isAIAvailable && <span className="ml-1 text-xs">(Off)</span>}
              </button>
            </div>

            {/* Save Status */}
            <div className="flex items-center space-x-3">
              {hasUnsavedChanges && (
                <button
                  onClick={handleSave}
                  disabled={isUpdatingContent}
                  className="flex items-center px-3 py-1 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                >
                  <Save className="h-4 w-4 mr-1" />
                  Save
                </button>
              )}
              
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                {isUpdatingContent ? (
                  <span className="flex items-center">
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-600 mr-2"></div>
                    Saving...
                  </span>
                ) : lastSaved ? (
                  <span className="flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    Saved {lastSaved.toLocaleTimeString()}
                  </span>
                ) : hasUnsavedChanges ? (
                  <span className="text-orange-500">Unsaved changes</span>
                ) : null}
              </div>
            </div>
          </div>

          {/* AI Quick Actions */}
          {isAIAvailable && selectedText && (
            <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
              <AIQuickActions
                onAIResult={handleAIResult}
                selectedText={selectedText}
                documentContext={`Document: ${title}\n\nContent: ${editor.getHTML()}`}
              />
            </div>
          )}
        </div>
      )}

      {/* Document Content */}
      <div className="px-6 py-8">
        {/* Document Icon */}
        {content.icon && (
          <div className="mb-6">
            {content.icon.type === 'emoji' && (
              <span className="text-6xl">{content.icon.emoji}</span>
            )}
          </div>
        )}

        {/* Document Cover */}
        {content.cover && (
          <div className="mb-8 -mx-6">
            <img
              src={content.cover.external?.url || content.cover.file?.url}
              alt="Document cover"
              className="w-full h-48 object-cover"
            />
          </div>
        )}

        {/* Document Title */}
        <div className="mb-8">
          {isEditable ? (
            <input
              type="text"
              value={title}
              onChange={(e) => handleTitleChange(e.target.value)}
              className="w-full text-4xl font-bold text-gray-900 dark:text-gray-100 bg-transparent border-none outline-none placeholder-gray-400"
              placeholder="Untitled"
            />
          ) : (
            <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100">
              {title || 'Untitled'}
            </h1>
          )}
        </div>

        {/* Editor */}
        <div className="prose prose-lg dark:prose-invert max-w-none">
          <EditorContent editor={editor} />
        </div>
      </div>

      {/* AI Context Menu */}
      <AIContextMenu
        isVisible={aiContextMenu.visible}
        position={aiContextMenu.position}
        selectedText={aiContextMenu.text}
        onClose={() => setAIContextMenu(prev => ({ ...prev, visible: false }))}
        onReplaceText={handleAIReplaceText}
        onInsertText={handleAIInsertText}
        onOpenFullAssistant={() => {
          setShowAIAssistant(true)
          setAIContextMenu(prev => ({ ...prev, visible: false }))
        }}
      />

      {/* Full AI Assistant */}
      <AIAssistant
        isOpen={showAIAssistant}
        onClose={() => setShowAIAssistant(false)}
        selectedText={selectedText}
        onInsertText={handleAIInsertText}
        onReplaceText={handleAIReplaceText}
        documentContext={`Document: ${title}\n\nContent: ${editor ? editor.getHTML() : ''}`}
      />
    </div>
  )
}

export default DocumentEditor