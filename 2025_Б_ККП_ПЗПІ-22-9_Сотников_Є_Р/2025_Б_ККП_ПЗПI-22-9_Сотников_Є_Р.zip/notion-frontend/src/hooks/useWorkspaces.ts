import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { workspacesApi } from '../lib/api'
import { useAppStore } from '../store/useAppStore'
import type { CreateWorkspaceData } from '../types'

export const useWorkspaces = () => {
  const queryClient = useQueryClient()
  const { currentWorkspace, setCurrentWorkspace } = useAppStore()

  // Get all user workspaces
  const {
    data: workspaces = [],
    isLoading: isLoadingWorkspaces,
    error: workspacesError,
  } = useQuery({
    queryKey: ['workspaces'],
    queryFn: workspacesApi.getAll,
    staleTime: 5 * 60 * 1000, // 5 minutes
  })

  // Get workspace by ID
  const useWorkspace = (id: string) => {
    return useQuery({
      queryKey: ['workspaces', id],
      queryFn: () => workspacesApi.getById(id),
      enabled: !!id,
      staleTime: 5 * 60 * 1000,
    })
  }

  // Get workspace members
  const useWorkspaceMembers = (id: string) => {
    return useQuery({
      queryKey: ['workspaces', id, 'members'],
      queryFn: () => workspacesApi.getMembers(id),
      enabled: !!id,
      staleTime: 2 * 60 * 1000, // 2 minutes
    })
  }

  // Get workspace documents
  const useWorkspaceDocuments = (id: string, params?: { page?: number; limit?: number; search?: string }) => {
    return useQuery({
      queryKey: ['workspaces', id, 'documents', params],
      queryFn: () => workspacesApi.getDocuments(id, params),
      enabled: !!id,
      staleTime: 1 * 60 * 1000, // 1 minute
    })
  }

  // Create workspace mutation
  const createWorkspaceMutation = useMutation({
    mutationFn: (data: CreateWorkspaceData) => {
      console.log('createWorkspaceMutation called with:', data)
      console.log('workspacesApi.create:', workspacesApi.create)
      return workspacesApi.create(data)
    },
    onSuccess: (newWorkspace) => {
      console.log('createWorkspace onSuccess:', newWorkspace)
      queryClient.invalidateQueries({ queryKey: ['workspaces'] })
      setCurrentWorkspace(newWorkspace)
      toast.success('Workspace created successfully!')
    },
    onError: (error: any) => {
      console.error('createWorkspace onError:', error)
      toast.error(error.response?.data?.message || 'Failed to create workspace')
    },
    onMutate: (data) => {
      console.log('createWorkspace onMutate:', data)
    }
  })

  // Update workspace mutation
  const updateWorkspaceMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<CreateWorkspaceData> }) =>
      workspacesApi.update(id, data),
    onSuccess: (updatedWorkspace) => {
      queryClient.invalidateQueries({ queryKey: ['workspaces'] })
      queryClient.invalidateQueries({ queryKey: ['workspaces', updatedWorkspace.id] })
      
      // Update current workspace if it's the one being updated
      if (currentWorkspace?.id === updatedWorkspace.id) {
        setCurrentWorkspace(updatedWorkspace)
      }
      
      toast.success('Workspace updated successfully!')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to update workspace')
    },
  })

  // Delete workspace mutation
  const deleteWorkspaceMutation = useMutation({
    mutationFn: workspacesApi.delete,
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ['workspaces'] })
      
      // Clear current workspace if it's the one being deleted
      if (currentWorkspace?.id === deletedId) {
        setCurrentWorkspace(null)
      }
      
      toast.success('Workspace deleted successfully!')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to delete workspace')
    },
  })

  // Invite member mutation
  const inviteMemberMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: { email: string; role: string } }) =>
      workspacesApi.inviteMember(id, data),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: ['workspaces', id, 'members'] })
      toast.success('Member invited successfully!')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to invite member')
    },
  })

  // Get public workspaces
  const usePublicWorkspaces = (params?: { page?: number; limit?: number; search?: string }) => {
    return useQuery({
      queryKey: ['workspaces', 'public', params],
      queryFn: () => workspacesApi.getPublic(params),
      staleTime: 5 * 60 * 1000,
    })
  }

  // Helper functions
  const createWorkspace = (data: CreateWorkspaceData) => {
    console.log('createWorkspace helper called with:', data)
    console.log('createWorkspaceMutation.mutate:', createWorkspaceMutation.mutate)
    createWorkspaceMutation.mutate(data)
  }

  const updateWorkspace = (id: string, data: Partial<CreateWorkspaceData>) => {
    updateWorkspaceMutation.mutate({ id, data })
  }

  const deleteWorkspace = (id: string) => {
    deleteWorkspaceMutation.mutate(id)
  }

  const inviteMember = (id: string, data: { email: string; role: string }) => {
    inviteMemberMutation.mutate({ id, data })
  }

  const switchWorkspace = (workspace: any) => {
    setCurrentWorkspace(workspace)
    toast.success(`Switched to ${workspace.name}`)
  }

  // Debug log
  console.log('useWorkspaces hook state:', {
    isCreatingWorkspace: createWorkspaceMutation.isPending,
    createWorkspaceError: createWorkspaceMutation.error,
    workspacesCount: workspaces.length
  })

  return {
    // Data
    workspaces,
    currentWorkspace,
    
    // Loading states
    isLoadingWorkspaces,
    isCreatingWorkspace: createWorkspaceMutation.isPending,
    isUpdatingWorkspace: updateWorkspaceMutation.isPending,
    isDeletingWorkspace: deleteWorkspaceMutation.isPending,
    isInvitingMember: inviteMemberMutation.isPending,
    
    // Error states
    workspacesError,
    createWorkspaceError: createWorkspaceMutation.error,
    updateWorkspaceError: updateWorkspaceMutation.error,
    deleteWorkspaceError: deleteWorkspaceMutation.error,
    inviteMemberError: inviteMemberMutation.error,
    
    // Actions
    createWorkspace,
    updateWorkspace,
    deleteWorkspace,
    inviteMember,
    switchWorkspace,
    setCurrentWorkspace,
    
    // Queries
    useWorkspace,
    useWorkspaceMembers,
    useWorkspaceDocuments,
    usePublicWorkspaces,
  }
}