import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { authApi } from '../lib/api'
import { useAppStore } from '../store/useAppStore'
import type { LoginCredentials, RegisterData } from '../types'

export const useAuth = () => {
  const { login, logout, user, isAuthenticated, token } = useAppStore()
  const queryClient = useQueryClient()

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: authApi.login,
    onSuccess: (data) => {
      login(data.token, data.user)
      localStorage.setItem('token', data.token)
      toast.success('Login successful!')
      
      // Invalidate and refetch user data
      queryClient.invalidateQueries({ queryKey: ['user'] })
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Login failed')
    },
  })

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: authApi.register,
    onSuccess: (data) => {
      login(data.token, data.user)
      localStorage.setItem('token', data.token)
      toast.success('Registration successful!')
      
      // Invalidate and refetch user data
      queryClient.invalidateQueries({ queryKey: ['user'] })
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Registration failed')
    },
  })

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: authApi.logout,
    onSuccess: () => {
      logout()
      localStorage.removeItem('token')
      queryClient.clear()
      toast.success('Logged out successfully')
    },
    onError: () => {
      // Still logout locally even if server request fails
      logout()
      localStorage.removeItem('token')
      queryClient.clear()
    },
  })

  // Get user profile query
  const { data: userProfile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['user', 'profile'],
    queryFn: authApi.getProfile,
    enabled: !!token && isAuthenticated,
    retry: 1,
    staleTime: 10 * 60 * 1000, // 10 minutes
  })

  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: authApi.changePassword,
    onSuccess: () => {
      toast.success('Password changed successfully')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to change password')
    },
  })

  const handleLogin = (credentials: LoginCredentials) => {
    loginMutation.mutate(credentials)
  }

  const handleRegister = (data: RegisterData) => {
    registerMutation.mutate(data)
  }

  const handleLogout = () => {
    logoutMutation.mutate()
  }

  const handleChangePassword = (data: { currentPassword: string; newPassword: string }) => {
    changePasswordMutation.mutate(data)
  }

  return {
    // State
    user: userProfile || user,
    isAuthenticated,
    token,
    
    // Loading states
    isLoggingIn: loginMutation.isPending,
    isRegistering: registerMutation.isPending,
    isLoggingOut: logoutMutation.isPending,
    isLoadingProfile,
    isChangingPassword: changePasswordMutation.isPending,
    
    // Actions
    login: handleLogin,
    register: handleRegister,
    logout: handleLogout,
    changePassword: handleChangePassword,
    
    // Error states
    loginError: loginMutation.error,
    registerError: registerMutation.error,
    changePasswordError: changePasswordMutation.error,
  }
}