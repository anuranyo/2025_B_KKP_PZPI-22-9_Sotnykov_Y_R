import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { documentsApi, usersApi } from '../lib/api'
import type { CreateDocumentData, DocumentContent } from '../types'

// Move useAllDocuments OUTSIDE the useDocuments function and fix the export
export const useAllDocuments = (
  params?: { page?: number; limit?: number; search?: string },
  options?: { enabled?: boolean }
) => {
  return useQuery({
    queryKey: ['documents', 'all', params],
    // Fix: Use usersApi.getUserDocuments instead of documentsApi.getAllDocuments
    queryFn: () => usersApi.getUserDocuments(params),
    enabled: options?.enabled,
    staleTime: 2 * 60 * 1000,
  })
}

export const useDocuments = () => {
  const queryClient = useQueryClient()

  // Get document by ID
  const useDocument = (id: string) => {
    return useQuery({
      queryKey: ['documents', id],
      queryFn: () => documentsApi.getById(id),
      enabled: !!id,
      staleTime: 2 * 60 * 1000, // 2 minutes
    })
  }

  // Get document content
  const useDocumentContent = (id: string) => {
    return useQuery({
      queryKey: ['documents', id, 'content'],
      queryFn: () => documentsApi.getContent(id),
      enabled: !!id,
      staleTime: 1 * 60 * 1000, // 1 minute
    })
  }

  // Get child documents
  const useChildDocuments = (id: string) => {
    return useQuery({
      queryKey: ['documents', id, 'children'],
      queryFn: () => documentsApi.getChildren(id),
      enabled: !!id,
      staleTime: 2 * 60 * 1000,
    })
  }

  // Get user's documents
  const useUserDocuments = (params?: { page?: number; limit?: number; search?: string }) => {
    return useQuery({
      queryKey: ['users', 'documents', params],
      queryFn: () => usersApi.getUserDocuments(params),
      staleTime: 2 * 60 * 1000,
    })
  }

  // Get recent documents
  const useRecentDocuments = (limit = 10) => {
    return useQuery({
      queryKey: ['users', 'documents', 'recent', limit],
      queryFn: () => usersApi.getRecentDocuments(limit),
      staleTime: 1 * 60 * 1000,
    })
  }

  // Get favorite documents
  const useFavoriteDocuments = () => {
    return useQuery({
      queryKey: ['users', 'documents', 'favorites'],
      queryFn: usersApi.getFavoriteDocuments,
      staleTime: 2 * 60 * 1000,
    })
  }

  // Get archived documents
  const useArchivedDocuments = (params?: { page?: number; limit?: number; search?: string }) => {
    return useQuery({
      queryKey: ['users', 'documents', 'archived', params],
      queryFn: () => usersApi.getUserDocuments({ ...params, archived: true }),
      staleTime: 2 * 60 * 1000,
    })
  }

  // Create document mutation
  const createDocumentMutation = useMutation({
    mutationFn: documentsApi.create,
    onSuccess: (newDocument) => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['workspaces', newDocument.workspaceId, 'documents'] })
      queryClient.invalidateQueries({ queryKey: ['users', 'documents'] })
      
      if (newDocument.parentId) {
        queryClient.invalidateQueries({ queryKey: ['documents', newDocument.parentId, 'children'] })
      }
      
      toast.success('Document created successfully!')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to create document')
    },
  })

  // Update document mutation
  const updateDocumentMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<CreateDocumentData> }) =>
      documentsApi.update(id, data),
    onSuccess: (updatedDocument) => {
      queryClient.invalidateQueries({ queryKey: ['documents', updatedDocument.id] })
      queryClient.invalidateQueries({ queryKey: ['workspaces', updatedDocument.workspaceId, 'documents'] })
      queryClient.invalidateQueries({ queryKey: ['users', 'documents'] })
      
      toast.success('Document updated successfully!')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to update document')
    },
  })

  // Update document content mutation
  const updateContentMutation = useMutation({
    mutationFn: ({ id, content }: { id: string; content: Partial<DocumentContent> }) =>
      documentsApi.updateContent(id, content),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: ['documents', id, 'content'] })
      // Don't show toast for content updates as they happen frequently
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to save content')
    },
  })

  // Delete document mutation
  const deleteDocumentMutation = useMutation({
    mutationFn: documentsApi.delete,
    onSuccess: (_, deletedId) => {
      // Remove from cache
      queryClient.removeQueries({ queryKey: ['documents', deletedId] })
      queryClient.removeQueries({ queryKey: ['documents', deletedId, 'content'] })
      
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ['workspaces'] })
      queryClient.invalidateQueries({ queryKey: ['users', 'documents'] })
      
      toast.success('Document deleted successfully!')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to delete document')
    },
  })

  // Toggle favorite mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: documentsApi.toggleFavorite,
    onSuccess: (result, documentId) => {
      queryClient.invalidateQueries({ queryKey: ['documents', documentId] })
      queryClient.invalidateQueries({ queryKey: ['users', 'documents', 'favorites'] })
      queryClient.invalidateQueries({ queryKey: ['users', 'documents'] })
      
      toast.success(result.isFavorite ? 'Added to favorites' : 'Removed from favorites')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to update favorite status')
    },
  })

  // Toggle archive mutation
  const toggleArchiveMutation = useMutation({
    mutationFn: documentsApi.toggleArchive,
    onSuccess: (result, documentId) => {
      queryClient.invalidateQueries({ queryKey: ['documents', documentId] })
      queryClient.invalidateQueries({ queryKey: ['workspaces'] })
      queryClient.invalidateQueries({ queryKey: ['users', 'documents'] })
      
      toast.success(result.isArchived ? 'Document archived' : 'Document unarchived')
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Failed to update archive status')
    },
  })

  // Search documents mutation
  const searchDocumentsMutation = useMutation({
    mutationFn: documentsApi.search,
    onError: (error: any) => {
      toast.error(error.response?.data?.message || 'Search failed')
    },
  })

  // Helper functions (простые версии)
  const createDocument = (data: CreateDocumentData) => {
    createDocumentMutation.mutate(data)
  }

  const updateDocument = (id: string, data: Partial<CreateDocumentData>) => {
    updateDocumentMutation.mutate({ id, data })
  }

  const updateContent = (id: string, content: Partial<DocumentContent>) => {
    updateContentMutation.mutate({ id, content })
  }

  const deleteDocument = (id: string) => {
    deleteDocumentMutation.mutate(id)
  }

  const toggleFavorite = (id: string) => {
    toggleFavoriteMutation.mutate(id)
  }

  const toggleArchive = (id: string) => {
    toggleArchiveMutation.mutate(id)
  }

  const searchDocuments = (query: { query: string; workspaceId?: string; type?: string; limit?: number }) => {
    searchDocumentsMutation.mutate(query)
  }

  // Промис-версии функций (для случаев когда нужно что-то делать после успешного выполнения)
  const createDocumentAsync = (data: CreateDocumentData) => {
    return createDocumentMutation.mutateAsync(data)
  }

  const updateDocumentAsync = (id: string, data: Partial<CreateDocumentData>) => {
    return updateDocumentMutation.mutateAsync({ id, data })
  }

  const updateContentAsync = (id: string, content: Partial<DocumentContent>) => {
    return updateContentMutation.mutateAsync({ id, content })
  }

  const deleteDocumentAsync = (id: string) => {
    return deleteDocumentMutation.mutateAsync(id)
  }

  const toggleFavoriteAsync = (id: string) => {
    return toggleFavoriteMutation.mutateAsync(id)
  }

  const toggleArchiveAsync = (id: string) => {
    return toggleArchiveMutation.mutateAsync(id)
  }
  

  // Optimistic update for content
  const updateContentOptimistic = (documentId: string, content: Partial<DocumentContent>) => {
    queryClient.setQueryData(['documents', documentId, 'content'], (old: DocumentContent | undefined) => {
      if (!old) return old
      return { ...old, ...content }
    })
    
    // Still call the mutation to save to server
    updateContent(documentId, content)
  }

  return {
    // Loading states
    isCreatingDocument: createDocumentMutation.isPending,
    isUpdatingDocument: updateDocumentMutation.isPending,
    isUpdatingContent: updateContentMutation.isPending,
    isDeletingDocument: deleteDocumentMutation.isPending,
    isTogglingFavorite: toggleFavoriteMutation.isPending,
    isTogglingArchive: toggleArchiveMutation.isPending,
    isSearching: searchDocumentsMutation.isPending,
    
    // Error states
    createDocumentError: createDocumentMutation.error,
    updateDocumentError: updateDocumentMutation.error,
    updateContentError: updateContentMutation.error,
    deleteDocumentError: deleteDocumentMutation.error,
    searchError: searchDocumentsMutation.error,
    
    // Search results
    searchResults: searchDocumentsMutation.data,
    
    // Actions (простые версии - не возвращают промисы)
    createDocument,
    updateDocument,
    updateContent,
    updateContentOptimistic,
    deleteDocument,
    toggleFavorite,
    toggleArchive,
    searchDocuments,
    
    // Async versions (возвращают промисы)
    createDocumentAsync,
    updateDocumentAsync,
    updateContentAsync,
    deleteDocumentAsync,
    toggleFavoriteAsync,
    toggleArchiveAsync,
    
    // Queries
    useDocument,
    useDocumentContent,
    useChildDocuments,
    useUserDocuments,
    useRecentDocuments,
    useFavoriteDocuments,
    useArchivedDocuments,
    // Optionally add useAllDocuments here if you want
    useAllDocuments,
  }
}