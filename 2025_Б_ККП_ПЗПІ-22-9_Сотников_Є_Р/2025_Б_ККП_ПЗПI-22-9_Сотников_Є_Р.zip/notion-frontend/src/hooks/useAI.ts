import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { aiApi } from '../lib/api'
import type { AIGenerateRequest, AIGenerateResponse } from '../types'

export const useAI = () => {
  // Health check query
  const { data: healthStatus, isLoading: isCheckingHealth } = useQuery({
    queryKey: ['ai', 'health'],
    queryFn: aiApi.healthCheck,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 1,
    refetchOnWindowFocus: false
  })

  // Generate content mutation
  const generateMutation = useMutation({
    mutationFn: (request: AIGenerateRequest) => aiApi.generate(request),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'AI generation failed'
      toast.error(message)
    }
  })

  // Complete text mutation
  const completeMutation = useMutation({
    mutationFn: ({ prompt, context }: { prompt: string; context?: string }) => 
      aiApi.complete(prompt, context),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Text completion failed'
      toast.error(message)
    }
  })

  // Improve text mutation
  const improveMutation = useMutation({
    mutationFn: ({ text, instructions }: { text: string; instructions?: string }) => 
      aiApi.improve(text, instructions),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Text improvement failed'
      toast.error(message)
    }
  })

  // Summarize text mutation
  const summarizeMutation = useMutation({
    mutationFn: ({ text, length }: { text: string; length?: 'short' | 'medium' | 'long' }) => 
      aiApi.summarize(text, length),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Text summarization failed'
      toast.error(message)
    }
  })

  // Translate text mutation
  const translateMutation = useMutation({
    mutationFn: ({ text, targetLanguage, sourceLanguage }: { 
      text: string; 
      targetLanguage: string; 
      sourceLanguage?: string 
    }) => aiApi.translate(text, targetLanguage, sourceLanguage),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Translation failed'
      toast.error(message)
    }
  })

  // Brainstorm ideas mutation
  const brainstormMutation = useMutation({
    mutationFn: ({ topic, count }: { topic: string; count?: number }) => 
      aiApi.brainstorm(topic, count),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Brainstorming failed'
      toast.error(message)
    }
  })

  // Generate outline mutation
  const outlineMutation = useMutation({
    mutationFn: ({ topic, depth }: { topic: string; depth?: 'basic' | 'detailed' }) => 
      aiApi.generateOutline(topic, depth),
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Outline generation failed'
      toast.error(message)
    }
  })

  // Helper functions
  const generateContent = async (request: AIGenerateRequest): Promise<AIGenerateResponse> => {
    return generateMutation.mutateAsync(request)
  }

  const completeText = async (prompt: string, context?: string): Promise<string> => {
    return completeMutation.mutateAsync({ prompt, context })
  }

  const improveText = async (text: string, instructions?: string): Promise<string> => {
    return improveMutation.mutateAsync({ text, instructions })
  }

  const summarizeText = async (text: string, length: 'short' | 'medium' | 'long' = 'medium'): Promise<string> => {
    return summarizeMutation.mutateAsync({ text, length })
  }

  const translateText = async (text: string, targetLanguage: string, sourceLanguage?: string): Promise<string> => {
    return translateMutation.mutateAsync({ text, targetLanguage, sourceLanguage })
  }

  const brainstormIdeas = async (topic: string, count: number = 5): Promise<string[]> => {
    return brainstormMutation.mutateAsync({ topic, count })
  }

  const generateOutline = async (topic: string, depth: 'basic' | 'detailed' = 'basic'): Promise<string> => {
    return outlineMutation.mutateAsync({ topic, depth })
  }

  return {
    // Status
    isAIAvailable: healthStatus?.status === 'healthy',
    isCheckingHealth,
    
    // Loading states
    isGenerating: generateMutation.isPending,
    isCompleting: completeMutation.isPending,
    isImproving: improveMutation.isPending,
    isSummarizing: summarizeMutation.isPending,
    isTranslating: translateMutation.isPending,
    isBrainstorming: brainstormMutation.isPending,
    isCreatingOutline: outlineMutation.isPending,
    
    // Any operation in progress
    isAIWorking: generateMutation.isPending || completeMutation.isPending || 
                 improveMutation.isPending || summarizeMutation.isPending ||
                 translateMutation.isPending || brainstormMutation.isPending ||
                 outlineMutation.isPending,
    
    // Results
    generateResult: generateMutation.data,
    completeResult: completeMutation.data,
    improveResult: improveMutation.data,
    summarizeResult: summarizeMutation.data,
    translateResult: translateMutation.data,
    brainstormResult: brainstormMutation.data,
    outlineResult: outlineMutation.data,
    
    // Error states
    generateError: generateMutation.error,
    completeError: completeMutation.error,
    improveError: improveMutation.error,
    summarizeError: summarizeMutation.error,
    translateError: translateMutation.error,
    brainstormError: brainstormMutation.error,
    outlineError: outlineMutation.error,
    
    // Functions
    generateContent,
    completeText,
    improveText,
    summarizeText,
    translateText,
    brainstormIdeas,
    generateOutline,
    
    // Reset functions
    resetGenerate: () => generateMutation.reset(),
    resetComplete: () => completeMutation.reset(),
    resetImprove: () => improveMutation.reset(),
    resetSummarize: () => summarizeMutation.reset(),
    resetTranslate: () => translateMutation.reset(),
    resetBrainstorm: () => brainstormMutation.reset(),
    resetOutline: () => outlineMutation.reset(),
  }
}