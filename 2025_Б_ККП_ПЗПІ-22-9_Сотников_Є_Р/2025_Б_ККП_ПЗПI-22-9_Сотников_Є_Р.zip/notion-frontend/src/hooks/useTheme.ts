import { useEffect } from 'react'
import { useAppStore } from '../store/useAppStore'

export const useTheme = () => {
  const { theme, setTheme } = useAppStore()

  // Переключение темы
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light'
    setTheme(newTheme)
  }

  // Установка конкретной темы
  const switchTheme = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme)
  }

  // Проверка на темную тему
  const isDark = theme === 'dark'

  // Слушатель изменений системной темы
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return
    
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    
    const handleChange = (e: MediaQueryListEvent) => {
      try {
        // Применяем системную тему только если нет сохраненных настроек
        const savedTheme = localStorage.getItem('theme')
        if (!savedTheme) {
          const systemTheme = e.matches ? 'dark' : 'light'
          setTheme(systemTheme)
        }
      } catch (error) {
        console.warn('Error handling theme change:', error)
      }
    }

    try {
      mediaQuery.addEventListener('change', handleChange)
      return () => mediaQuery.removeEventListener('change', handleChange)
    } catch (error) {
      console.warn('Could not set up theme change listener:', error)
    }
  }, [setTheme])

  // Синхронизация с CSS переменными
  useEffect(() => {
    if (typeof document === 'undefined' || !document.documentElement) return
    
    const root = document.documentElement
    
    try {
      // Дополнительные CSS классы для компонентов
      if (theme === 'dark') {
        root.classList.add('theme-dark')
        root.classList.remove('theme-light')
      } else {
        root.classList.add('theme-light')
        root.classList.remove('theme-dark')
      }
    } catch (error) {
      console.warn('Could not update theme classes:', error)
    }
  }, [theme])

  return {
    theme,
    isDark,
    toggleTheme,
    switchTheme,
    setTheme
  }
}

// Хелпер для условного применения классов
export const themeClass = (lightClass: string, darkClass: string, currentTheme?: 'light' | 'dark') => {
  const { theme } = useAppStore.getState()
  const activeTheme = currentTheme || theme
  return activeTheme === 'dark' ? darkClass : lightClass
}

// Хелпер для CSS переменных
export const getCSSVariable = (variable: string) => {
  if (typeof window !== 'undefined') {
    return getComputedStyle(document.documentElement).getPropertyValue(variable)
  }
  return ''
}

// Дополнительный хук для классов (для совместимости)
export const useThemeClasses = () => {
  const { theme } = useAppStore()
  const isDark = theme === 'dark'
  
  return {
    theme,
    isDark,
    // Структурированные классы для Header.tsx
    bg: {
      primary: isDark ? 'bg-gray-800' : 'bg-white',
      secondary: isDark ? 'bg-gray-700' : 'bg-gray-100', 
      tertiary: isDark ? 'bg-gray-600' : 'bg-gray-200'
    },
    text: {
      primary: isDark ? 'text-gray-100' : 'text-gray-900',
      secondary: isDark ? 'text-gray-400' : 'text-gray-500',
      tertiary: isDark ? 'text-gray-500' : 'text-gray-400'
    },
    border: {
      primary: isDark ? 'border-gray-700' : 'border-gray-200'
    },
    hover: {
      bg: isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-100',
      text: isDark ? 'hover:text-gray-100' : 'hover:text-gray-900'
    },
    input: isDark 
      ? 'bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400'
      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500',
    
    // Готовые классы для других компонентов (сохраняем обратную совместимость)
    containerClass: isDark 
      ? 'bg-gray-900 text-gray-100' 
      : 'bg-white text-gray-900',
    cardClass: isDark
      ? 'bg-gray-800 border-gray-700'
      : 'bg-white border-gray-200',
    inputClass: isDark
      ? 'bg-gray-700 border-gray-600 text-gray-100'
      : 'bg-white border-gray-300 text-gray-900',
    buttonClass: isDark
      ? 'bg-gray-700 hover:bg-gray-600 text-gray-100'
      : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
  }
}